# v17.16 验证矩阵

## 已执行：Linux 构建环境

| 验证 | 方法 | 结果与范围 |
|---|---|---|
| 继承 ACL 基线问题 | 从上传原源码提取 Helper 函数/Go 内嵌检查表达式，伪造同一继承 FullControl ACE | 原 Helper=True、Go=False，分歧复现；不是实际 NTFS |
| Watchdog 基线缺函数 | 核对原完整注入集合与调用 | 缺 Get-GuardInheritanceFlags 和 Write-Notification 确认 |
| Go 业务边界 | 从当前源码抽取可移植函数直接运行 7 个测试，另含 22 个端点子用例 | 通过；实际文件 IO/解析/发现/通知尾读取，不运行 Windows API |
| PowerShell 完整解析 | PS7.4.6 Parser 解析 Helper/Watchdog/共享/进程/探针/两份 fmt 模板，共 7 份，另解析 build-local.ps1 | 通过；不等于 Windows PowerShell 5.1 Parser |
| PS 实际函数模拟 | ACL、UTF8、本地化审计、INI、FQDN、非空恢复、Java 同步、旧 Schema | 107 项检查通过；包括解析/定义存在性检查，不能称为 107 个独立 Windows 场景 |
| 原生备用进程枚举 | Linux .NET 实际 Process.GetProcesses，CIM 故障注入 | 取得当前进程，证明独立代码路径执行；不是 Windows Winmgmt 故障验证 |
| Windows Go 源文件 test | GOOS=windows go test GuardLauncher_v17.go | 编译检查通过，输出 [no test files]；无 Windows 测试执行 |
| Windows 测试套件 | go test -c，含配置测试、原生当前进程身份、Windows PS Parser 测试 | 编译通过，未执行测试 EXE |
| Go 静态检查 | Windows amd64 go vet，含两个测试文件 | 通过 |
| 发布构建 | Windows amd64/CGO=0，trimpath、-s -w，两个不同输出文件构建 | SHA-256 相同，见构建报告 |
| 包完整性 | SHA-256 全文件清单、ZIP CRC、旧历史原件与配置字节比较 | 最终打包步骤核验，见构建报告 |

命令和输出在 `tests/README.md`、`tests/results/`。

## 必须在 Windows 11 / PowerShell 5.1 执行：本轮全部未实机验证

| 编号 | 场景 | 预期与必须检查的证据 |
|---|---|---|
| W01 | 当前源码 Helper/Watchdog/探针/UAC 脚本完整解析 | build-local 的 Go Windows Parser 测试通过；实际运行前语法预检仍通过 |
| W02 | 普通用户 UAC 同账号/不同凭据，同意/取消 | 唯一成功标记校验有效；取消不误报成功；staging 哈希/ACL/清理正常 |
| W03 | 至少一个真实 Tencent 目录，含中文文件与阻断继承子项 | Apply 逐对象 journal 与有效保护正确；恢复只删除 Guard ACE；SDDL/实际文件访问均检查 |
| W04 | 显式/继承 FullControl Deny、Allow-only、部分 Deny、InheritOnly、读 ACL 拒绝 | 三方定义一致；读取失败和没有 Deny 分开；不重复添加/误删用户 ACE |
| W05 | root junction、child junction、文件 symlink、越界/不存在/不可读目标 | 输出具体链接与 Unknown 诊断，失败关闭/回滚；不得修改外部目标 ACL |
| W06 | QQ 隐藏目录、超过 50 个 INI、CP936 与 UTF-16/UTF8、枚举拒绝 | 无静默截断；编码日志准确；不完整时明确失败；roots=0 暂缓项保持原行为 |
| W07 | 官方/自定义/Store/第三方启动器运行时、深层路径 | 候选不直接 Allow；同一快照本次后代 + Minecraft 参数后才同步实际 EXE；ActiveStore 精确规则匹配 |
| W08 | IDE/Gradle 与 Minecraft Java 同时运行/同一 EXE | 不因 PATH/JAVA_HOME 自动授权；同一 EXE 副作用如实记录；不得误宣称实例级隔离 |
| W09 | Java 配置缺失/空白/BOM/无效路径/不可读；Allowed/Protected 无效 | 按诊断规则处理；严格配置错误在 Apply 前失败；没有猜测域名/端口或回退丢自定义目录 |
| W10 | Java 首次连接早于识别、父链中断、Launcher 提前退出/IPC | 不确认则不自动授权；验证需要显式配置的布局；记录首次连接/已有 Allow 窗口，不称原子隔离 |
| W11 | Winmgmt 不可用、CIM 拒绝/超时/空/属性缺失、PID 重用 | 原生核验能独立运行；不能证明退出时保留保护；不授予未知 Java 规则；父租约/ack 保留 |
| W12 | 普通主程序读取管理员 Watchdog | 有限查询权限、路径/创建时间/PID 校验成功；读取失败仍不能误报就绪 |
| W13 | Watchdog 首次启动、心跳、parent-ready 前后主程序中断、Watchdog 重启 | 无提前删 StateDir；重启读到持久实际 JavaPaths；各身份/时间令牌校验保持 |
| W14 | FQDN 建对象失败、规则降级、能力中途消失、对象删除失败/已不存在 | 活动精确规则保持；待删 ID 不丢；查询确认不存在才退休；最终清理失败保留 session |
| W15 | Helper Apply 中 ACL/Firewall/journal 中途失败 | 独立回滚分组执行；写前日志保留；失败不扩大规则、不盲删会话 |
| W16 | 同一 journal 连续两次以上原子替换，写入/备份/Replace 故障注入 | 保留 v17.14 同目录 .bak/失败保留策略；不能仅用 Parser 作为通过 |
| W17 | 游戏退出、主程序异常、最终 Restore 及恢复失败重试 | Launcher/Java 确认退出才恢复；ActiveStore 无 Guard 规则、用户 Allow 指纹、Profile、auditpol、ACL 分别核验 |
| W18 | Schema 6/7/8/10/11 真实旧记录、损坏/缺失字段 | 可信元数据才迁移；旧 Watchdog 存活/查询未知不能并发恢复；损坏记录保留 |
| W19 | audit_policy.json 中文/旧枚举/乱码/布尔字符串；当前策略被用户改动 | UTF8 正确；稳定枚举优先；无法映射保留记录；不能盲目关闭用户审计 |
| W20 | 高速通知、首条 BOM、半行写入、4 MiB 重置 | 界面通知可恢复读取；审计事件持续保存；真实 NTFS 文件共享/替换无异常 |
| W21 | 无关应用与用户规则在会话中被外部修改 | 当前全局 BLOCK 副作用记录；不覆盖指纹已变化规则；不得声称无关应用已完全不受影响 |

每个实机场景需保存主日志、会话 audit、Watchdog stdout/stderr/startup，必要时保存 session/journal，以及测试前后 SDDL、ActiveStore/Profile 和审核状态。不得用截图 OCR 或 Linux 模型替代这些证据。
