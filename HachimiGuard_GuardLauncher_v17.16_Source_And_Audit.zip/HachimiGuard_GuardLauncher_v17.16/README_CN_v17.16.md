# HachimiGuard GuardLauncher v17.16

Windows x64 源码与交叉编译程序包，基线为用户上传的 v17.15 / Schema 11。

请按顺序阅读：

1. `00_优先阅读_修复状态与剩余边界_v17.16.md`：修复状态和仍存在的兼容边界。
2. `01_AI交接_项目初衷功能与用户要求.md`：当前交接说明与必须保留的要求。
3. `02_修复总结_原理与需求溯源_v17.16.md`：逐项改动、原理、原始要求和验证证据。
4. `TEST_MATRIX_V17.16_CN.md`：测试结果、Windows 待验收项目。

## 运行与配置

在可信本地目录解压后，运行唯一的 `GuardLauncher_v17.16_x64.exe`，按提示选择 Minecraft 启动器。`--background`、`--diagnose`、`--no-network-lock` 及传入启动器参数的方式保留。

严格模式仍然修改三个 Windows Firewall Profile 的默认出站策略为 BLOCK，并临时禁用冲突 Allow；这会影响一部分无关应用。当前版本没有宣称完成按游戏进程隔离的架构改造。

`JavaPaths.txt` 的有效显式条目在启动前获得现有白名单的精确规则。自动扫描只报告候选，运行中的 Watchdog 需同时确认本次进程后代链和 Minecraft 参数，才加入实际 Java。没有可靠归属时不会自动授予规则。首个连接可能早于运行时识别；对于这类启动器，请预先填入实际 Java 的完整路径。不要填写 IDE/Gradle 使用的共享 Java 作为变通。

AllowedDomains、JavaPaths、ProtectedPaths 采用严格 UTF-8 读取（允许 UTF-8 BOM）；默认启动器文件沿用原有读取路径。`JavaPaths.txt` 说明已更新；另外三个配置文件字节未变，没有新增域名、IP、端口或 Tencent 默认目录。

遇到 junction/symlink，当前仍可能中止保护并回滚。新日志会指出链接和可读取的目标元数据；不会据此擅自跟随链接改 ACL。详见 00 文件。

不要删除 `%ProgramData%\HachimiGuard` 中的会话恢复记录；启动失败或恢复失败时保留原始 UTF-8 日志。历史说明保存在 `历史记录/`，不含旧版 EXE。

## 构建与验证边界

Windows 安装 Go 后可运行 `build-local.ps1`。它执行 Go 测试、静态检查和构建，并刷新 SHA-256 清单。`tests/README.md` 给出更多测试命令。

本包在 Linux 完成 Go 业务边界测试、PowerShell 7.4.6 Parser/模拟测试和 Windows x64 交叉构建。Windows PowerShell 5.1、UAC、真实 NTFS ACL、Firewall ActiveStore/WFP 与完整 Minecraft 会话尚未实机验证。不能把编译或模拟结果当作 Windows 验收结论。
