#!/usr/bin/env python3
"""Export exact embedded script templates for Parser/mocked tests; never run Apply."""
import base64,re,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'GuardLauncher_v17.go'
out=Path(sys.argv[2]) if len(sys.argv)>2 else root/'tests'/'generated'
out.mkdir(parents=True,exist_ok=True)
s=source.read_text(encoding='utf-8')
constants=dict(re.findall(r'(?m)^const (\w+) = `([\s\S]*?)`',s))
shared=constants['powershellSessionLifecycleFunctions'].replace('__EFFECTIVE_ACL_FUNCTIONS__',constants.get('powershellEffectiveACLFunctions',''))
java=constants['powershellJavaProcessFunctions']
watch=constants['watchdogScript'].replace('__PERSISTENCE_FUNCTIONS__',shared).replace('__JAVA_PROCESS_FUNCTIONS__',java).replace('__WATCHDOG_UTF16_B64__','')
helper=constants['helperScript'].replace('__PERSISTENCE_FUNCTIONS__',shared).replace('__JAVA_PROCESS_FUNCTIONS__',java).replace('__HELPER_WATCHDOG_FUNCTIONS__',constants['powershellHelperWatchdogFunctions']).replace('__WATCHDOG_UTF16_B64__',base64.b64encode(watch.encode('utf-16le')).decode())
for name,text in [('helper',helper),('watchdog',watch),('process',java),('shared',shared),('probe',constants['javaProcessProbeScript'].replace('__JAVA_PROCESS_FUNCTIONS__',java))]:
    (out/(name+'.ps1')).write_text(text,encoding='utf-8-sig')
# The raw Bootstrap/trampoline source has format placeholders within strings;
# parsing these templates checks syntax, not parameter substitution/runtime APIs.
for index,match in enumerate(re.finditer(r'fmt\.Sprintf\(`([\s\S]*?)`',s)):
    text=match[1]
    if 'param(' in text or '$ErrorActionPreference' in text:
        (out/f'format-template-{index}.ps1').write_text(text,encoding='utf-8-sig')
print(f'Exported {len(list(out.glob("*.ps1")))} exact/template PowerShell scripts to {out}')
