# 测试使用说明

本目录测试不启用实际 Guard Apply、不修改系统防火墙或真实 Tencent ACL。临时文件只用于夹具。`results/` 是本次 Linux 执行结果，Windows 项目见根目录测试矩阵。

## Linux 可移植 Go 测试

需要真正的 Go 编译器。脚本从当前 `GuardLauncher_v17.go` 直接抽取指定可移植函数，在临时目录运行同一份 `GuardLauncher_v17_test.go`，不是重新实现被测逻辑。

```bash
python3 tests/run_portable_tests.py
# 可用 GO_BIN 指定 Go 编译器。
```

## PowerShell Parser 与函数模拟

需要 Python3 导出当前源码模板，然后使用 PowerShell。Windows 使用系统 Windows PowerShell 5.1，Linux 本轮使用 pwsh 7.4.6。

```powershell
python tests/export_scripts.py
powershell.exe -NoProfile -NonInteractive -File tests/verify_powershell.ps1
```

模拟了 NetSecurity、ACL IO、归属快照和部分恢复依赖，不调用真实防火墙/ACL 命令。最后独立 .NET 进程枚举为当前操作系统的真实枚举，但不能代表 Windows 组件已验证。不要单独执行导出的 helper.ps1/watchdog.ps1；它们是解析材料，配置占位符没有实际会话值。

## Windows 完整 Go 测试与构建

在 Windows x64 且安装 Go 时，根目录 `build-local.ps1` 会运行：

```powershell
go test .\GuardLauncher_v17.go .\GuardLauncher_v17_test.go .\GuardLauncher_windows_test.go
go vet .\GuardLauncher_v17.go .\GuardLauncher_v17_test.go .\GuardLauncher_windows_test.go
```

Windows 专用测试检查当前进程的原生身份、系统 PowerShell 对生成的 Helper/Watchdog/trampoline 完整解析，不运行这些脚本的 Apply。不会弹 UAC。

交叉环境可以用 `go test -c` 检查 Windows 测试 EXE 可构建，但不能声称这些 Windows 测试已运行。

`source_diff.patch` 为上传源码到当前源码的差异。`baseline-reproduction.log` 记录原继承 ACE 分歧和原独立 Watchdog 缺函数；原 v17.15 源码没有作为另一个可运行程序混入发布包。

完整模拟脚本包含临时符号链接夹具；在 Windows 上需要允许创建测试符号链接。若夹具创建被拒绝，脚本会报错，不会把该场景标为通过。程序日常运行不要求创建此测试链接。
