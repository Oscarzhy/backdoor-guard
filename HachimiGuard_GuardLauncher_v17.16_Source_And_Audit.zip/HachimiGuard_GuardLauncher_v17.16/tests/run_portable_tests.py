#!/usr/bin/env python3
"""Run exact platform-independent functions from the single Windows source.
Not a Windows integration test. Requires a real Go compiler on PATH (or GO_BIN).
"""
import os,re,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'GuardLauncher_v17.go').read_text(encoding='utf-8')
functions=['parseLine','validEndpointHost','expandWindowsEnv','resolveEndpoint','loadEndpoints','readConfigText','loadJavaPaths','readProtectedPaths','validateLauncherPath','readNotificationLines','cleanDroppedPath']
types=['Endpoint','javaDiscovery','notificationTail']
parts=[]
for name in functions:
    match=re.search(r'(?m)^func '+name+r'\([\s\S]*?\n}',s)
    if not match:raise ValueError('missing '+name)
    parts.append(match[0])
for name in types:
    parts.append(re.search(r'(?m)^type '+name+r' struct \{[\s\S]*?\n}',s)[0])
parts.append(re.search(r'(?m)^var windowsEnvToken = .*',s)[0])
imports='"bytes";"errors";"fmt";"io";"net";"os";"path/filepath";"regexp";"strconv";"strings";"unicode/utf8"'
with tempfile.TemporaryDirectory(prefix='guard-portable-') as tmp:
    p=Path(tmp)
    (p/'source.go').write_text('package main\nimport ('+imports+')\n'+'\n\n'.join(parts))
    (p/'source_test.go').write_bytes((root/'GuardLauncher_v17_test.go').read_bytes())
    env={**os.environ,'GOOS':'linux' if os.name!='nt' else 'windows','CGO_ENABLED':'0','GO111MODULE':'off'}
    subprocess.run([os.environ.get('GO_BIN','go'),'test','-v','-count=1','source.go','source_test.go'],cwd=p,env=env,check=True)
