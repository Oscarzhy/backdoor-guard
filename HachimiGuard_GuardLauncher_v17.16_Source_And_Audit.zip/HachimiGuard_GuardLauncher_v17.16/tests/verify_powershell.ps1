param([string]$ScriptDir=(Join-Path $PSScriptRoot 'generated'))
$ErrorActionPreference='Stop'
$passed=0
function Check([bool]$ok,[string]$name){if(-not $ok){throw ('FAIL '+$name)};$script:passed++;Write-Output ('PASS '+$name)}
function MustThrow([scriptblock]$body,[string]$name){$failed=$false;try{& $body|Out-Null}catch{$failed=$true};Check $failed $name}
$asts=@{}
foreach($file in Get-ChildItem -LiteralPath $ScriptDir -Filter '*.ps1'){
  $tokens=$null;$parseErrors=$null
  $ast=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$parseErrors)
  Check (@($parseErrors).Count -eq 0) ('Parser '+$file.Name+' '+(@($parseErrors|ForEach-Object{$_.Message}) -join '; '))
  $asts[$file.BaseName]=$ast
}
function LoadFunction([string]$script,[string]$name){
  $definitions=@($asts[$script].FindAll({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$true))
  Check ($definitions.Count -eq 1) ('exact definition '+$script+'/'+$name)
  # Global scope keeps selected functions available to tests; no script top-level runs.
  Invoke-Expression ($definitions[0].Extent.Text -replace ('^function '+[regex]::Escape($name)),('function global:'+$name))
}
foreach($name in @('Test-GuardProtectionEffective','Read-GuardUtf8Text','Get-GuardInheritanceFlags','Get-OriginalAuditKind','Write-Notification','Save-PendingDynamicId','Remove-PendingDynamicIds','Assert-DynamicCleanupComplete')){LoadFunction 'shared' $name}
foreach($name in @('Normalize-ProcessImagePath','Test-MinecraftJavaCommandLine','Get-SessionProcessState','Sync-SessionJavaPaths')){LoadFunction 'process' $name}
LoadFunction 'helper' 'Read-QQIniText'
# Ensure the independent Watchdog receives callable definitions, not just call sites.
foreach($name in @('Get-GuardInheritanceFlags','Write-Notification','Test-GuardProtectionEffective')){
  Check (@($asts['watchdog'].FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)).Count -eq 1) ('watchdog shared '+$name)
}
function Write-GuardLog($msg){}
function Get-Acl{param($LiteralPath,$ErrorAction)if($script:aclError){throw 'ACL access denied'};return $script:acl}
$sid='S-1-5-21-123'
function SetACE($inherit,$rights,$prop,$who=$sid,$type='Deny'){
 $script:acl=[pscustomobject]@{Access=@([pscustomobject]@{IsInherited=$inherit;AccessControlType=$type;PropagationFlags=$prop;IdentityReference=[pscustomobject]@{Value=$who};FileSystemRights=$rights})}
}
$full=[Security.AccessControl.FileSystemRights]::FullControl
SetACE $false $full 0;Check (Test-GuardProtectionEffective 'target' $sid) 'explicit FullControl Deny'
SetACE $true $full 0;Check (Test-GuardProtectionEffective 'target' $sid) 'inherited FullControl Deny'
SetACE $true $full 2;Check (-not (Test-GuardProtectionEffective 'target' $sid)) 'InheritOnly does not protect target'
SetACE $false ([Security.AccessControl.FileSystemRights]::Read) 0;Check (-not (Test-GuardProtectionEffective 'target' $sid)) 'partial Deny rejected'
SetACE $false $full 0 'S-1-5-21-999';Check (-not (Test-GuardProtectionEffective 'target' $sid)) 'other SID rejected'
SetACE $false $full 0 $sid 'Allow';Check (-not (Test-GuardProtectionEffective 'target' $sid)) 'Allow rejected'
$script:aclError=$true;MustThrow {Test-GuardProtectionEffective 'target' $sid} 'ACL read error propagates';$script:aclError=$false
Check ((Get-GuardInheritanceFlags ([pscustomobject]@{IsDirectory=$false})) -eq 'None') 'file journal flags'
Check ((Get-GuardInheritanceFlags ([pscustomobject]@{})) -eq 'ContainerInherit,ObjectInherit') 'legacy directory flags'
$tmp=Join-Path ([IO.Path]::GetTempPath()) ('guard-tests-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($tmp)|Out-Null
try{
 $utf8=New-Object Text.UTF8Encoding($false,$true)
 $p=Join-Path $tmp 'audit_policy.json'
 foreach($bom in @($false,$true)){
  $bytes=$utf8.GetBytes('{"Setting":"成功和失败","Path":"C:\\中文\\Tencent"}')
  if($bom){$bytes=[byte[]](@(0xef,0xbb,0xbf)+@($bytes))}
  [IO.File]::WriteAllBytes($p,$bytes)
  $v=(Read-GuardUtf8Text $p)|ConvertFrom-Json
  Check ($v.Path -eq 'C:\中文\Tencent' -and (Get-OriginalAuditKind $v.Setting) -eq 'SuccessFailure') ('localized legacy UTF8 BOM='+$bom)
 }
 foreach($bad in @([byte[]]@(0xff,0xfe,0x41,0),[byte[]]@(0xfe,0xff,0,0x41),[byte[]]@(0,0,0xfe,0xff),[byte[]]@(0xc3,0x28))){
  [IO.File]::WriteAllBytes($p,$bad);MustThrow {Read-GuardUtf8Text $p} ('strict malformed bytes '+[Convert]::ToBase64String($bad))
 }
 $ini=Join-Path $tmp 'UserDataInfo.ini'
 [IO.File]::WriteAllText($ini,'UserDataSavePath=C:\中文\QQ',$utf8)
 Check ((Read-QQIniText $ini) -match '中文') 'QQ UTF8 INI'
 [IO.File]::WriteAllText($ini,'UserDataSavePath=C:\中文\QQ',[Text.Encoding]::Unicode)
 Check ((Read-QQIniText $ini) -match '中文') 'QQ UTF16 BOM INI'
 $cfg=[pscustomobject]@{StateDir=$tmp;NotificationPath=(Join-Path $tmp 'notifications.ndjson');Strict=$true;JavaPaths=@();Group='test'}
 Write-Notification ([pscustomobject]@{type='firewall_block';recordId=1})
 $bytes=[IO.File]::ReadAllBytes($cfg.NotificationPath)
 Check (-not ($bytes[0] -eq 0xef -and $bytes[1] -eq 0xbb)) 'notification no BOM'
 Check (([IO.File]::ReadAllText($cfg.NotificationPath)|ConvertFrom-Json).recordId -eq 1) 'notification JSON'
 # Mock only journal persistence and NetSecurity here; no actual firewall API invoked.
 function Write-AtomicJson($Path,$Value,$Depth){[IO.File]::WriteAllText($Path,($Value|ConvertTo-Json -Depth $Depth -Compress),$utf8)}
 function Get-NetFirewallDynamicKeywordAddress{param($ErrorAction)return @($script:objects)}
 function Remove-NetFirewallDynamicKeywordAddress{param($Id,$ErrorAction)if($script:deleteFail){throw 'injected remove failure'};$script:objects=@($script:objects|Where-Object{$_.Id -ne $Id})}
 $script:objects=@([pscustomobject]@{Id='{one}'});$script:deleteFail=$true
 Remove-PendingDynamicIds @('{one}')
 $journal=(Read-GuardUtf8Text (Join-Path $tmp 'dynamic_keywords.json'))|ConvertFrom-Json
 Check (@($journal.PSObject.Properties|Where-Object{$_.Value -eq '{one}'}).Count -eq 1) 'failed dynamic delete ID retained'
 MustThrow {Assert-DynamicCleanupComplete (Join-Path $tmp 'dynamic_keywords.json')} 'final failed cleanup retains session'
 $script:deleteFail=$false;Remove-PendingDynamicIds @('{one}')
 $journal=(Read-GuardUtf8Text (Join-Path $tmp 'dynamic_keywords.json'))|ConvertFrom-Json
 Check (@($journal.PSObject.Properties).Count -eq 0) 'confirmed deletion retires ID'
 Remove-PendingDynamicIds @('{already-absent}')
 Check (@($script:objects).Count -eq 0) 'absent dynamic ID idempotent'
 # Session attribution: direct caller controls the snapshot, not an implementation model.
 function Get-GuardParentLeaseMutexState($Group){return 'Missing'}
 function Get-DirectParentProcessProbe($ProcessId,$SessionStart){return 'Absent'}
 function Get-GuardProcessSnapshot($session){return [pscustomobject]@{Processes=$script:rows;NativeFallback=$script:native}}
 $session=[pscustomobject]@{SessionStartUtc='2026-11-08T10:00:00Z';ParentPID=10;ParentPath='/guard.exe';LauncherPath='/launcher.exe';JavaPaths=@('/java.exe');Group='test'}
 function Row($id,$parent,$name,$image,$created,$cmd){return [pscustomobject]@{ProcessId=$id;ParentProcessId=$parent;Name=$name;ExecutablePath=$image;CreationDate=([DateTime]$created);CommandLine=$cmd}}
 $parent=Row 10 0 'guard.exe' '/guard.exe' '2026-11-08T09:59:00Z' ''
 $launcher=Row 20 10 'launcher.exe' '/launcher.exe' '2026-11-08T10:00:01Z' ''
 $java=Row 30 20 'java.exe' '/java.exe' '2026-11-08T10:00:02Z' 'net.minecraft.client.main.Main'
 $script:native=$false;$script:rows=@($parent,$launcher,$java)
 $state=Get-SessionProcessState $session
 Check ($state.JavaProcesses.Count -eq 1 -and $state.ConfirmedJavaProcesses.Count -eq 1 -and $state.ParentAlive) 'attributed Minecraft runtime'
 $java.ParentProcessId=999;$state=Get-SessionProcessState $session
 Check ($state.JavaProcesses.Count -eq 1 -and $state.ConfirmedJavaProcesses.Count -eq 0) 'unrelated Minecraft held for liveness but no network grant'
 $java.CommandLine='org.gradle.launcher.daemon.bootstrap.GradleDaemon';$state=Get-SessionProcessState $session
 Check ($state.JavaProcesses.Count -eq 0 -and $state.ConfirmedJavaProcesses.Count -eq 0) 'unrelated Gradle excluded'
 $java.CommandLine='';$state=Get-SessionProcessState $session
 Check ($state.JavaProcesses.Count -eq 1 -and $state.ConfirmedJavaProcesses.Count -eq 0) 'unreadable Java args retains protection no grant'
 $java.CommandLine='net.minecraft.client.main.Main';$java.ParentProcessId=20;$script:native=$true
 $state=Get-SessionProcessState $session;Check ($state.ConfirmedJavaProcesses.Count -eq 0) 'native fallback never grants runtime'
 $script:rows=@((Row 10 0 'guard.exe' '/guard.exe' '2026-11-08T10:02:00Z' ''))
 $state=Get-SessionProcessState $session;Check (-not $state.ParentAlive) 'reused parent PID rejected'
 $script:rows=@([pscustomobject]@{ProcessId=0});$state=Get-SessionProcessState $session
 Check (-not $state.ParentAlive -and $state.JavaProcesses.Count -eq 0) 'verified empty native relevant set'
}finally{Remove-Item -LiteralPath $tmp -Recurse -Force}
Write-Output ('TOTAL '+$passed+' checks passed; Parser/mocks only, no Windows system APIs validated.')
# Verify runtime write-ahead ordering and failed metadata rollback.
$syncRoot=Join-Path ([IO.Path]::GetTempPath()) ('guard-sync-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($syncRoot)|Out-Null
try{
 $runtime=Join-Path $syncRoot 'java.exe';[IO.File]::WriteAllText($runtime,'fixture')
 $cfg=[pscustomobject]@{StateDir=$syncRoot;Strict=$true;JavaPaths=@();Group='test'}
 $script:actions=New-Object Collections.Generic.List[string]
 $script:writeFail=$false
 function Write-AtomicJson($Path,$Value,$Depth){if($script:writeFail){throw 'injected journal failure'};$script:actions.Add('persist')}
 function Audit-AndDisableProgramAllows{$script:actions.Add('audit')}
 function Assert-NoUnmanagedActiveAllows{$script:actions.Add('assert')}
 function Rebuild-FirewallRules{$script:actions.Add('rebuild')}
 $runtimeState=[pscustomobject]@{ConfirmedJavaProcesses=@([pscustomobject]@{ExecutablePath=$runtime;ProcessId=123;CreationDate=[DateTime]::UtcNow})}
 $script:writeFail=$true;MustThrow {Sync-SessionJavaPaths $runtimeState} 'runtime journal failure blocks rules'
 Check ($cfg.JavaPaths.Count -eq 0 -and $script:actions.Count -eq 0) 'runtime failed write rolls back memory'
 $script:writeFail=$false;Sync-SessionJavaPaths $runtimeState
 Check (($script:actions -join ',') -eq 'persist,audit,assert,rebuild') 'runtime persist before conflict audit and rebuild'
 Sync-SessionJavaPaths $runtimeState;Check ($script:actions.Count -eq 4) 'runtime repeated path idempotent'
 # Nonempty ACL Watchdog restore traverses the actual function with mocked ACL IO.
 LoadFunction 'watchdog' 'Restore-GuardACLs'
 LoadFunction 'shared' 'Invoke-LoggedRecoveryStep'
 LoadFunction 'shared' 'Write-SessionRecoverySummary'
 function Get-AclJournalRecords{param($StateDir,[switch]$Refresh)return @([pscustomobject]@{Path='中文 Tencent';UserSID='S-1-5-21-123';Added=$true;IsDirectory=$false})}
 function Test-AclJournalManifest($StateDir){return $true}
 $script:removedFlags=''
 function Remove-GuardDeny($path,$sid,$flags){$script:removedFlags=$flags;return $true}
 Restore-GuardACLs;Check ($script:removedFlags -eq 'None') 'Watchdog nonempty file ACL journal restore'
 function Remove-GuardDeny($path,$sid,$flags){return $false}
 MustThrow {Restore-GuardACLs} 'Watchdog ACL removal failure propagates'
 # Real .NET enumeration fallback; CIM is injected as failed, no Windows API claim.
 LoadFunction 'process' 'Get-GuardProcessSnapshot'
 function Get-CimInstance{param($ClassName,$OperationTimeoutSec,$ErrorAction)throw 'injected provider unavailable'}
 $nativeCfg=[pscustomobject]@{LauncherPath=('/'+[Diagnostics.Process]::GetCurrentProcess().ProcessName+'.exe');ParentPID=0}
 $snapshot=Get-GuardProcessSnapshot $nativeCfg
 Check ($snapshot.NativeFallback -and @($snapshot.Processes|Where-Object{$_.ProcessId -eq $PID}).Count -eq 1) 'CIM exception uses independent .NET process enumeration'
}finally{Remove-Item -LiteralPath $syncRoot -Force -Recurse}
Write-Output ('FINAL TOTAL '+$passed+' checks passed; mocks/Linux .NET, not Windows acceptance.')
$moreRoot=Join-Path ([IO.Path]::GetTempPath()) ('guard-boundary-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($moreRoot)|Out-Null
try{
 LoadFunction 'shared' 'Restore-AuditStateFromPath'
 LoadFunction 'shared' 'Get-ExpectedAuditSettingAfterFailureEnable'
 $audit=Join-Path $moreRoot 'audit_policy.json'
 $utf8=New-Object Text.UTF8Encoding($false,$true)
 [IO.File]::WriteAllText($audit,'{"FailureEnabled":false,"Setting":"乱码未知"}',$utf8)
 MustThrow {Restore-AuditStateFromPath $audit} 'unknown legacy audit kind retains record'
 Check (Test-Path -LiteralPath $audit) 'unknown audit record kept'
 function Get-FilteringPlatformAuditState{return [pscustomobject]@{Known=$true;Kind='None';FailureEnabled=$false;Setting='无审核'}}
 [IO.File]::WriteAllText($audit,'{"FailureEnabled":false,"Setting":"乱码","OriginalKind":"None","ExpectedKind":"Failure"}',$utf8)
 Restore-AuditStateFromPath $audit
 Check $true 'stable audit enum takes precedence over localized text'
 [IO.File]::WriteAllText($audit,'{"FailureEnabled":"false","OriginalKind":"None","ExpectedKind":"Failure"}',$utf8)
 MustThrow {Restore-AuditStateFromPath $audit} 'audit bool string rejected'
 LoadFunction 'helper' 'Find-QQSavePaths'
 LoadFunction 'helper' 'Expand-CallerPath'
 LoadFunction 'helper' 'Write-ReparseDiagnostic'
 $cfg=[pscustomobject]@{CallerPublic=(Join-Path $moreRoot 'public');CallerAppData=(Join-Path $moreRoot 'appdata');CallerUserProfile=(Join-Path $moreRoot 'profile');ProtectedPaths=@()}
 $qqRoot=Join-Path $cfg.CallerAppData 'Tencent'
 [IO.Directory]::CreateDirectory($qqRoot)|Out-Null
 foreach($i in 1..51){
  $sub=Join-Path $qqRoot ('.hidden-'+$i);[IO.Directory]::CreateDirectory($sub)|Out-Null
  $target=Join-Path $moreRoot ('data-'+$i);[IO.Directory]::CreateDirectory($target)|Out-Null
  [IO.File]::WriteAllText((Join-Path $sub 'UserDataInfo.ini'),('UserDataSavePath='+$target),$utf8)
 }
 $found=@(Find-QQSavePaths)
 Check ($found.Count -eq 51) 'QQ hidden entries and more than 50 INIs'
 [IO.File]::WriteAllBytes((Join-Path $qqRoot 'UserDataInfo.ini'),[byte[]]@(255,254,1))
 MustThrow {Find-QQSavePaths} 'QQ unreadable encoding rejects incomplete coverage'
}finally{Remove-Item -LiteralPath $moreRoot -Recurse -Force}
Write-Output ('ALL TOTAL '+$passed+' checks passed.')
$legacyRoot=Join-Path ([IO.Path]::GetTempPath()) ('guard-legacy-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($legacyRoot)|Out-Null
try{
 LoadFunction 'helper' 'Recover-StaleSessions'
 function Is-AdminOrSystemOwned($Path){return $true}
 function Get-SessionProcessState($session){return [pscustomobject]@{ParentAlive=$false;LauncherProcesses=@();JavaProcesses=@()}}
 function FirewallGroupExists($group){return $false}
 function Remove-GuardFirewallRulesByGroup{param($Group,$Context)$script:cleanupCalls++}
 function Get-GuardFirewallRulesByGroup{param($Group,$PolicyStore)return @()}
 function Restore-DisabledAllowsFrom($path){}
 function Get-AclJournalRecords{param($StateDir,[switch]$Refresh)return @()}
 function Get-CimInstance{param($ClassName,$Filter,$OperationTimeoutSec,$ErrorAction)if($script:legacyCimFail){throw 'injected CIM error'};return $script:legacyProc}
 function Get-DirectParentProcessProbe($ProcessId,$SessionStart){return $script:directLegacy}
 $cfg=[pscustomobject]@{StateRoot=$legacyRoot;StateDir='unused';Group='new'}
 $versions=@{'v17.1'=6;'v17.2'=7;'v17.3'=7;'v17.4'=7;'v17.5'=8;'v17.6'=10;'v17.7'=10;'v17.8'=10;'v17.9'=10;'v17.10'=11;'v17.11'=11;'v17.12'=11;'v17.13'=11;'v17.14'=11;'v17.15'=11;'v17.16'=11}
 foreach($version in @($versions.Keys|Sort-Object)){
  $dir=Join-Path $legacyRoot ('session-'+$version);[IO.Directory]::CreateDirectory($dir)|Out-Null
  [IO.File]::WriteAllText((Join-Path $dir 'session.json'),([pscustomobject]@{Version=$version;Schema=$versions[$version];Group='old';SessionStartUtc='2026-11-08T10:00:00Z'}|ConvertTo-Json),$utf8)
  $script:cleanupCalls=0;Recover-StaleSessions
  Check (-not (Test-Path -LiteralPath $dir) -and $script:cleanupCalls -eq 1) ('mock legacy restore '+$version+' schema='+$versions[$version])
 }
 $dir=Join-Path $legacyRoot 'session-query';[IO.Directory]::CreateDirectory($dir)|Out-Null
 [IO.File]::WriteAllText((Join-Path $dir 'session.json'),'{"Version":"v17.15","Schema":11,"Group":"old","SessionStartUtc":"2026-11-08T10:00:00Z"}',$utf8)
 [IO.File]::WriteAllText((Join-Path $dir 'watchdog.pid'),'123')
 $script:cleanupCalls=0;$script:legacyCimFail=$true;$script:directLegacy='Unknown'
 MustThrow {Recover-StaleSessions} 'legacy CIM and native uncertainty blocks recovery'
 Check ((Test-Path -LiteralPath $dir) -and $script:cleanupCalls -eq 0) 'legacy uncertainty retains state before mutation'
 $script:legacyCimFail=$false;$script:directLegacy='Alive';$script:legacyProc=[pscustomobject]@{CommandLine=('powershell -File '+(Join-Path $dir 'watchdog.ps1'))}
 MustThrow {Recover-StaleSessions} 'live legacy Watchdog never raced'
 $script:legacyCimFail=$true;$script:directLegacy='Absent'
 Recover-StaleSessions;Check (-not (Test-Path -LiteralPath $dir)) 'native absence allows stale restore during CIM failure'
}finally{Remove-Item -LiteralPath $legacyRoot -Recurse -Force}
Write-Output ('VERIFIED TOTAL '+$passed+' checks passed.')
$rollbackRoot=Join-Path ([IO.Path]::GetTempPath()) ('guard-rollback-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($rollbackRoot)|Out-Null
try{
 $cfg=[pscustomobject]@{StateDir=$rollbackRoot;Group='test'}
 foreach($pair in @(@('helper','Remove-Firewall'),@('watchdog','Remove-Fw'))){
  LoadFunction $pair[0] $pair[1]
  function Write-AtomicText($Path,$Text){}
  function Remove-GuardFirewallRulesByGroup{param($Group,$Context)throw 'injected rules removal failure'}
  $script:relaxed=0
  function Restore-DisabledAllows{$script:relaxed++}
  function Restore-ProfileState($Path,$Required){$script:relaxed++}
  function Restore-Profiles{$script:relaxed++}
  function Remove-DynamicKeywordAddresses{$script:relaxed++}
  function Remove-DynamicKeywords{$script:relaxed++}
  function Restore-FilteringPlatformConnectionAudit{}
  function Restore-Audit{}
  if($pair[0] -eq 'helper'){MustThrow {Remove-Firewall} 'Helper rollback rule residue fails closed'}else{MustThrow {Remove-Fw} 'Watchdog rule residue fails closed'}
  Check ($script:relaxed -eq 0) ($pair[0]+' rule removal failure defers profiles and Allows')
 }
 # Root symlink is rejected before any ACL function, using isolated fixture dirs.
 LoadFunction 'helper' 'Protect-One'
 $target=Join-Path $rollbackRoot 'target';[IO.Directory]::CreateDirectory($target)|Out-Null
 $link=Join-Path $rollbackRoot 'root-link'
 # New-Item requires link permission on Windows. A denied fixture setup is
 # reported as an error rather than falsely claiming the scenario passed.
 New-Item -ItemType SymbolicLink -Path $link -Target $target -ErrorAction Stop|Out-Null
 $script:aclCalls=0
 function Protect-PathIfNeeded($Path,$SID,$IsDirectory){$script:aclCalls++;return $false}
 Check (-not (Protect-One $link 0) -and $script:aclCalls -eq 0) 'root symlink refuses before any ACL write'
 Remove-Item -LiteralPath $link -Force
}finally{Remove-Item -LiteralPath $rollbackRoot -Recurse -Force}
Write-Output ('COMPLETE TOTAL '+$passed+' checks passed.')
# Malformed legacy PID cannot reuse a value left by an earlier loop iteration.
$pidRoot=Join-Path ([IO.Path]::GetTempPath()) ('guard-pid-'+[guid]::NewGuid().ToString('N'))
$pidDir=Join-Path $pidRoot 'session-bad-pid';[IO.Directory]::CreateDirectory($pidDir)|Out-Null
try{
 $cfg=[pscustomobject]@{StateRoot=$pidRoot;StateDir='unused';Group='new'}
 [IO.File]::WriteAllText((Join-Path $pidDir 'session.json'),'{"Version":"v17.15","Schema":11,"Group":"old","SessionStartUtc":"2026-11-08T10:00:00Z"}',$utf8)
 [IO.File]::WriteAllText((Join-Path $pidDir 'watchdog.pid'),'not-a-pid')
 $script:legacyCimFail=$false;$script:legacyProc=$null;$script:directLegacy='Absent'
 MustThrow {Recover-StaleSessions} 'malformed legacy PID cannot use native absent shortcut'
 [IO.File]::WriteAllText((Join-Path $pidDir 'watchdog.pid'),'123')
 $script:directLegacy='Alive';MustThrow {Recover-StaleSessions} 'missing CIM row does not override native alive PID'
}finally{Remove-Item -LiteralPath $pidRoot -Recurse -Force}
$tokens=$null;$parseErrors=$null
[void][Management.Automation.Language.Parser]::ParseFile((Join-Path (Split-Path -Parent $PSScriptRoot) 'build-local.ps1'),[ref]$tokens,[ref]$parseErrors)
Check (@($parseErrors).Count -eq 0) 'Parser build-local.ps1'
Write-Output ('FINAL VERIFIED TOTAL '+$passed+' checks passed.')
