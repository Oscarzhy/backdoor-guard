# GuardLauncher v17.9：Watchdog 提前删除会话目录修复

## 用户现场错误

主程序报告：

`Watchdog initial readiness failed: 会话状态目录在 Watchdog 就绪前消失：CreateFile ... session-<id>: The system cannot find the file specified.`

OCR 可能改变空格、反斜杠或全半角字符，因此没有把识别文本中的字符差异直接当作路径拼写故障。源码检查发现两个可导致或放大该症状的缺陷。

## 已确认的源码缺陷

### 1. Watchdog 的无目标启动宽限期没有考虑 GuardLauncher 父进程

`Get-SessionProcessState` 已经返回 `ParentAlive`，但 v17.8 Watchdog 循环的 60 秒“从未出现启动器/Java”退出判断只看 `targetSeen` 与 `sessionDeadline`，完全忽略 `ParentAlive`。

因此如果 Minecraft 目标进程尚未启动，而 GuardLauncher 主程序仍在初始化或等待启动器，Watchdog 仍可能在宽限期结束后执行恢复并删除 `session-*` 目录。主程序随后读取状态目录时便会得到路径不存在。

v17.9 改为：

- Minecraft 启动器/Java 已出现：仍按原有目标进程活动和 30 秒交接窗口决定结束，不因 GuardLauncher 主程序继续运行而延迟正常恢复。
- Minecraft 目标尚未出现、但 GuardLauncher 父进程仍存活：保持防护和 Watchdog 心跳，不启动自动清理倒计时。
- Minecraft 目标尚未出现且 GuardLauncher 父进程已退出：从确认父进程退出的时刻重新开始 60 秒恢复宽限期。
- WMI/CIM 快照失败：继续保留保护，不当作父进程或 Minecraft 已退出。

### 2. 父进程路径表示差异可能导致 ParentAlive 假阴性

v17.8 用 PID、创建时间和完整可执行文件路径核对 GuardLauncher 父进程。部分 Windows 启动路径可能令 `os.Executable()` 与 `Win32_Process.ExecutablePath` 的路径表示不同。

v17.9 保留完整路径精确匹配优先；路径不一致时，只有同时满足以下条件，才使用兼容回退：

- ParentPID 完全相同；
- 进程创建时间不晚于本会话 `SessionStartUtc`，从而排除会话后 PID 重用；
- 可执行文件 basename 与会话记录完全相同。

回退会在 Watchdog 日志中单独记录。它不接受仅凭进程名相似或仅凭 PID 匹配。

### 3. Go 就绪检查对状态目录的单次 Stat 错误过于敏感

v17.8 在 `waitForWatchdogReady` 中，第一次 `os.Stat(StateDir)` 失败就立刻返回，没有利用已有的就绪等待窗口。

v17.9 在 15 秒就绪窗口内对目录暂不可用、尚未出现或暂时无法读取的情况持续重试；目录始终不可用时仍失败关闭，并把最后一次错误、观察次数及 Watchdog 持久化诊断附在超时信息中。它不会把“目录不存在”视为 Watchdog 就绪。

## 未改变

- 默认出站 BLOCK、AllowedDomains、静态 IP/FQDN 放行范围。
- Tencent 默认保护路径、自定义 QQ 路径发现规则。
- Java 进程标记与会话归属算法（仅补充 GuardLauncher 父进程路径兼容比较）。
- 会话锁、Watchdog 心跳字段、UAC staging 哈希验证。
- 5157、原子恢复记录、ACL 逐对象日志和恢复策略。

## 验收限制

当前构建环境没有 Windows PowerShell 5.1、真实 UAC、WMI/CIM 或 NTFS 环境。Go Windows amd64 交叉编译和源码定向检查不能代替 Windows 实测。必须验证：

1. UAC/Helper 返回后，Watchdog 在主进程存活期间持续保留 `session-*` 目录。
2. 延迟启动 Minecraft（超过 60 秒）时，Watchdog 不应提前恢复。
3. Minecraft 目标出现后正常退出，仍按原有逻辑恢复。
4. GuardLauncher 在 Minecraft 尚未出现时退出，Watchdog 从父进程退出时开始 60 秒宽限期，再恢复。
5. 父 PID 被复用时，创建时间检查拒绝把新进程当作旧 GuardLauncher。
6. `StateDir` 暂时不存在时，Go 在就绪窗口内重试；持续不存在时输出最后错误和诊断，而不是误报成功。
