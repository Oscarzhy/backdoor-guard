# GuardLauncher v17.6 变更记录

基线：v17.5 Lifecycle Half 1。范围仅为本次计划第二半：5157 恢复、恢复记录原子性、Tencent ACL 子目录覆盖和完善恢复日志。

## 1. 5157 Filtering Platform Connection 审计恢复

- Helper 与 Watchdog 共用同一个 `Restore-AuditStateFromPath` 实现，移除两套逻辑不一致的风险。
- 使用子类别 GUID 查询 `auditpol /get /r`，解析已知本地化状态；未知格式只记录并保留，不猜测修改。
- 保存原始 Setting/Kind、ExpectedKind 和 ChangeAttempted；在改变审计设置前写 `audit_policy_apply_started` 标记。
- 恢复前比较 Guard 预期状态与当前状态；发现外部改变时不覆盖。
- 执行恢复后重新读取并验证是否回到原始状态。
- 初始化失败与恢复失败写完整异常/脚本栈；失败的状态文件和会话目录保留。

## 2. 原子恢复记录

- 统一 `Write-AtomicText` / `Write-AtomicJson`：同目录唯一临时文件、Flush(true)、原子 Replace/Move。
- 逐对象 ACL JSON 写前记录先提交，再更新 manifest RecordCount，然后才修改 DACL。
- manifest 记录 Schema、Group、CreatedUtc、Format 和 RecordCount。
- 恢复时 RecordCount 少于实际记录数则拒绝；多于实际数则报告丢失，不自动猜测；实际数多于 manifest 则报告崩溃窗口并校正。
- 缺少 manifest 的 per-object JSON 不被当作可信恢复记录；旧 NDJSON 继续兼容。
- Watchdog 启动脚本本身也改为原子写入并保留 UTF-8 BOM，减少脚本半写入风险。

## 3. Tencent ACL 子目录覆盖

- 对每个受保护根目录逐层枚举目录和普通文件。
- 逐对象检查当前有效 Deny；关闭继承或没有有效 Deny 的对象，先写入恢复记录，再添加明确 Deny 并复核。
- 文件仅添加当前对象 Deny；目录添加 ContainerInherit/ObjectInherit。
- 重解析点不跟随、不修改目标；发现时日志标为 COVERAGE_INCOMPLETE，当前保护启动失败关闭，不报告完整覆盖。
- 任一目录枚举、属性读取、ACL 查询或写入失败都会记录路径与异常，整棵根目录不算完成。
- Watchdog 周期执行使用只读缓存；恢复前强制刷新磁盘记录和校验 manifest。

## 4. 恢复步骤与持久化日志

- 防火墙清理、动态关键词、用户原 Allow、Profile、5157、Tencent ACL 独立执行与汇总。
- Guard 防火墙规则仍在 ActiveStore 时，不恢复用户 Allow/Profile；5157/ACL 仍尝试独立恢复。
- 任一恢复步骤失败都保留状态文件，并让 Watchdog/遗留恢复后续重试。
- 每个恢复分组记录开始、成功、失败、重试次数、异常详情与 ScriptStackTrace。
- ACL 成功记录按根目录与进度汇总，失败对象逐路径记录；避免大目录产生冗余成功日志。
- 补充 stale session 枚举失败、缺少 metadata、损坏日志、manifest 缺失/计数异常等持久化诊断。

- 遗留会话 Profile 恢复会同时检查 Profile 修改标记，避免 Guard 规则已被外部删除且清理标记尚未写入时漏恢复基线。
- 原子写 Watchdog 脚本时显式写入 UTF-8 BOM（通过 UTF8Encoding.GetPreamble），保证 Windows PowerShell 5.1 正确读取非 ASCII 脚本文字。

## 5. 不变项目

- 保留 v17.5 全局互斥锁、Watchdog 心跳/身份监督、进程归属判断与统一审计日志。
- 保留 v17.3 FQDN 兼容性降级策略。
- 不改变 AllowedDomains.txt、JavaPaths.txt、ProtectedPaths.txt 的原有规则范围。
- 不修改 hosts；不新增后台持久化服务或计划任务。
