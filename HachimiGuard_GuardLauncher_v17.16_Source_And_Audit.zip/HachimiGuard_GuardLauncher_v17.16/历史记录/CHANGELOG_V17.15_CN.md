# GuardLauncher v17.15 更新记录

## 修复一：ACL journal 的 UTF-8 读取

v17.14 的写入端通过 `Write-AtomicText` 保存 UTF-8 无 BOM 文件，但 ACL manifest 与逐条记录部分读取端仍使用 `Get-Content -Raw`。Windows PowerShell 5.1 在未指定编码时可能按系统活动代码页解码，非 ASCII 路径名称存在变成乱码的风险。

v17.15 在 Helper/Watchdog 共用的持久化函数中加入 `Read-GuardUtf8Text`，并用于：

- `acl_journal_manifest.json` 的初始化、完整性检查和写前日志更新读取；
- `acl_journal\*.json` 每条 ACL 恢复记录；
- 旧版 `acl_state.ndjson`。

读取器显式按严格 UTF-8 解码，可剥离 UTF-8 BOM；遇到 UTF-16/UTF-32 BOM 或非法 UTF-8 时明确失败，不按系统代码页猜测。

## 修复二：session.json 的 UTF-8 读取

- `Recover-StaleSessions` 读取旧会话元数据时使用 `Read-GuardUtf8Text`。
- `ResumeWatchdog` 读取当前会话元数据时使用同一读取器。
- Go `validateWatchdogSessionState` 在 `json.Unmarshal` 前去除可选 UTF-8 BOM、校验 `utf8.Valid`；非法字节会返回明确错误，不允许被 `encoding/json` 替换后继续做会话身份比较。
- 将 v17.15 / Schema 11 加入后续旧会话识别表。

## 范围控制

本版没有修改防火墙规则、默认出站 BLOCK、网络允许列表、ProtectedPaths、ACL 规则授予/移除算法、Java 路径扫描、Watchdog 生命周期或进程识别。四份配置文件与 v17.14 完全一致。

## 验证边界

Go Windows x64 交叉编译、`go vet`、定向静态断言和重复构建检查通过。当前环境没有 Windows PowerShell 5.1，未执行真实 .NET UTF8Encoding、NTFS ACL journal 读取或 Watchdog 恢复实机测试。
