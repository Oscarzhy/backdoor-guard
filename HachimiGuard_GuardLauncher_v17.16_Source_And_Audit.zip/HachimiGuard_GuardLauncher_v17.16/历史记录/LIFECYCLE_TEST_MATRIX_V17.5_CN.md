# GuardLauncher v17.5 生命周期测试矩阵（Windows 实测待执行）

测试前：保留 v17.1–v17.4 原 ZIP；在独立目录解压 v17.5；准备可恢复的 Windows 测试环境；确认 `%ProgramData%\HachimiGuard`、防火墙 Profile 和测试 Tencent 目录的基线；不要在重要生产会话中首次测试。

| 编号 | 场景 | 操作 | 预期结果 |
|---|---|---|---|
| L01 | 单实例正常启动 | 启动 v17.5，允许 UAC | Helper 取得独占锁；Watchdog 取得锁后写入新鲜心跳；主程序确认身份后继续 |
| L02 | 第二实例竞争 | 第一实例保护运行时启动第二个 v17.5 | 第二实例不能覆盖第一会话基线或修改防火墙/ACL；记录锁竞争并安全退出 |
| L03 | Helper 初始化期间竞争 | UAC Helper 正在执行时快速启动第二实例 | 第二实例无法并发进入遗留恢复/Apply |
| L04 | Watchdog 正常退出 | 正常关闭 Minecraft | Watchdog 记录退出检测、恢复开始、每次重试/失败/成功；清理完成后释放锁 |
| L05 | 主程序异常结束 | Minecraft 运行时结束 GuardLauncher 主程序 | Watchdog 继续持锁和监控；目标进程退出后恢复；日志保留会话记录 |
| L06 | Watchdog 被强制结束 | Minecraft 运行时终止 watchdog powershell.exe | 主程序识别心跳/进程异常，尝试一次接管；不能确认时不得误恢复，状态资料保留 |
| L07 | Watchdog 进程仍活但不更新 | 测试环境中暂停/挂起 Watchdog（不要在生产机） | 心跳过期后记录故障；不得仅凭 PID 存活认定健康；无法取得锁时保留保护 |
| L08 | PID 复用模拟 | 仅在自动化测试环境模拟原 PID 被另一进程复用 | CreationDate 不匹配时拒绝身份确认 |
| L09 | WMI 查询异常 | 在隔离测试中暂时阻断相关 CIM 查询或模拟查询失败 | 不得把查询失败/空快照解释为 Minecraft 已退出；保持保护并记录重试 |
| L10 | 最终 Restore 门禁 | Minecraft 仍在运行时手动测试 Restore 模式 | Helper 二次查询发现 Launcher/Java 活跃后拒绝恢复，状态保留 |
| L11 | UAC 取消/失败 | 取消 UAC 或让 Helper 语法检查失败 | 主程序日志、`uac-failure-*.log` 和可用的 ProgramData 审计记录包含失败详情 |
| L12 | Watchdog 启动元数据写失败 | 测试环境模拟 `watchdog.pid` 写入失败 | Helper 仍持锁；只有确认进程路径、脚本命令行和创建时间匹配时才终止子进程 |
| L13 | 旧 v17.4 Watchdog | v17.4 会话仍活动时尝试启动 v17.5 | v17.5 不应与旧 Watchdog 并发恢复；记录冲突并保留旧会话 |
| L14 | 日志并发 | Helper、主程序、Watchdog 高频写日志 | 同一审计文件记录完整、可解析、行内容无交错；各条日志含会话组 |
| L15 | 日志目录不可写 | 测试环境中拒绝主程序日志路径写入 | 使用 LOCALAPPDATA 回退；Helper/Watchdog 尝试 ProgramData/会话应急日志 |
| L16 | Go Panic / Helper 异常 | 仅用测试构建注入可控异常 | Go 堆栈、PowerShell 异常类型、消息、ScriptStackTrace 均持久化 |
| L17 | 进程监控超时 | 模拟 WMI 长时间不可信且 Watchdog 未完成 | 主程序保留会话资料并报错，不因 30/120 秒超时直接 Restore |
| L18 | 系统重启遗留 | 测试 Windows 重启后再次启动 v17.5 | 无存活锁句柄时新 Helper 执行遗留会话恢复；未完成恢复记录不应被清除 |

## 收集的日志

- 程序目录 `logs` 或 `%LOCALAPPDATA%\HachimiGuard\logs`。
- `%ProgramData%\HachimiGuard\audit\session-*.log`。
- `%ProgramData%\HachimiGuard\lifecycle-emergency.log`（若产生）。
- 对应 `session-*` 的 `watchdog.heartbeat.json`、`watchdog.pid` 和 `session.json`（保留隐私后再分享）。

本矩阵只描述预期测试，不代表已在 Windows 上通过。
