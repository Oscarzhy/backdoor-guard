# v17.10 构建状态（2026-11-08）

- Target: Windows amd64, CGO_ENABLED=0
- Go commands: `gofmt`, `GOOS=windows GOARCH=amd64 go test ./GuardLauncher_v17.go`, `go vet`, `go build -trimpath -ldflags='-s -w'`
- `go test`: 命令通过，输出 `[no test files]`；项目没有 Go 测试用例。
- Two independent builds: byte-identical.
- Binary type: PE32+ Windows x86-64 console.
- PowerShell templates: delimiter/quote structural check passed; no actual PowerShell 5.1 parser available in build environment.
- Windows UAC/NTFS/Firewall/WMI runtime tests: not executed.
- Final EXE SHA-256: `51dd0fd77114dc55f323344b3bd43ecdf4d0cd80ce2ec40c1521fb265e33cc11`
