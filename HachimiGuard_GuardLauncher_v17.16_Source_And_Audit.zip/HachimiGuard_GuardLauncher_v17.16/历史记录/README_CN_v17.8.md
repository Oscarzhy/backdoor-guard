# HachimiGuard GuardLauncher v17.8

Windows x64 Minecraft 防护启动器。v17.8 以 v17.7 为基线，修复 UAC 外层等待范围错误导致 Watchdog 心跳文件丢失的问题，并增加 Watchdog 启动诊断；v17.5 的会话互斥、Watchdog 生命周期监督和统一日志基础设施，以及 v17.6 的 5157 恢复、原子恢复记录和 Tencent ACL 子目录覆盖均保持不变。v17.3 FQDN 兼容性、v17.4 Minecraft Java 进程识别也继续保留。


## v17.8 Watchdog 启动/心跳时序修复（本次针对真实 Windows 错误）

1. **根因：等待了整个进程树**。v17.7 的 UAC 外层命令使用 `Start-Process -Wait` 等待管理员 Bootstrap。PowerShell 5.1 文档明确说明，该参数会等待指定进程及其所有子进程退出；而 Helper 在 Bootstrap 进程内启动长期运行的 Watchdog 子进程，因此外层可能一直等到 Watchdog 结束，才把控制权交还主程序。Watchdog 在主程序尚未启动 Minecraft 时，可能走完无目标宽限期并清理会话，导致主程序随后读不到 `watchdog.heartbeat.json`。
2. **等待改为精确进程对象**。UAC 外层现在使用 `Start-Process -PassThru` 启动管理员 Bootstrap，再通过 `Wait-Process -InputObject $p` 只等待 Bootstrap 自身退出，并读取该进程真实 ExitCode。不会等待 Watchdog 子进程；Watchdog 仍独立运行。Helper 原有的 PID/创建时间/会话组/心跳握手保持不变。
3. **Watchdog 子进程启动诊断**。Helper 将 Watchdog 标准输出、标准错误和启动阶段记录分别写入 ProgramData 审计目录中的会话专属文件：`*.watchdog.stdout.log`、`*.watchdog.stderr.log`、`*.watchdog.startup.log`。这些诊断文件放在会话状态目录之外，避免 Watchdog 删除会话目录时把诊断一起删掉。
4. **明确记录启动阶段**。Watchdog 在配置成功解析后记录脚本入口、StateDir/StateRoot、PowerShell 版本、尝试取得会话锁、成功取得锁、首次心跳写入前和首次心跳成功。未能就绪时 Helper 收集最近的启动日志、stderr 和 stdout。
5. **主程序超时诊断**。Go 侧再次检查心跳超时时，会读取相同审计目录中的三份诊断文件，并将其末尾内容附在错误中，帮助区分脚本未启动、锁竞争、配置解析失败、CIM 查询失败或心跳文件写入失败。

## v17.7 紧急启动修复（基于真实 Windows 日志）

1. **修复 UAC 命令过长**：v17.6 将完整 Bootstrap 脚本再次 UTF-16LE Base64 编码后嵌入 `Start-Process -EncodedCommand`。当日志中的编码长度达到 26,540 字符时，超过 v17.6 的 26,000 字符保护阈值，程序会在启动 UAC 之前主动拒绝执行。v17.7 将完整 Bootstrap 写入临时 `bootstrap.ps1` 文件；命令行只携带一个较小的 UTF-16LE Base64 安全 trampoline。
2. **保持提权边界**：trampoline 启动后先检查 staging 目录不是 reparse point，再将目录和文件 ACL 收紧到 Administrators/SYSTEM 完全控制、当前提升身份只读；然后核对 `bootstrap.ps1` 的 SHA-256，匹配后才执行。Helper、config 仍分别进行 SHA-256 校验；Helper、Watchdog、Bootstrap 和 trampoline 都在本地 PowerShell Parser 预检。
3. **长度保护不再卡在 26,000**：实际 UAC trampoline 编码上限改为 14,000 Base64 字符，外层命令限制为 16,000 UTF-16 单元；每次运行都会记录实际 trampoline Base64 长度和 outer command 长度。超限仍会在 UAC 前失败关闭，但正常路径不再把完整 Bootstrap 代码塞入命令行。
4. **修复审计路径绑定时机**：v17.6 在 `runElevated` 失败时也无条件把预计的 ProgramData 审计路径登记为共享日志目标；但超长命令拒绝发生在 UAC 之前，Bootstrap 尚未创建目录和文件，导致后续反复报 `The system cannot find the path specified`。v17.7 只有在会话审计文件已存在、为普通文件且当前调用用户可追加时才绑定路径；否则只向用户可写的每次运行日志记录一条清晰警告，不会反复向不存在的共享路径写入。
5. **ProgramData 路径清洁与可诊断**：读取 `ProgramData` 时去除首尾空白并验证为绝对路径；状态目录和审计路径使用带引号格式记录，以便发现真实路径内的空格或控制字符。

### 本次日志对应的根因

- `UAC bootstrap command is too large (26540 Base64 characters)`：v17.6 本地上限为 26,000，故在 `exec.Command` 前返回，UAC 进程未启动。
- `shared lifecycle audit append failed: ... path not found`：错误分支仍调用了无条件的 `setSessionAuditPath`，但创建该目录/文件的管理员 Bootstrap 没有运行。此错误是启动失败的次生现象，不代表已证明 ProgramData ACL 错误。

## v17.5 第一半：会话互斥、Watchdog 生命周期与持久化日志（继承）

1. **全局会话互斥**：管理员 Helper 在遗留会话检查和初始化系统保护前，取得 `%ProgramData%\HachimiGuard\active-session.lock` 的独占文件句柄；新 Watchdog 必须取得同一独占句柄后才开始监控，并持有到恢复结束。锁由 Windows 文件句柄共享模式实现，不以“锁文件存在”判断存活；进程异常终止时，Windows 关闭句柄，后续实例可以重新取得锁。锁文件仅保留当前持有者 PID、模式、会话组和取得时间，供诊断使用。
2. **Helper → Watchdog 所有权交接**：Helper 先启动 Watchdog，写入 PID/创建时间元数据，再释放锁；Watchdog 取得锁并写入有效心跳后，Helper 才报告启动成功。握手失败时，Helper 仅在重新取得锁且重新核对进程路径、命令行和创建时间后，才会尝试终止自己启动的子进程。
3. **Watchdog 心跳**：心跳 JSON 含 Schema、会话组、PID、进程创建时间、UTC 更新时间、单调序号、状态和消息。心跳采用同目录临时文件 + `File.Replace`/`File.Move` 更新，避免主程序读取到半写入 JSON。
4. **主程序持续监督**：主程序每 3 秒检查心跳和进程存活；每 12 秒核对 PowerShell 可执行文件路径、PID 与创建时间，避免仅凭一个可复用 PID 判断健康。心跳过期、进程退出或 `Failed` 状态会触发生命周期故障处理；必要时请求一次管理员 Watchdog 接管，不会无限弹出 UAC。
5. **恢复的失败关闭保护**：如果主程序自己的进程查询超时，不能将超时解释为 Minecraft 已退出。最终 Restore Helper 在取得全局锁后还会重新查询会话启动器与 Minecraft Java；仍有目标进程、WMI 查询失败或快照不可信时拒绝撤销保护并保留会话资料。
6. **新旧版本交接**：v17.5 遗留恢复会检查仍在运行的 v17.4 Watchdog，避免新 Helper 与旧 Watchdog 同时恢复同一会话。v17.3/v17.4 会话元数据仍按已有兼容分支读取。
7. **持久化日志**：普通主程序日志继续保存于程序目录 `logs`，无法写入时使用用户本地应用数据回退。管理员会话审计日志保存在 `%ProgramData%\HachimiGuard\audit`。主程序、UAC Bootstrap、Helper、Watchdog 使用相同规范化路径派生的 Windows 命名互斥量串行写入；每条记录写入后 Flush/Sync。记录启动、Helper 模式、锁竞争、锁交接、Watchdog PID/心跳状态、恢复开始/重试/失败/成功、UAC 失败和未处理 Panic 堆栈。若审计文件不可写，会尝试写入 ProgramData 的 `lifecycle-emergency.log` 和会话目录应急日志。
8. **早期崩溃日志**：若主程序在常规日志器初始化前发生 Panic，使用 `%LOCALAPPDATA%\HachimiGuard\logs`（不可用时系统临时目录）建立早期崩溃日志，并记录 Go 堆栈。

## v17.6 第二半：恢复一致性、原子日志与 ACL 子目录覆盖

1. **5157 恢复统一**：Helper 与 Watchdog 共用同一套 `Restore-AuditStateFromPath`；使用 Filtering Platform Connection 子类别 GUID 读取状态，识别当前 Success/Failure 组合。恢复前比较原始状态、Guard 预期状态和当前状态；如果当前状态与 Guard 预期不一致，按外部用户/GPO 修改处理并保留，不擅自覆盖。恢复后再次读取并验证原始设置。
2. **审计恢复检查点**：修改 5157 前先原子保存 `audit_policy.json`，再设置 `ChangeAttempted` 与 `audit_policy_apply_started` 检查点，最后才执行 `auditpol /set`。恢复时若检查点存在但日志缺失，会报错并保留会话，不把“缺失状态”当作成功。
3. **原子恢复记录**：JSON 状态使用同目录唯一临时文件，写入后 `Flush(true)`，再通过 `File.Replace`/`File.Move` 提交。覆盖 Profile 基线、被禁用 Allow 规则清单、动态关键词、活动目标、会话元数据和状态标记。写入失败会阻止后续会改变系统状态的动作。
4. **ACL 逐对象写前日志**：每个新 Deny ACE 都先写独立 JSON 恢复记录并完成原子提交，再修改 ACL。`acl_journal_manifest.json` 使用会话 Group、Schema 和 `RecordCount`。记录数少于清单时拒绝自动清理并保留会话；记录数多于清单时按“记录已提交、清单更新前进程中断”处理，核对已提交记录并原子校正计数。损坏的 JSON 不会被跳过。
5. **旧 ACL 日志兼容**：仍读取旧版 `acl_state.ndjson`；新格式 per-object JSON 若缺少对应 manifest，则拒绝把它当作可验证的恢复记录。临时 `.tmp` 文件只作为未提交记录记录告警，不视为 ACL 已修改。
6. **递归 ACL 覆盖**：保护根目录后逐层枚举所有普通子目录与文件。检查每个对象的当前有效 Deny；已有有效保护的不重复加 ACE，关闭继承或没有有效 Deny 的对象单独写前日志、加显式 Deny，并验证结果。目录 ACE 使用 ContainerInherit/ObjectInherit；文件 ACE 只保护当前文件。
7. **重解析点策略**：junction、symlink 和其他 reparse point 不跟随、不修改其外部目标。发现它们时记录路径和数量，并把该根目录标记为 `COVERAGE_INCOMPLETE`；当前启动会失败关闭，不会把未检查目标报告成完整受保护。
8. **恢复过程分项执行**：防火墙规则、动态关键词、原 Allow 规则、Profile、5157 和 Tencent ACL 分开记录结果。防火墙规则仍残留时，不恢复较宽松 Profile 或用户 Allow；但仍独立尝试 5157 和 ACL 恢复。某一步失败不会跳过其他独立步骤；任何失败都保留会话目录供 Watchdog/遗留恢复重试。
9. **日志颗粒度**：每个恢复分组记录 START/SUCCESS/FAILURE、重试次数、完整异常与 PowerShell `ScriptStackTrace`；ACL 大规模成功操作按目录和进度汇总，失败对象仍逐路径记录，避免为每个成功对象产生重复日志。
10. **Watchdog 重试异常**：每次恢复尝试都有持久化状态/日志；异常时写明 attempt、异常类型、消息和脚本栈，更新 `RecoveryFailed` 心跳；恢复全部成功后才写 `Restored` 并尝试清理会话目录。

### 重要 ACL 边界

- 目录树检查遇到权限读取失败、枚举失败或无法验证的对象时，该保护根不会被标记为完整覆盖；Helper 会失败并进入回滚/重试，不会静默跳过。
- Reparse point 的目标不会自动跟随修改。若 Tencent 子目录中有 junction/symlink，必须另外检查其实际目标，并按独立保护路径配置；本版为避免跨目录误改，选择不跟随并拒绝声称覆盖完整。
- 逐对象 ACL 写前日志会对大量对象产生磁盘 I/O。Watchdog 周期检查会缓存当前会话只读快照；执行真正恢复时强制从磁盘重新读取并校验 manifest。

> v17.6 完成了本次两半计划中的源码修复；v17.7 进一步修复本次发现的 UAC 启动与审计路径故障。当前版本仍不是 Windows 实机验证版。

## 保护行为（继承 v17.2）

- 保护当前用户默认 Tencent 目录，并读取 QQ `UserDataInfo.ini` 中的 `UserDataSavePath` 补充自定义路径。
- 严格出站隔离默认开启：Domain、Private、Public 配置文件设为默认出站 BLOCK，仅为指定启动器和 Java 可执行文件建立精确 TCP 目标规则。
- 默认目标来自 `AllowedDomains.txt`；Minecraft 服务器目标为 `3c3u.org:25565`，不会泛化放行整个 Minecraft 域名家族。
- 只撤销 Guard 有记录新增的 ACL Deny ACE；退出与遗留会话恢复继续使用 v17.2 的原有流程。
- 不修改 hosts。`--diagnose` 只检查，`--background` 只隐藏控制台，`--no-network-lock` 明确关闭本次会话的全局网络隔离。

## 继承的 v17.3 FQDN 兼容性修复

1. **能力预检**：Helper 和 Watchdog 分别检查动态关键词相关 NetSecurity 命令及必要参数、Windows build、Microsoft Defender Antivirus 状态/平台版本、Network Protection 状态，以及可观察到的 DoH 配置。
2. **静态 IP 与 FQDN 分离**：已解析的静态 IP 规则独立建立，不依赖 FQDN 功能是否可用。FQDN 仅是补充能力，不再被当作系统必然支持的功能。
3. **不支持时降级**：系统版本、Defender 平台/状态、Network Protection 或已检测到的 DoH 条件不满足时，只保留已经解析的静态 IP 目标；未解析的域名跳过，默认出站 BLOCK 保持，不会降级为 `Any` 或宽泛地址放行。
4. **建立失败回退**：动态关键词对象或 FQDN 防火墙规则建立失败时，移除本轮 Guard 规则并仅重建明确解析出的静态 IP 规则。Watchdog 在运行期发现前置条件不再满足时，也会先移除 FQDN 规则，再按静态 IP 清单重建。
5. **零目标处理**：当静态 IP 和 FQDN 都不可用时，`active_endpoints.json` 保存为合法 JSON 空数组 `[]`。Helper、Watchdog 和主程序三层都认可这一状态：主程序会额外验证本会话的 `active_endpoints.json` 确实是合法空数组 `[]`，且 ActiveStore 三个配置文件仍然启用并默认出站 BLOCK；其他“规则数为 0”的情况仍然失败关闭。
6. **规则关联核对**：FQDN 规则自检会核对关联过滤器中的动态关键词 ID，并核对该 ID 对应的 FQDN 与 AutoResolve 属性。

## v17.4 Java 进程识别修复

本版统一 Helper、Watchdog 和主程序的 Minecraft Java 进程归属判断，避免把所有“会话开始后启动的 java.exe/javaw.exe”或所有使用同一路径的 Java 程序都视为 Minecraft。

1. **进程身份**：通过 `Win32_Process` 同一快照读取 PID、ParentProcessId、CreationDate、ExecutablePath 和 CommandLine；路径比较不区分大小写，进程创建时间用于排除 PID 重用造成的错误父子关系。
2. **启动器归属**：用 GuardLauncher 的 PID + 自身可执行文件路径校验父进程；用用户选择的 LauncherPath + 本会话开始时间识别启动器。进程树只沿这些会话根节点构建。
3. **Minecraft 参数识别**：识别 Vanilla 主类、Legacy LaunchWrapper、Fabric KnotClient/KnotServer、Forge/NeoForge ModLauncher，以及 Quilt KnotClient/KnotServer；同时识别 `--gameDir`、`--assetsDir`/`--assetIndex` 与用户/版本参数组合。
4. **自定义 Java**：即使 Minecraft 使用的 Java 路径不在 `JavaPaths.txt`，只要其命令行具有可识别的 Minecraft/Fabric/Forge/Quilt 启动参数，仍会被跟踪。配置中的 Java 路径只有在进程属于本会话启动器/父进程树时才用于补充识别。
5. **无关 Java 排除**：IDE、Gradle Daemon、编译工具或其他程序即使在会话开始后启动，且使用同一个 Java 可执行文件路径，只要不具备 Minecraft 参数且不属于本会话启动器树，就不会阻止保护恢复；启动前也不再因为任意 Java 占用同一运行时路径而拒绝启动。
6. **旧会话兼容**：v17.3 的 `session.json` 尚无 `ParentPath` 字段；新识别器对这类旧记录使用 `GuardLauncher*.exe` 文件名回退判断，并仍检查启动器路径、创建时间和 Minecraft Java 参数。
7. **查询失败保护**：Watchdog 无法取得可靠进程快照时记录日志、保持现有保护并重试；空快照也作为无法安全判断处理，不能解释为“没有进程”。Go 主程序进程查询失败时暂按 Minecraft Java 仍然存活处理，避免过早恢复。正式启动前的预检查无法查询时会警告但不会把“未知”误报为“已检测到 Minecraft”。

`JavaPaths.txt` 仍用于防火墙程序路径规则，不改变现有白名单范围；本次只调整进程生命周期归属判断。程序仍按路径与启动参数识别，不等于签名或哈希身份验证。符合 Minecraft 启动标记且在会话开始后启动的其他 Minecraft Java 实例也会被视为活动游戏进程；这是全局出站隔离下的保守处理，避免某个 Minecraft 仍在运行时提前撤销全局保护。普通 IDE、Gradle Daemon 和普通 Java JAR 不会仅因使用相同 Java 路径而被计入。

## FQDN 的 Windows 前提与限制

- Microsoft Defender Antivirus 必须开启，平台版本至少 `4.18.2209.7`。
- Network Protection 必须为 Block 或 Audit。Windows Server 还需要相应的 Network Protection Server 开关。
- DoH 必须关闭。程序只读取可观察到的浏览器策略和 Windows DNS Client DoH AutoUpgrade 状态；它**无法枚举所有浏览器用户偏好、代理、VPN 或应用自带的 DNS-over-HTTPS 实现**。无法确认的情况会写入兼容性警告，仍需人工确认实际使用的应用已关闭 DoH。
- Windows Firewall FQDN 规则必须由应用实际发起匹配域名的 DNS 查询才能获得地址；代理、安全 DNS、某些 VPN 配置和缓存 IP 都可能使解析/放行无法按预期发生。首次连接也可能因防火墙地址更新延迟而被阻止，应用重试后才成功。
- Microsoft Firewall CSP 列出的客户端动态关键词最低支持基线为 Windows 10 20H2/21H1/21H2 对应 `KB5013942`（build `19042/19043/19044.1706`）及后续版本，以及 Windows 11 21H2 build `22000` 及后续版本。程序只把这些已知客户端基线用于版本预检；命令存在本身不代表运行环境满足全部 FQDN 条件。
- 程序不会为了启用 FQDN 自动修改 Defender、Network Protection、DoH、DNS、浏览器策略或 VPN 设置。

## 使用

- 解压到普通用户有写入权限的固定目录，保留 v17.1/v17.2 目录，不要覆盖旧版。
- 运行 `GuardLauncher_v17.7_x64.exe`，首次选择 Minecraft 启动器 EXE；也可传入路径：
  - `GuardLauncher_v17.7_x64.exe "C:\Path\MinecraftLauncher.exe"`
  - `GuardLauncher_v17.7_x64.exe --background "C:\Path\MinecraftLauncher.exe"`
  - `GuardLauncher_v17.7_x64.exe --diagnose`
  - `GuardLauncher_v17.7_x64.exe --no-network-lock "C:\Path\MinecraftLauncher.exe"`
- `--diagnose` 不修改 ACL 或防火墙；正式测试仍应使用独立测试目录，并准备好恢复点。

## v17.5 生命周期日志与恢复行为（继承）

- `active-session.lock` 是文件句柄独占锁；锁文件内容仅用于诊断，不是锁有效性的依据。
- `watchdog.heartbeat.json` 是 Watchdog 状态与身份检查点，心跳过期并不自动授权恢复；必须在锁保护下重新查询进程状态。
- 当进程查询持续失败且 Watchdog 没有完成恢复时，主程序会保留会话状态并报告失败，不会因等待超时就直接恢复更宽松的网络配置或 ACL。
- Watchdog 运行中被强制结束、断电或系统崩溃时，进程本身可能来不及写出“崩溃”记录；下一次启动会根据锁句柄释放、心跳陈旧和状态目录执行遗留会话检查。突然断电无法保证写入最后一条日志。

## 日志与状态

- 普通日志：程序目录 `logs\YYYY-MM-DD_HH-MM-SS.mmm.log`，不可写时回退 `%LOCALAPPDATA%\HachimiGuard\logs`。
- 管理员审计日志：`%ProgramData%\HachimiGuard\audit`。
- 会话状态：`%ProgramData%\HachimiGuard\session-*`。
- FQDN 前置条件、DoH 可见性、降级原因、动态关键词对象创建失败和规则重建结果会写入管理员审计日志。

## 安全边界

程序按可执行文件路径匹配启动器/Java，不等于签名或哈希身份验证；管理员级恶意程序不在威胁模型内。静态 IP 放行只适用于配置中明确解析出的地址，域名地址变更可能需要重新启动保护会话以刷新静态 IP 清单。

**本包不是 Windows 实机验证版。** 当前构建环境没有 Windows PowerShell 5.1 Parser 和 Windows 实机；首次使用前请在可恢复环境里验证 UAC、文件锁句柄交接、Watchdog 心跳/进程身份、双实例竞争、异常退出恢复、ActiveStore、Defender、动态关键词 AutoResolve、DoH 场景以及 ACL 恢复。

## 持久化日志与故障诊断（继承 v17.6）

- 管理员审计日志：`%ProgramData%\HachimiGuard\audit\session-<会话ID>.log`，主程序、UAC Bootstrap、Helper、Watchdog 通过共享 Windows 命名互斥量串行追加，每条记录 `Flush(true)`。
- 普通日志：程序目录 `logs`，不可写时回退 `%LOCALAPPDATA%\HachimiGuard\logs`。
- 应急日志：当主审计文件不可写时，尝试 `lifecycle-emergency.log` / `emergency-lifecycle.log`；同时向标准错误输出日志写入失败原因。
- 每次 ACL 添加动作按“原子写入逐对象恢复记录 → 更新 RecordCount manifest → 修改 DACL → 验证”顺序执行。
- 日志记录目录树扫描统计、reparse point、不可访问路径、ACL 每 500 个对象进度、恢复每个步骤的结果、完整异常和 PowerShell 堆栈。
- 断电、系统崩溃或外部强杀可能发生在日志写入之间；`Flush(true)` 降低丢失风险但不能保证物理设备在断电瞬间完成持久化。下一次启动依靠锁句柄、心跳和恢复检查点发现未完成会话。

## 本地构建

在 Windows PowerShell 中运行 `build-local.ps1`。目标为 Windows amd64 Console 子系统，使用当前目录的 `GuardLauncher_v17.go`；输出为 `GuardLauncher_v17.7_x64.exe`。
