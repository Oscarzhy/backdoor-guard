# GuardLauncher v17.3 静态检查报告

## Go 构建

- `gofmt -w GuardLauncher_v17.go`：已执行。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go`：成功，输出 `[no test files]`，没有业务测试用例。
- 同目标 `go vet`：成功。
- 同目标 `go build`：成功。
- EXE 类型：PE32+ / Windows x86-64 / Console 子系统。

## FQDN 源码检查

- Helper 和 Watchdog 各有一份独立 `Get-FqdnCapability`。
- 预检检查动态关键词 cmdlet 及所需参数，以及 `New-NetFirewallRule -RemoteDynamicKeywordAddresses`。
- 不满足预检时跳过未解析 FQDN；不生成 Any、通配 IP 或任意远端地址规则。
- 静态 IP Allow 与 FQDN Allow 分开创建。
- FQDN 规则创建异常时先移除本轮 Guard 组规则，再按静态 IP 清单重建；后续 ActiveStore 语义检查仍然是必要门槛。
- Watchdog 运行期如果 FQDN 条件变为不可用，则改为 IP-only；空目标列表用显式 `ConvertTo-Json -InputObject ([object[]]...)` 生成 `[]`。
- Helper 与 Watchdog 的零目标健康状态都要求 ActiveStore Profile 启用、默认出站 BLOCK 且 Guard Allow 规则数为 0；Go 主程序还会验证当前会话记录确实是合法空 JSON 数组，避免把缺失/损坏记录误判成有意 BLOCK-only。
- 动态关键词 ID 在创建对象前写入会话状态，降低异常退出导致孤立对象的可能。
- 未发现 `New-NetFirewallRule -PassThru` 或 `New-NetFirewallRule -EdgeTraversalPolicy` 用法；前者并非该 cmdlet 声明参数，后者文档限定为入站规则。
- 对比 v17.2，Java 进程识别函数及其配置未变；没有移入上一轮 v17.3 草稿里的 Java 匹配改动。

## 文本结构检查边界

- 源码包含两段嵌入式 PowerShell 脚本；本环境没有 Windows PowerShell 5.1 / PowerShell 7，不能运行官方 Parser。
- 本报告不声称 PowerShell 语法检查通过，不声称 Defender、Network Protection、DoH 或 Firewall ActiveStore 已在 Windows 上实测。
- `go test` 的 `[no test files]` 仅表示该单文件包可通过测试构建流程，不是业务功能测试。
