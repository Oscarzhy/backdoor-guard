# GuardLauncher v17.8 构建状态（2026-11-08）

- 基线：v17.7 UAC/Audit Path Fix。
- 版本：v17.8，Windows amd64，Console 子系统。
- Go：1.23.2。
- 构建环境：Linux amd64 交叉编译 Windows；未安装 `powershell`/`pwsh`。
- 构建命令：
  - `gofmt -w GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o GuardLauncher_v17.8_x64.exe GuardLauncher_v17.go`
- 结果：全部命令退出码为 0；`go test` 输出 `[no test files]`。
- PE：PE32+ Windows x86-64 Console executable。
- PowerShell：本机 Parser 预检逻辑保留，但当前容器没有 Windows PowerShell 5.1，未实际执行 Parser。
- Windows 实机：未执行；UAC、Wait-Process、Watchdog 子进程独立运行、首次心跳和完整恢复仍待实机验证。

注意：交叉编译和静态断言不证明 Windows UAC/PowerShell/文件锁功能已正常运行。
