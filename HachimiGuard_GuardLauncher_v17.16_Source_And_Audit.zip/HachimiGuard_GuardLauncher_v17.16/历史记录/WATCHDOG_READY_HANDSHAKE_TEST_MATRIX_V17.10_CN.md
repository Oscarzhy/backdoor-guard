# v17.10 Watchdog 就绪交接测试矩阵

| 场景 | 预期结果 | 当前验证状态 |
|---|---|---|
| Helper 创建 StateDir 与 session.json | 路径存在且元数据可读 | 源码静态核对 |
| Helper 写 watchdog.pid | 单一路径写入，读回 PID 与进程 PID 一致 | 源码静态核对 |
| Watchdog 启动并取得全局锁 | 写首次心跳，PID/Group 正确 | 未在 Windows 实测 |
| 主程序读取心跳 | 同时验证 session.json、watchdog.pid 和进程身份 | Go 编译/静态断言 |
| 主程序写 parent-ready Token | 写入 Helper 预创建的文件并 Sync | Go 编译/静态断言 |
| Watchdog 尚未收到有效 Token | 保持保护，不删除 StateDir | PowerShell 结构静态检查 |
| GuardLauncher 在确认前退出 | 进入孤儿恢复宽限期，之后按进程状态恢复 | 未在 Windows 实测 |
| ack Group/PID/Token 错误 | 不视为已就绪，保持保护 | 源码静态核对 |
| session.json 与 PID/heartbeat 交叉不一致 | Helper/主程序拒绝确认就绪 | 源码静态核对 |
| Watchdog 启动失败 | stdout/stderr/startup 诊断保留 | 未在 Windows 实测 |
| 正常游戏退出 | 目标进程消失后按原恢复流程清理 | 未在 Windows 实测 |

真实 Windows 验收还应覆盖：UAC 同意/取消、PowerShell 5.1 Parser、Helper/Watchdog 启动失败、主程序在 ack 前退出、Watchdog 在 ack 后崩溃、父进程 PID 复用、WMI 暂时失败及恢复重试。
