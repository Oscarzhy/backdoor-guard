# v17.14 原子 journal 写入修复说明

## 故障现场

日志：`disabled_allows.json :: 使用“4”个参数调用“Replace”时发生异常：“路径的形式不合法。”`。调用栈为 `Write-AtomicText -> Write-AtomicJson -> Save-DisabledAllows -> Audit-AndDisableProgramAllows`。

失败时目标 `disabled_allows.json` 已存在：首次持久化完成后，程序继续审计下一条宽泛 Outbound Allow 规则，需要更新同一 journal。v17.13 用 `File.Replace($temp,$full,$null,$true)` 更新已有文件。虽然 .NET 文档说明备份参数可为 null，但日志并未记录该次调用的 source/temp 路径，无法据此证明具体是哪一个参数被运行时判定为非法。

## 修复设计

- 使用明确的同目录备份路径，避免 PowerShell 5.1 对空备份参数的重载/参数绑定歧义。
- 显式将四个参数转换为 `String, String, String, Boolean`。
- 备份路径使用随机 GUID，避免与现有文件冲突，并确保与源/目标文件处于同一卷。
- 只有在 `File.Replace` 成功且目标文件存在后，才删除备份。
- 失败时记录三个路径及文件存在状态；若旧文件已被移动到备份路径则保留备份，不做危险的直接覆盖。

## 使用范围

该函数位于共享的 PowerShell 生命周期函数块，被 Helper 和 Watchdog 脚本共同嵌入，因此所有 journal、心跳和状态 JSON 更新均使用同一实现。

## 尚未实测

容器没有 Windows PowerShell 5.1 / NTFS。代码结构、参数非空、同目录、失败保留和版本映射可作静态验证；仍需目标机验证至少两次对同一 JSON 文件连续写入，并验证 Replace 失败时原目标或备份内容仍完整。
