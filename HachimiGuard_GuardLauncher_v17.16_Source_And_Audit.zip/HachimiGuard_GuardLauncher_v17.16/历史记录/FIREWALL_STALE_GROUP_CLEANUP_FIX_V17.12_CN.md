# 防火墙旧 Group 清理修复说明（v17.12）

旧实现直接使用 `Remove-NetFirewallRule -Group $Group -ErrorAction Stop`。用户 Windows 11 机器在旧组已无规则时返回 CIM Job 异常，使“已经没有东西可删除”变成恢复失败。

新实现不把空匹配传给 Remove cmdlet：

1. `Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop` 枚举本机持久规则。
2. 在 PowerShell 进程内按 Group 精确匹配。
3. 只有匹配数量大于零时，才调用 `Remove-NetFirewallRule -InputObject <这些规则>`。
4. 重新枚举 `ActiveStore` 并按同一个 Group 比对。
5. ActiveStore 为零才返回成功；仍有规则或任一枚举失败都抛错，恢复记录保留。

这既让零匹配具备幂等性，也避免误删同 Group 的非本地策略规则。函数由 Helper 和 Watchdog 共用。
