# GuardLauncher v17.15 静态审计报告

## 修改范围

只处理 v17.14 未修改代码审计中的两项读取编码问题：ACL journal 与 session.json。未改动网络隔离策略、受保护路径集合、Java 白名单范围或进程生命周期逻辑。

## ACL journal 检查

- `Read-GuardUtf8Text` 位于 `powershellSessionLifecycleFunctions`，由 Go 在生成 Helper 与 Watchdog 脚本时共享注入。
- ACL manifest 的三个读取点均通过该函数解码。
- 每条 `acl_journal/*.json` 记录均通过该函数解码。
- 旧 `acl_state.ndjson` 同样使用严格 UTF-8 解码，逐行 JSON 解析逻辑和逆序恢复顺序保持不变。
- 没有保留针对上述 ACL 文件的默认 `Get-Content -Raw` 读取。

## session.json 检查

- `Recover-StaleSessions` 旧会话元数据读取改用共享严格 UTF-8 读取器。
- `ResumeWatchdog` 读取当前会话元数据改用共享严格 UTF-8 读取器。
- Go Watchdog 状态校验允许 UTF-8 BOM，并先验证 UTF-8 字节合法性，再调用 JSON 解码。
- 读取或解析失败仍沿用原来的失败关闭行为：保留会话目录，不猜测路径、不继续恢复。

## 兼容性

- UTF-8 无 BOM：支持（本程序当前原子 JSON 写入格式）。
- UTF-8 BOM：支持（读取器剥离 BOM）。
- 非法 UTF-8：拒绝读取并返回错误。
- UTF-16/UTF-32 BOM：明确拒绝，不自动切换编码。
- Schema 仍为 11，新增 v17.15 版本映射。

## 结果与限制

本次代码差异审阅显示，除版本文案、必要的旧会话版本映射和本报告所述编码读取外，没有修改其他策略与控制流程。

Go Windows x64 交叉编译、`go vet`、重复构建与 24 项定向静态断言通过。Go `test` 命令通过，但当前没有 Go 单元测试文件。环境没有 Windows PowerShell 5.1/NTFS 实机，因此 PowerShell 函数解析、.NET 解码实际行为和 ACL 回滚仍未获得 Windows 实机验证。
