# v17.11 父进程存活核验修复说明

v17.10 已有主程序 parent-ready 确认文件，但在确认文件写入之前，Watchdog 判断父进程是否退出仍主要依赖 CIM/WMI 快照。若某次快照没有返回 ParentPID，可能出现父进程实际上仍运行、Watchdog 却开始无目标孤儿宽限期的窗口。

v17.11 将父进程活跃判断扩展为三项证据：

1. CIM 进程快照（原有 PID、映像路径与进程创建时间归属判断）。
2. Go 主程序在 UAC 前创建的命名 Mutex 租约。Mutex 由一个锁定 OS 线程持有；主程序退出或线程异常结束后，Windows 能报告 abandoned 状态。
3. .NET `Process.GetProcessById` 直接探测，检查 HasExited 与 StartTime，排除 PID 在会话开始后被重用的情况。

任何活着或不确定的证据都优先保留保护。未确认 parent-ready 的清理分支在宽限期到期时重新读取确认文件并复查父进程；正常无目标清理也增加最后检查。WMI 本身不可用时，仍沿用“保留状态并重试”的规则。

另外，主程序缺失目录观察计数使用 `errors.Is` 检查 `%w` 包装后的错误链；删除审计日志对普通结束路径的空 final snapshot 做了空值保护。

**限制：** Windows Mutex 与 .NET `Mutex.OpenExisting` 跨完整性级别行为、PowerShell 5.1 的异常展开和系统实机生命周期必须测试后才能最终确认。本文件记录的是实现和静态构建结果，不将源码推断等同于已复现本机根因。
