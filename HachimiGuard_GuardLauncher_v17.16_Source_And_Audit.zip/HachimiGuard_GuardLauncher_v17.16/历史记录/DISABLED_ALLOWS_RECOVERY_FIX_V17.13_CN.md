# disabled_allows.json 恢复兼容修复

- 读取 UTF-8，不再依赖 Windows PowerShell 5.1 的默认文本代码页。
- 只在 `Fingerprint` 字符串字段中尝试补齐未转义的双引号。
- 不改变规则名称、Group、原始 Enabled 标志及其他 JSON 字段。
- 如果 `Fingerprint` 不是对象最后属性、结束位置不唯一、修复后仍无法解析，直接失败并保留恢复记录。
- 仅当 `WasEnabled` 为 true 且当前规则完整指纹与 journal 一致时才重新启用原规则。

Helper 和 Watchdog 两条脚本路径均采用同一 reader。
