# GuardLauncher v17.14 未修改代码横向审计报告

- 审计基线：`HachimiGuard_GuardLauncher_v17.14_Clean_Release.zip`
- 审计目标：检查本轮未修改、且尚未由用户实机日志验证通过的代码路径，寻找与既往 PowerShell 参数类型、JSON/编码、文件路径、空结果误判、错误被吞掉相似的问题。
- 本轮操作：**只读审计；没有修改源码、配置、脚本或 EXE。**
- 执行环境：Linux 容器；有 Go 1.23.2，没有 `pwsh` / Windows PowerShell 5.1、UAC、NetSecurity、NTFS ACL 或 WFP 实机环境。

## 结论

发现多项需要在下一版集中修正或明确记录的潜在缺陷。最重要的是：ACL 单条恢复记录和 `session.json` 都以 UTF-8 无 BOM 写入，却有 Windows PowerShell 5.1 代码路径用默认 `Get-Content` 读取；在路径或元数据含非 ASCII 字符时，可能造成记录内容乱码。另有 QQ 自定义目录扫描的隐藏文件、扫描上限和错误忽略问题；Java/保护路径配置读取也存在静默遗漏。

本报告将“确定的源码问题”与“条件性兼容风险”分开。静态审计不能证明它们已在用户电脑触发。

## A. 优先修正

### A1. ACL per-object journal UTF-8 读写不一致

- 位置：`powershellSessionLifecycleFunctions.ps1` 第 283–296 行、第 298–323 行，尤其第 315 行；ACL 删除在 `helperScript.ps1` 第 389–396 行及 `watchdogScript.ps1` 第 606–621 行。
- 写入：`Write-AclJournalRecord` 经 `Write-AtomicJson` 写入 UTF-8 无 BOM JSON；记录包含实际 `Path`。
- 读取：`Get-AclJournalRecords` 对 `acl_journal\*.json` 使用 `Get-Content -Raw`，没有指定编码。
- 影响：Windows PowerShell 5.1 对无 BOM 文件使用系统活动代码页的默认行为可能破坏非 ASCII 路径。若读取后路径变成乱码，`Remove-GuardDeny` 会在 `Test-Path` 返回 false 时把“原路径不存在”记成成功；真实路径上的 Guard Deny 可能没有移除，而恢复流程仍可能继续清理状态目录。
- 判断：**确定的源码编码不一致；具体是否触发取决于受保护路径是否含当前代码页无法表示的字符。**
- 下一版：统一使用 `[IO.File]::ReadAllText(path,[Text.Encoding]::UTF8)` 后再 `ConvertFrom-Json`；读取失败或字段异常时必须保留记录，不得将路径不存在当作已恢复。

### A2. session.json UTF-8 读写不一致

- 位置：`helperScript.ps1` 第 935 行（旧会话扫描）和第 1155 行（ResumeWatchdog 读取会话元数据）；写入在第 1038–1041 行，经 `Write-AtomicJson`。
- `session.json` 包含 `LauncherPath`、`JavaPaths`、`ParentPath`、`ProtectedPaths` 等可能含中文/Unicode 的路径。
- `Get-Content -Raw` 默认读取可能破坏这些值。随后 `Get-SessionProcessState` 会使用其中的 Java 路径和父进程身份信息判断会话是否仍在运行；有些情况下可能无法正确归属进程，产生误恢复或过度等待风险。
- 判断：**确定的读写编码不一致；对进程判断的影响取决于路径编码和命令行是否能独立识别 Minecraft。**
- 下一版：上述 `session.json` 读取统一改为 UTF-8，并对必需字段做完整性校验。

### A3. QQ UserDataInfo.ini 扫描可能静默漏掉自定义目录

- 位置：`helperScript.ps1` 第 206–243 行，重点第 223–225 行。
- `Get-ChildItem -Recurse` 没有 `-Force`，默认不列出隐藏项目；使用 `-ErrorAction SilentlyContinue`，访问/枚举错误可能被压掉；每个根目录只保留前 50 个 `UserDataInfo.ini`。
- 影响：隐藏目录里的 INI、扫描结果超过 50 个、或部分目录访问失败时，实际 `UserDataSavePath` 可能未被发现。后续主流程仍可能正常继续，形成“没有报错但漏保护”的情况。
- 额外条件风险：第 229 行 `File.ReadAllText` 没有指定旧版 INI 编码。如果 INI 使用非 UTF-8 的 ANSI/GBK 编码，含中文路径的内容可能被错误解码，然后被判断为不存在。
- 判断：**扫描范围限制和错误被忽略是确定的；是否漏掉用户实际路径取决于目录属性、数量、权限和 INI 编码。**
- 下一版：扫描时加入隐藏项目；取消固定 50 个硬上限或把上限变为显式可见的“扫描不完整”；累计记录访问错误；任何扫描不完整都不能显示完整覆盖成功；确认 INI 编码策略并对中文路径做测试。

### A4. 没有任何 Tencent 目标时仍报告树保护验证成功

- 位置：`helperScript.ps1` 第 362–376 行，尤其第 368–376 行。
- 当四个默认根目录都不存在、`Find-QQSavePaths` 又没有发现自定义目录时，循环不会添加失败项，最后仍记录 `QQ/Tencent tree protection verified: roots=0 existing=0`。
- 影响：程序不会报错，但该次会话没有实际对任何 Tencent 目录添加 ACL。此前用户提供的 v17.13 实机日志确实出现过 `roots=0 existing=0`，所以这条代码路径至少在该次运行发生过；它没有证明该电脑存在未保护的 QQ 目录，但不能称为“已有目录保护已验证”。
- 下一版：零目标时记录 `NO_TARGETS_FOUND` 并显示明确警告；是否允许继续启动可由产品策略决定，但不能用 `COVERAGE_VERIFIED` 或“已保护”措辞。

### A5. JavaPaths 扫描错误被忽略，可能导致部分 Java 未进入防火墙白名单

- 位置：`GuardLauncher_v17.go` 第 3659–3730 行，调用处第 4601 行。
- `JavaPaths.txt` 读取失败被忽略；目录枚举 `WalkDir` 的错误在第 3711–3714 行直接返回 `nil`；扫描深度超过 5 层就停止；调用处还丢弃 `loadJavaPaths` 的 error。
- 严格模式只在 `len(javaPaths)==0` 时退出。如果已经找到一个 Java，但真正 Minecraft 使用的 Java 在不可访问/更深的目录中，程序仍继续，Helper 只会给已发现的 Java 建立允许规则，其余 Java 可能被默认出站 BLOCK。
- 判断：**静默忽略和深度上限是确定的；实际影响取决于当前启动器安装位置和 Java 运行时布局。**
- 下一版：返回“发现的路径 + 扫描警告”；配置文件读取失败不能静默当成没有配置；存在局部枚举错误时必须告知用户并在严格模式下决定是否中止。

## B. 中优先级 / 有条件的恢复和兼容风险

### B1. ProtectedPaths.txt 读取失败时静默回退默认目录

- 位置：`GuardLauncher_v17.go` 第 3732–3752 行。
- `os.ReadFile` 出错会直接返回四个默认路径，不会告知自定义路径配置未读取。
- 影响：用户在 `ProtectedPaths.txt` 中新增的目录会被静默忽略。默认目录仍会保护，因此不是完全无保护，但配置覆盖不完整。
- 下一版：如果文件存在但读取失败，应报告配置错误；只有文件确实不存在时才静默使用默认项。

### B2. Helper 与 Go 的 ACL 自检标准不一致

- 位置：Helper `Test-GuardProtectionEffective`：`helperScript.ps1` 第 263–273 行；Go `hasDenyForSID`：`GuardLauncher_v17.go` 第 4371–4389 行。
- Helper 接受继承而来的、当前 SID 有效的 FullControl Deny；Go 自检却排除所有 inherited ACE，只认显式 ACE。
- 影响：如果目标在运行前已经通过父目录继承到有效 Deny，Helper 认为保护成立，但 Go 最后自检可能判定失败并中止启动。这通常是误报，不表示实际 ACL 不生效。
- 判断：**确定的判定规则不一致；是否触发取决于用户目录的 ACL 继承结构。**
- 下一版：统一两侧的“有效保护”定义；仅在需要 Guard 自己添加 ACE 时才要求显式 ACE。

### B3. FQDN 动态地址对象删除失败后，恢复 ID 清单可能被清空

- 位置：`helperScript.ps1` 第 660–715 行；`watchdogScript.ps1` 第 260–306 行。
- 创建失败/降级重建时，代码会尝试删除动态对象；删除异常仅写日志，之后仍把 `$dynamic` / `$dyn` 置空并移除 `dynamic_keywords.json`。
- 影响：若系统对象删除失败，ID 可能不再被 journal 记录，后续无法自动重试清理。
- 安全边界：相关 Guard 防火墙规则在降级前已经先移除并检查 ActiveStore；残留动态对象本身不等于有放行规则，所以这主要是系统清理残项，不应误报为网络已经开放。
- 下一版：保留删除失败的 ID 到 journal，直到查询确认对象不存在才移除条目。

### B4. 审计策略 JSON 对旧版本地化 Setting 有编码兼容风险

- 位置：`powershellSessionLifecycleFunctions.ps1` 第 365–380 行，尤其第 372 行。
- `audit_policy.json` 由 UTF-8 JSON 写入；`Setting` 会保存本地化的 auditpol 显示文本，但读取时使用默认 `Get-Content`。新记录同时保存 ASCII 的 `OriginalKind`，通常可避免依赖本地化文本；旧记录若缺少 `OriginalKind`，回退解析 `Setting` 可能失败并保留恢复记录。
- 判断：**条件性旧记录兼容问题；新 Schema 有 `OriginalKind` 缓解。**
- 下一版：统一 UTF-8 读取；优先用稳定枚举字段，只有旧记录才解析本地化文本。

### B5. 旧版 Watchdog PID 定向检查使用 SilentlyContinue

- 位置：`helperScript.ps1` 第 955–969 行，尤其第 962 行。
- 定向 `Get-CimInstance Win32_Process -Filter ...` 查询失败会被 `SilentlyContinue` 变成空结果；随后可能记为“身份检查不确定”但继续进行其他陈旧会话判断。
- 后续完整进程快照通常会拒绝不确定的会话，但它不专门按旧 Watchdog PID 做归属判断，因此存在极窄的旧 Watchdog 仍在恢复时被并发恢复的窗口。
- 下一版：把“进程不存在”和“查询失败”区分；查询失败时保留旧会话，不并发恢复。

### B6. 主程序最终 ACL 基线快照忽略路径读取错误

- 位置：`GuardLauncher_v17.go` 第 4404–4412 行；调用第 4654–4655 行。
- `snapshotConfiguredACLs` 只把 `pathACL` 成功的目录加入基线，失败的目录直接跳过；最终恢复自检只检查快照中存在的条目。
- 影响：这份诊断基线可能不完整，最终摘要也不能证明每个配置路径 ACL 都恢复到原样。Helper 自己的 journal 恢复仍是主要恢复保证，但主程序最终比较会漏检。
- 下一版：返回 `map + errors`，逐项列出无法快照的路径；不能把缺失项默认为已恢复。

## C. 低优先级 / 体验和资源使用

### C1. Firewall notification feed 的 BOM 和全文件重复扫描

- 位置：`helperScript.ps1` 第 866–869 行；`GuardLauncher_v17.go` 第 4025–4068 行。
- PowerShell 5.1 使用 `Add-Content -Encoding UTF8`，新文件可能带 UTF-8 BOM；Go 端逐行 `json.Unmarshal` 没有剥除行首 BOM，因此第一条通知可能被忽略。
- Go 每 350ms 重读整个、且无轮转上限的 `notifications.ndjson`，并重新解析全部行；运行很久或 5157 事件很多时产生重复 IO/CPU。
- 下一版：固定 UTF-8 无 BOM 写入；Go 增量读取新字节，并对通知文件做轮转/上限。

### C2. 命令行直接传入的启动器路径缺少文件/扩展名检查

- 位置：`GuardLauncher_v17.go` 第 4539–4545 行。
- 直接传参时只做 `filepath.Abs` 和 `os.Stat`，没有拒绝目录或非 `.exe`；交互输入和保存路径则会检查。
- 影响：无效路径可能在完成管理员保护后才于 `cmd.Start` 失败，之后再依赖 Watchdog 回滚。
- 下一版：在 UAC/Apply 前统一检查 `!IsDir`、`.exe` 和可执行文件存在性。

### C3. AllowedDomains.txt 的无效行被静默跳过

- 位置：`GuardLauncher_v17.go` 第 3627–3656 行。
- `parseLine` 不接受的条目直接 `continue`；只要还有至少一个有效 endpoint，就不会提示被忽略的行。
- 影响：某个 Minecraft 服务端/认证地址写错时，该目标继续被 BLOCK，但用户看不到具体哪一行格式错误。不会扩大放行范围。
- 下一版：累计并输出无效行号/内容摘要，保持严格 BLOCK，不自动猜测或放宽规则。

### C4. 旧的用户 Allow 规则指纹发生变化时会保持禁用

- 位置：`helperScript.ps1` 第 516–543 行（Watchdog 对应 `watchdogScript.ps1` 第 431–456 行）。
- 这是有意的防覆盖策略：只重新启用名字唯一且指纹未变化的原规则。用户此前 v17.13 日志里已有一条 Windows 系统 Allow 因指纹变化而没有恢复。
- 这不是崩溃，但可能使一条 Windows 功能的 Allow 规则持续禁用。需要在下一次修复前确认其当前状态；不能仅因为“恢复步骤成功”就认为每一条原规则都已重新启用。

## D. 先前日志已经验证的范围（本轮不重复列为新缺陷）

- v17.13 实机日志：v17.7 Schema 10 旧会话的 firewall group 无匹配项处理成功；旧会话的动态对象步骤、用户 Allow 恢复步骤、Profile 恢复步骤均有成功记录；旧状态目录清理完成。
- v17.13 实机日志：旧会话 `Restore-ProfileState` 的 `GpoBoolean` 转换路径成功。
- v17.13 实机日志：Helper 报告 FAILED 时，主程序也返回失败，没有再误报“管理员保护组件完成”。
- 但该日志中的 ACL 树保护为 `roots=0 existing=0`，**没有验证任何实际 Tencent ACL 添加/恢复**。
- v17.14 的 `Write-AtomicText` 是刚刚修改的部分；当前没有 v17.14 Windows 实机日志确认连续 Replace 已通过，因此它仍属于待实机验证范围，不是本轮未修改代码审计的对象。

## E. 本轮检查执行结果与边界

- Go Windows x64 `go test`：编译通过，输出 `[no test files]`，没有实际 Go 单元测试。
- Go Windows x64 `go vet`：通过，无输出。
- PowerShell 脚本：已静态检查主要路径及命令参数/错误处理；当前环境没有 PowerShell，因此未运行 Windows PowerShell 5.1 parser 或真实 cmdlet。
- 未执行 UAC、NetSecurity、WFP、NTFS ACL、CIM/WMI 实机测试。
- **本轮没有修改任何程序文件，没有生成新 EXE 或新发布 ZIP。**

## F. 建议下一版集中修复顺序

1. ACL journal 和 session.json UTF-8 读取一致化；补 Unicode 路径恢复测试。
2. QQ 自定义目录扫描：hidden/错误/50 项限制/INI 编码；修正 `roots=0` 状态误报。
3. JavaPaths / ProtectedPaths 读取和递归扫描的错误显式化；不能静默接受不完整扫描。
4. ACL 继承 Deny 自检定义统一；最终基线快照失败要可见。
5. FQDN 动态对象 ID 清单只在确认删除后移除；旧 Watchdog PID 查询失败时保留恢复现场。
6. 通知文件 BOM/增量读取、启动器 CLI 文件校验、AllowedDomains 无效行提示。

建议下一版完成上述修改后，统一做 Windows PowerShell 5.1 的路径/编码/参数测试，再做一次最小真实会话：至少要有一个实际 Tencent 目录（含中文路径）、一条自定义 `UserDataSavePath`、一个 Java 运行时，验证 Apply、Watchdog 保持、Restore 三阶段。
