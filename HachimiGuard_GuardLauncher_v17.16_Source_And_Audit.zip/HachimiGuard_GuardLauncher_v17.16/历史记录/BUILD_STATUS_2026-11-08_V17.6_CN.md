# GuardLauncher v17.6 构建状态（2026-11-08）

- 基线：用户提供的 v17.5 第一半完整包。
- 版本：v17.6，Windows amd64，Console 子系统。
- Go：1.23.2。
- 构建命令：
  - `gofmt -w GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test ./GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o GuardLauncher_v17.6_x64.exe GuardLauncher_v17.go`
- 结果：全部命令退出码为 0；`go test` 输出 `[no test files]`。
- PE 检查：PE32+ Windows x86-64 Console executable。
- PowerShell 检查：自定义静态结构检查通过；环境未安装 powershell/pwsh，因此未执行 PowerShell 5.1 Parser。
- Windows 实机：未执行；真实 auditpol、NetSecurity、ActiveStore、NTFS ACL、UAC、文件锁与异常恢复仍待测试。

本构建不声称已通过 Windows 实机功能验证。编译通过仅证明 Go Windows 目标构建成功。
