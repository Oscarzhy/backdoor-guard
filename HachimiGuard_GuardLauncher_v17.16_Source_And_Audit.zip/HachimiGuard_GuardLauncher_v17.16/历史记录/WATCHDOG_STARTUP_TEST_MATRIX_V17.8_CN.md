# GuardLauncher v17.8 Watchdog 启动测试矩阵

| 场景 | 预期结果 | 验收依据 |
|---|---|---|
| UAC 同意，Bootstrap 正常完成 | `runElevated` 只等待 Bootstrap，及时返回 | 主程序继续到 Watchdog ready 检查；不等待 Minecraft/Watchdog 退出 |
| Watchdog 正常启动 | Helper 等到新鲜的 Starting/Monitoring 心跳后返回 | 心跳 Group、PID、创建时间与进程身份匹配 |
| Watchdog 脚本解析或配置解码失败 | Helper 握手失败，保留安全恢复状态并记录错误 | `*.watchdog.stderr.log` 或 startup log 有原因 |
| Watchdog 无法取得会话锁 | 不写就绪心跳，不误报健康 | startup log 显示 lease 申请失败；状态保留 |
| 首次心跳写入失败 | Helper 不认为 Watchdog 就绪 | stderr/startup/audit 记录原子写入错误 |
| Minecraft 在宽限期内启动 | Watchdog 继续监控，不提前恢复 | 心跳持续更新、保护状态不清理 |
| Minecraft 正常退出 | Watchdog 进入恢复并释放全局锁 | audit 记录恢复各阶段，状态目录仅在成功后删除 |
| UAC 被用户取消 | 不会出现空心跳目录被误认为就绪 | 外层返回启动/取消错误；每次运行日志保留 |

## 当前可执行的检查

- Go 格式、Windows amd64 交叉编译、`go vet`。
- 静态断言：UAC 外层不再包含 `Start-Process ... -Wait`；使用 `Wait-Process -InputObject $p`。
- 静态断言：Watchdog 子进程使用独立 Start-Process，不带 `-Wait`，并重定向 stdout/stderr。
- 静态断言：Helper、Watchdog、Go 主程序读取同一 AuditLogPath 衍生的诊断文件路径。

## 必须 Windows 实机验证

- UAC 凭据确认/取消。
- Bootstrap 进程退出与 Watchdog 子进程继续存活。
- `Wait-Process -InputObject` 是否在目标 Windows PowerShell 5.1 环境按预期工作。
- Watchdog 首次心跳是否在 Helper 返回之前写入。
- Minecraft 在启动宽限期内出现后，Watchdog 是否保持监控。
