# HachimiGuard GuardLauncher v17.11

## 本版本定位

v17.11 基于用户提供的 v17.10 完整源码包，针对 `Watchdog initial readiness failed` 且 Windows 报告 `StateDir` 不存在的问题，强化父进程存活判定与 Watchdog 清理前复核。它不把本次 OCR 日志直接认定为某一个已证实的删除者；当前修改针对源码中可确认的风险路径。

本版本保留 v17.10 的 parent-ready 文件握手、Helper/Watchdog 状态文件核对、旧会话保守恢复、网络白名单、Tencent ACL、5157 审计和恢复策略。配置文件 `AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 内容保持不变，Schema 仍为 11。

## 本次重要修改

1. **新增父进程内核存活租约。** 主程序在启动 UAC Helper 之前，按本次随机 Group 创建并持有 Windows `Local\HachimiGuardParentLease-<Group>` 命名 Mutex。租约由独立锁定的 OS 线程持有至 GuardLauncher 正常结束；进程异常退出时由 Windows 标记为 abandoned。
2. **Watchdog 不再只依赖 WMI 的单次进程快照。** 当 CIM 快照暂时没有 ParentPID 时，Watchdog 同时读取父进程 Mutex 状态，并通过 `System.Diagnostics.Process.GetProcessById` 复核 PID、退出状态和进程创建时间。Mutex 被持有、进程仍存在或进程状态无法确定时，均按“父进程仍可能存活”处理，不启动无目标清理。
3. **清理前增加最后一道复核。** 未收到 parent-ready 确认文件的会话，在孤儿恢复宽限期结束时重新检查确认文件与父进程状态；确认文件刚到达或父进程仍活着，会取消清理并继续监控。正常无目标退出也会重新核对父进程。
4. **补齐状态目录删除审计。** 除 Watchdog 主循环外，Apply 回滚、Helper 最终 Restore、Helper Watchdog 恢复、旧会话恢复和空孤儿目录清理现在也会在删除前记录 `*_DELETE_BEGIN`，成功后记录对应 `*_DELETE_COMPLETE`。Watchdog 的 `STATE_DIR_DELETE_BEGIN` 还记录 Group、父进程 PID、parent-ready 状态、是否见过游戏目标及最后一次可用的 Mutex/Process 探测结果；普通游戏结束路径没有 final snapshot 时会安全回退，不再解引用空对象。
5. **修正缺失目录观察计数。** `validateWatchdogSessionState` 通过 `%w` 包装底层文件错误，计数器改用 `errors.Is(err, os.ErrNotExist)` 检查错误链。此前 `观察次数=0` 不足以证明目录从未存在，可能只是包装错误没有被识别。
6. **继续统一当前版本号。** 当前源码 `appVersion`、`VERSION.txt`、新 README、构建脚本输出与 EXE 文件名统一为 v17.11。源码的历史版本识别表增加 `v17.11 = Schema 11`。发布包只包含 v17.11 当前程序，不重复携带 v17.10 或更早版本的 EXE。

## 对本次 StateDir 错误的判断

v17.10 Helper 的执行顺序是：取得全局会话锁、扫描旧会话、创建并加固本次 StateDir、写入 `session.json`、应用 ACL/防火墙、启动 Watchdog、验证 PID 与首次心跳，随后才返回成功。Go 主程序在 Helper 返回后继续检查状态文件并写入 parent-ready 确认。

因此，如果 Go 主程序已经收到 Helper 成功返回，而之后观察到 StateDir 不存在，源码中值得重点关注的是 Watchdog 是否在确认文件到达前把父进程误判为已退出并进入孤儿清理。v17.10 的该路径主要依赖 WMI 快照判断父进程；WMI 暂时遗漏父 PID 时存在误判窗口。v17.11 加入内核租约、独立进程探测与清理前最后复核来封闭这一窗口。

这仍是**源码层面的风险修复与高可信候选根因**，不是对用户这次机器上实际删除动作的运行时定案。若再次发生，新的 `STATE_DIR_DELETE_BEGIN` 和父进程状态日志可用于直接判断 Watchdog 是否执行过删除，以及当时它看到的父进程状态。

## ProgramData 与旧状态

位置仍为 `%ProgramData%\HachimiGuard\`。不要手动删除整个目录或任何非空 `session-*`。`active-session.lock` 文件可能在锁已释放后继续存在；`audit\` 历史日志通常不影响会话识别；只有确认恢复完成的状态目录才可删除。无法识别、元数据损坏或恢复不完整的旧会话会被保留并阻止新会话覆盖。

兼容版本列表请查看 `PROGRAMDATA_LEGACY_STATE_GUIDE_V17.11_CN.md`。v17.11 不改变 Schema 11，因此 v17.10 的 Schema 11 状态结构仍兼容。历史版本的 README、变更记录、审计结果与测试矩阵统一保存在 `历史记录/`，仅作为文档查阅，不是当前构建或运行依赖。

## 使用与验证

1. 将本包解压到独立目录。此整理包只提供 v17.11 当前程序；你已有的 v17.10 文件夹不会被修改。
2. 首次可运行 `--diagnose`；正常运行请使用 `GuardLauncher_v17.11_x64.exe`。
3. 验证主日志出现 `parent liveness mutex acquired before UAC`；若 Mutex 创建失败，会明确警告并退回独立进程探测，但这种降级仍需重点复核。
4. 管理员审计日志应包含 Watchdog 的 `ParentLeaseState`、`ParentProbeState` 变化；真正删除目录前应出现新的 `STATE_DIR_DELETE_BEGIN`。
5. 游戏退出后，确认防火墙、Firewall Profile、5157 审计和 Tencent ACL 均恢复，再检查会话目录清理结果。

## 验证边界

当前环境完成了 Go Windows/amd64 交叉编译、`go test`（源码无单元测试文件）、`go vet`、重复构建与静态断言。当前环境没有 Windows PowerShell 5.1、UAC、CIM/WMI、NTFS ACL、Windows Firewall ActiveStore 环境，因此尚未完成真实 Windows 运行测试。请先在可回滚的 Windows 环境验证，不能把交叉编译当作 PowerShell 或系统行为验证。
