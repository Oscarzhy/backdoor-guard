# v17.13 静态审计报告

## 已检查的缺陷

### 1. 旧 disabled_allows.json 解析失败

日志显示 `Restore-DisabledAllowsFrom` 在 `ConvertFrom-Json` 处失败，输入中嵌套的 `Fingerprint` JSON 字符串至少存在一个未正确转义的引号。v17.13 显式以 UTF-8 读取，并在首轮 JSON 解析失败时，只对 `Fingerprint` 字段值内部未转义的双引号做受限补转义。该字段必须仍是对象的最后一个属性且能找到唯一安全结束符；否则拒绝自动修复并保留状态目录。修复后仍需 JSON 解析成功。

Helper 与 Watchdog 的恢复及 journal 追加入口均使用相同读取函数。无法验证指纹的规则不会自动启用。

### 2. NetSecurity GpoBoolean 类型不兼容

日志显示将 `System.Boolean` 传给 `Set-NetFirewallProfile -Enabled` 时无法转换成 `Microsoft.PowerShell.Cmdletization.GeneratedTypes.NetSecurity.GpoBoolean`。v17.13 根据运行时命令元数据获取 Enabled 参数类型；若为枚举则执行 `Enum.Parse`，否则只传递允许的 `True`、`False` 或 `NotConfigured` 字符串。Helper 与 Watchdog 两条恢复路径均更新。

## 静态验证范围

- Go 格式化、Windows x64 交叉编译、`go test` 命令、`go vet`。
- 检查 Helper / Watchdog 两套脚本是否都使用 UTF-8 journal reader。
- 检查 Profile 恢复路径不再将 `[bool]::Parse(...)` 结果直接传入 `-Enabled`。
- 使用合成样例验证受限 Fingerprint 转义修复算法只插入缺失的字符串转义。

## 未验证事项

没有 Windows PowerShell 5.1、真实 `NetSecurity` 模块、UAC、CIM/WMI 和 NTFS 环境。必须在目标 Windows 11 设备上验证旧会话恢复结果、用户规则指纹比较、三个 Profile 的最终状态和恢复摘要。不能将本报告视为实机通过证明。
