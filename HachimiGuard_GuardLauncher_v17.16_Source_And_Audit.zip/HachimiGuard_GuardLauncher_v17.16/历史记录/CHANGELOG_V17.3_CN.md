# GuardLauncher v17.3 变更记录

v17.3 是 v17.2 的 FQDN 兼容性定向修复。本版不处理 Java 进程归属、5157 恢复、Watchdog 生命周期、并发启动、ACL 递归或 Allow 恢复记录原子性等其他审计项。

## FQDN 能力预检

- Helper 与 Watchdog 分别加入 `Get-FqdnCapability`，核对动态关键词创建/查询/删除命令及所需参数、`New-NetFirewallRule` 动态地址参数、Windows build、Defender Antivirus 启用状态/运行模式/实时保护/平台版本、Network Protection Block/Audit 状态。
- 对 Windows Server 检查相应 Network Protection Server 配置。
- 读取可观察到的 Edge/Chrome/Firefox DoH 策略及 Windows DNS Client DoH AutoUpgrade；已知启用时禁用动态 FQDN 能力。无法完整枚举的用户级/应用自带 DoH 会输出人工确认警告，不会修改用户设置。

## 安全降级与恢复

- 先独立建立明确解析出的静态 IP 规则，再尝试创建动态 FQDN 对象和规则。
- FQDN 对象建立失败时跳过对应域名；FQDN 规则创建失败时清除本轮 Guard 规则并重建静态 IP 规则，避免残留部分 FQDN Allow 规则。
- Watchdog 检测到 FQDN 前提不再满足，先移除 Guard 组规则，再保存 IP-only 活跃清单并重建静态规则。
- Helper、Watchdog 在零目标场景中均使用合法 JSON `[]`，并允许在 ActiveStore 仍为默认出站 BLOCK 且没有 Guard Allow 规则时保持 BLOCK-only。
- 动态关键词 ID 在创建对象之前写入会话记录，减少异常退出产生未登记对象的可能。
- FQDN 精确自检增加动态关键词 ID 与对象 Keyword/AutoResolve 的关联核对。
- 移除出站规则命令中无效/不适用的 `-PassThru`、`-EdgeTraversalPolicy` 使用；FQDN 规则采用明确的唯一 `-Name`，便于失败清理。

## 明确未改动

- Java 进程识别逻辑及进程生命周期判断。
- AllowedDomains.txt、ProtectedPaths.txt、JavaPaths.txt 的既有内容和用户允许范围。
- ACL 处理、5157 审计恢复、Allow 规则恢复、并发启动及 Watchdog 生命周期的其他设计。
