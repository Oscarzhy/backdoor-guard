# GuardLauncher v17.9 静态审计摘要

## 修改范围

仅修改 Java/Watchdog 会话生命周期中的 GuardLauncher 父进程判断、无目标启动宽限期，以及 Go 主程序 Watchdog ready 轮询中的 StateDir 暂时不可用处理。

## 定向检查

- ParentAlive 已纳入 no-target watchdog exit 决策。
- ParentAlive=true 且 targetSeen=false 时，不进入恢复/目录删除分支。
- ParentAlive=false 且 targetSeen=false 时，从确认父进程退出时重开 60 秒宽限期。
- targetSeen=true 时，仍按目标进程最后活动 30 秒决定恢复；父进程存活不阻止正常游戏退出恢复。
- WMI/CIM 查询失败继续保留保护并重试。
- parent exact path 优先；basename 兼容回退还必须同时满足 PID 相同、进程创建时间不晚于 SessionStartUtc、basename 完全相同。
- Go `waitForWatchdogReady` 在 Stat 失败时不再立即 return，而是记录观察次数并在就绪窗口内重试。
- StateDir 仍无法访问时，超时错误仍失败关闭，不会误报就绪。
- AllowedDomains/ProtectedPaths/JavaPaths/DefaultLauncherPath 与 v17.8 逐字节一致。

## 构建检查

Windows amd64 交叉编译、gofmt、go vet 通过。`go test` 编译检查输出 `[no test files]`，没有 Go 业务测试。

## 未验证

当前主机没有 Windows PowerShell 5.1、UAC、CIM、NTFS 和真实 Windows Firewall。因此 PowerShell Parser、ParentAlive 实际判断、UAC/Watchdog 文件锁交接和运行时恢复未实测。静态断言不等同于运行测试。
