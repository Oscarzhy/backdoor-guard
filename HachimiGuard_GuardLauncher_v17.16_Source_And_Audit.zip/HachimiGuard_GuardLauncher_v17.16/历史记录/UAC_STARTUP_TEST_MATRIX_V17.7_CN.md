# GuardLauncher v17.7 UAC 启动测试矩阵

## A. 普通成功路径

1. 使用普通 Windows 用户解压 v17.7 到含空格的用户目录。
2. 启动 EXE，选择 Minecraft Launcher。
3. 主日志应记录 `trampolineBase64` 和 `outerCommand` 实际长度；不得再出现 `UAC bootstrap command is too large (xxxxx Base64 characters)`。
4. 应弹出 UAC；同意后检查 Helper 诊断中的 `Staging ACL secured`、Bootstrap SHA-256、Helper SHA-256、Config SHA-256。
5. 应出现 `管理员保护组件执行完成` 和有效 Watchdog 心跳。
6. `%ProgramData%\HachimiGuard\audit` 下应存在本会话日志；主程序应记录 `session audit attached`。

## B. UAC 取消/启动前失败

1. 在 UAC 提示处选择否，或在隔离测试构建中模拟 UAC 启动前失败。
2. 详细失败原因必须出现在每次运行日志。
3. 若 Bootstrap 没有运行，允许出现一条 `session audit was not created...` 警告；不应连续出现多条 `shared lifecycle audit append failed`。
4. staging 临时目录应由调用用户正常清理。

## C. 完整性保护

仅在隔离测试副本中，在生成 staging 文件后、同意 UAC 前篡改 `bootstrap.ps1`：

1. trampoline 应先收紧 staging ACL。
2. Bootstrap SHA-256 应不匹配。
3. Helper 不得被执行。
4. trampoline 应尽力恢复调用用户对 staging 目录的清理权限。
5. 诊断中必须记录 hash mismatch 与权限恢复结果。

## D. 路径兼容

- 用户名含空格。
- 临时目录路径含空格。
- `ProgramData` 环境值含首尾空白（仅隔离测试环境模拟）。
- 审计路径日志使用 `%q` 样式，确认没有实际嵌入意外空格/控制字符。

## E. 必须收集的文件

- 程序目录 `logs\*.log`。
- `%ProgramData%\HachimiGuard\audit\session-*.log`（若 Bootstrap 创建成功）。
- 若 UAC 失败，收集主日志中的 staging 路径和失败详情；如临时诊断文件在失败后保留，先复制再结束测试。

注意：请勿在日常系统中故意损坏 ACL 或动态防火墙状态；完整性失败测试应在可恢复的虚拟机/测试账户中进行。
