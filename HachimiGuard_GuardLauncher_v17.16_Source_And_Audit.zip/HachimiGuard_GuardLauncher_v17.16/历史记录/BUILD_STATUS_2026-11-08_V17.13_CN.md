# v17.13 构建状态（2026-11-08）

- Windows x64 / amd64 / CGO_ENABLED=0 交叉编译：通过。
- `go test GuardLauncher_v17.go`：命令通过；Go 输出 `[no test files]`，当前源码没有 Go 单元测试文件。
- `go vet GuardLauncher_v17.go`：通过。
- EXE 第二次独立构建：字节完全一致。
- 21/21 项 v17.13 定向静态回归检查通过。
- 旧 Fingerprint 记录：用合成坏转义、中文名称样例验证了外层/内层 JSON 修复算法；未在目标机 PowerShell 5.1 上实测。
- NetSecurity `Set-NetFirewallProfile -Enabled`：按 Microsoft Learn 所列 `GpoBoolean` 类型实现运行时枚举转换；未在目标机执行真实 cmdlet 回滚。
- EXE SHA-256：`ac32615db3e351bc494e3c807c979835c1896e4a5b84d5749301759f469f8f50`

## 重要限制

本次 Windows x64 二进制在 Linux 环境交叉编译。未在 Windows PowerShell 5.1、UAC、真实 NetSecurity 防火墙对象、CIM/WMI 和 NTFS ACL 环境完成端到端测试。交叉编译、Go vet 和静态脚本检查不代表 Windows 运行时验证成功。
