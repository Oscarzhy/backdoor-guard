# Firewall Profile GpoBoolean 参数修复

`Set-NetFirewallProfile -Enabled` 的 NetSecurity 参数类型为 `GpoBoolean`，接受 `False`、`True` 和 `NotConfigured`。旧代码显式传入 `[bool]`，在目标 Windows PowerShell 5.1 环境中触发类型转换失败。

v17.13 将恢复基线中的值映射到当前 cmdlet 的枚举类型（若该版本暴露枚举）；对转换器类型则传递白名单内的 `True`、`False` 或 `NotConfigured` 字符串值。Helper `Restore-ProfileState` 和 Watchdog `Restore-Profiles` 都已更新。
