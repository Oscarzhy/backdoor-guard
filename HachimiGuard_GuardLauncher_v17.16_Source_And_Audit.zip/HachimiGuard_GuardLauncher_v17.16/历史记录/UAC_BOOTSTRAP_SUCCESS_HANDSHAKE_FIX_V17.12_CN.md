# UAC Bootstrap 成功握手修复说明（v17.12）

Bootstrap 会先调用 Helper。只有 Helper 正常返回 `HACHIMIGUARD_OK` 后，Bootstrap 才会写入本次诊断日志行 `[bootstrap] HELPER_RESULT=OK`；任何异常都会写 `[bootstrap] FAILED` 并生成错误文件。

v17.11 的 Go 端在外层 PowerShell 返回 0 时直接写 `UAC-SUCCESS`，没有再次校验 Bootstrap 结果。这允许出现“Bootstrap 日志 FAILED，但主程序继续显示管理员组件执行完成”的错误状态。

v17.12 新增 `waitForElevatedBootstrapResult`：

- 读取本次唯一 UAC staging 目录的诊断日志。
- 出现 `HELPER_RESULT=OK` 才返回成功。
- 出现 `FAILED` 或 Bootstrap 错误文件立即返回失败。
- 120 秒内没有明确成功标记也按失败处理。
- `UAC-SUCCESS` 只有显式标记校验通过后才写入。

这样 Helper 在 `Recover-StaleSessions` 中提前失败时，主程序会直接报告管理员组件启动失败，不会继续等待一个尚未创建的 Watchdog `StateDir`。
