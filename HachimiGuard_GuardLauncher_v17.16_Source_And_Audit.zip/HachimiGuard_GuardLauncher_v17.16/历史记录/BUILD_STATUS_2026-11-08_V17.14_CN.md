# v17.14 构建状态（2026-11-08）

- Windows x64 / amd64 / CGO_ENABLED=0 交叉编译：通过。
- `go test GuardLauncher_v17.go`：命令通过；Go 输出 `[no test files]`，当前源码没有 Go 单元测试文件。
- `go vet GuardLauncher_v17.go`：通过。
- 独立重复构建：EXE 字节完全一致。
- v17.14 定向源码静态断言：32/32 通过。
- 共享 Helper/Watchdog 原子写入函数：两个 `File.Replace` 调用均使用显式同目录 `.bak` 路径；没有 null backup 参数；失败诊断包含 source/destination/backup。
- 用户 Allow 写前日志顺序：Helper 和 Watchdog 均静态确认先持久化恢复记录，再调用 `Disable-NetFirewallRule`。
- 网络、保护路径、Java 路径、默认启动器四份配置 SHA-256 均与 v17.13 一致。
- 历史 Markdown：70 份，集中在 `历史记录/`；发布包只包含 v17.14 EXE。
- EXE SHA-256：`ff96eac20d18fad95c4c7d3b32d848139156807af38484d7f2b4b57f3ea70439`

## 重要限制

本次在 Linux 环境进行 Go Windows x64 交叉编译和静态检查。没有 Windows PowerShell 5.1、UAC、NTFS 和 NetSecurity 防火墙实机环境；未实际执行重复 `File.Replace`、备份失败故障注入或真实防火墙恢复。请在目标设备上确认同一个 journal 至少连续更新两次，并检查备份清理/保留行为。静态检查不等同于目标 Windows 运行时验证。
