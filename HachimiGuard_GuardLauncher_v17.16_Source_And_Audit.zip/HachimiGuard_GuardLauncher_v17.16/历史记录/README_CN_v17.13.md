# HachimiGuard GuardLauncher v17.13

本包只包含当前 v17.13 程序、源码、构建脚本、配置和当前版本说明。历史 Markdown 保存在 `历史记录/`，不包含旧版 EXE。

## 本版重点

- 修复旧版 `disabled_allows.json` 中嵌套 `Fingerprint` 字符串的兼容读取。
- 显式按 UTF-8 读取该日志，避免 Windows PowerShell 5.1 的默认代码页改变规则名称。
- 修复 Windows PowerShell 5.1 / NetSecurity `Set-NetFirewallProfile -Enabled` 的 `GpoBoolean` 参数类型问题。
- 对无法解析或指纹不匹配的用户 Allow 规则仍采取保守策略，不自动启用。
- 保留 v17.12 的无匹配防火墙组幂等清理、Bootstrap 成功握手和 Watchdog 父进程保护。

## 运行

在可信的本地目录解压后，运行 `GuardLauncher_v17.13_x64.exe`。启动失败时请保留 `%ProgramData%\HachimiGuard` 中的恢复记录与 `audit` 日志，不要直接删除整个目录。

## 当前限制

本次构建在 Linux 环境进行 Windows x64 交叉编译。Go 编译、`go test` 命令与 `go vet` 可通过静态验证；没有在 Windows PowerShell 5.1、UAC、NetSecurity 防火墙和真实旧会话状态下完成端到端实机验证。首次实机启动后应检查 `stale-disabled-user-allows-restore`、`stale-firewall-profiles-restore` 和最终恢复摘要。
