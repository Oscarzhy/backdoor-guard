# HachimiGuard GuardLauncher v17.14

本包只包含当前 v17.14 程序、源码、构建脚本、配置和当前版本说明。历史 Markdown 保存在 `历史记录/`，不包含旧版 EXE。

## 本版重点

- 修复 `Write-AtomicText` 在目标文件已存在时调用 `System.IO.File.Replace` 的失败路径：替换时使用同目录、随机名称的显式备份文件，不再把 `$null` 作为备份路径参数传入 PowerShell 5.1 的 .NET 方法绑定。
- 原子替换成功后才删除旧内容备份；失败时保留任何已生成的备份，并在错误日志中记录源文件、目标文件、备份文件路径及其存在状态。
- Helper 和 Watchdog 共用该持久化函数，因此 JSON journal、心跳及 Watchdog 状态文件更新都使用相同的写入修复。
- 保留“先持久化用户 Allow 恢复记录，再禁用规则”的写前日志顺序；若保存失败，不会执行接下来的规则禁用。
- 保留 v17.13 的 UTF-8 旧 Allow journal 读取、Fingerprint 兼容修复和 GpoBoolean Profile 恢复。

## 本次日志所确认的前序行为

- v17.7 遗留会话的六类恢复步骤全部成功，旧状态目录随后被删除。
- 新 v17.13 会话目录已成功创建；失败发生在后续重复更新 `disabled_allows.json` 时。
- Helper 执行回滚并报告失败，主程序正确返回 `exitCode=5`，没有继续等待 Watchdog。

## 运行

在可信的本地目录解压后，运行 `GuardLauncher_v17.14_x64.exe`。启动失败时请保留 `%ProgramData%\HachimiGuard` 中的恢复记录和 `audit` 日志，不要直接删除整个目录。

## 验证限制

本版在 Linux 环境进行 Windows x64 交叉编译和源码静态检查。当前环境没有 Windows PowerShell 5.1、UAC、NTFS 和 NetSecurity 防火墙实机，因而没有完成目标设备上的重复 journal 替换及真实防火墙恢复测试。
