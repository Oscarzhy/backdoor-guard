# GuardLauncher v17.7 变更记录

基线：v17.6 Recovery/Audit Complete。此次只针对用户提供的真实启动日志修复 UAC 提权启动长度和审计路径初始化时序，不改动原有网络白名单、FQDN、Java 识别、会话锁、Watchdog、5157、ACL 与恢复策略。

## 1. UAC Bootstrap 命令长度

- v17.6 把完整 Bootstrap 脚本 UTF-16LE Base64 后放入 `Start-Process -EncodedCommand`，实际记录为 26,540 字符，超过本地 26,000 字符拒绝阈值。
- v17.7 把完整 Bootstrap 存为临时 `bootstrap.ps1`；命令行只携带小型 UTF-16LE Base64 trampoline。
- trampoline 先检查 staging 目录类型及 reparse 状态，收紧 staging 目录和文件 ACL，然后验证 Bootstrap SHA-256，最后才运行 Bootstrap。
- helper、config 仍保留各自 SHA-256 校验；Bootstrap、Helper、Watchdog 和 trampoline 都执行本机 PowerShell Parser 预检。
- 新增实际命令长度记录和合理上限：trampoline Base64 14,000 字符、outer command 16,000 UTF-16 单元。超限仍拒绝启动，避免越过 Windows 命令行限制。

## 2. 会话审计文件初始化时序

- 原错误分支在 UAC 启动失败后仍无条件登记 ProgramData 审计路径；当失败发生在 Bootstrap 启动前，目录/文件从未创建，随后每条主程序日志都尝试写入不存在的路径。
- `setSessionAuditPath` 现在必须先确认目标文件存在、是普通文件且当前调用用户能够追加，才绑定共享审计路径。
- 若管理员 Bootstrap 尚未创建该文件，错误只写入每次运行日志，并记录一次明确警告；不再重复触发共享审计路径不存在的次生错误。
- 成功 Apply 后仍验证审计文件是否已经创建并可写；若失败，保留每次运行日志作为诊断回退。
- `ProgramData` 取值去首尾空格、验证绝对路径；路径诊断使用 `%q` 格式，避免空格/控制字符显示歧义。

## 3. 保持不变

- 不改变 `AllowedDomains.txt`、`JavaPaths.txt`、`ProtectedPaths.txt` 的规则范围。
- 不修改 hosts，不新增服务、计划任务或后台常驻机制。
- 保留 v17.3 FQDN 兼容性、v17.4 Java 归属识别、v17.5 会话锁/Watchdog 心跳、v17.6 5157/原子恢复记录/ACL 子目录覆盖。
- 不把源码交叉编译结果宣称为 Windows 实机验证。
