# v17.15 构建状态（2026-11-08）

- 目标：Windows x64 / amd64 / CGO_ENABLED=0。
- `gofmt`：通过。
- `go test GuardLauncher_v17.go`：命令通过；输出 `[no test files]`，当前源码没有 Go 单元测试文件。
- `go vet GuardLauncher_v17.go`：通过。
- 独立重复构建：EXE 字节完全一致。
- ACL manifest、逐条 ACL journal、旧 NDJSON、两处 PowerShell session.json 读取及 Go session.json UTF-8 校验：**28/28 定向静态断言通过**。
- UTF-8 CJK 路径、UTF-8 BOM、非法 UTF-8、UTF-16 LE/BE BOM、UTF-32 BE BOM：**6 组字节边界模型测试通过**。此项不是 PowerShell/.NET 实机测试。
- `AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 与 v17.14 的 SHA-256 完全一致。
- 历史 Markdown 全部保留并归档在 `历史记录/`；发布包只包含 v17.15 EXE。

## 实机验证限制

当前构建环境未安装 Windows PowerShell 5.1，也无法访问 Windows NTFS ACL 和 NetSecurity 防火墙。因而尚未在目标设备验证严格 UTF8Encoding 与实际 ACL 恢复。此报告只记录源码/编译/静态检查结果，不宣称 Windows 实机通过。

## 交接文档补充（仅文档整理）

- 新增根目录优先阅读文件 `00_优先阅读_兼容性与启动中止问题复筛_v17.15.md`。
- 新增根目录 `01_AI交接_项目初衷功能与用户要求.md`，用于全新 AI 对话接手。
- 更新 README 的必读顺序。
- **本次仅增加/更新 Markdown 和文件哈希清单；没有修改 Go/PowerShell 源码、配置或 EXE，没有产生新的程序版本。**
