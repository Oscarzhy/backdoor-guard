# GuardLauncher v17.4 变更记录

v17.4 是以 v17.3 FQDN 兼容性修复版为基线的单批次定向更新。本版只处理 Minecraft Java 进程识别与会话归属判断；不改动 FQDN 逻辑、网络白名单、Tencent 路径、ACL 策略、5157 恢复或并发锁设计。

## 进程识别

- 新增共享 PowerShell 进程归属函数，Helper、Watchdog 和 Go 主程序使用同一套判断规则。
- 通过 `Win32_Process` 同一快照核对 PID、父 PID、创建时间、可执行文件路径和命令行。
- 使用 GuardLauncher 自身 PID + `ParentPath` 校验父进程；使用精确 `LauncherPath` 和本会话开始时间识别启动器。
- 进程树只从经过身份核对的 GuardLauncher/启动器进程根节点构建，并验证子进程创建时间不早于父进程，避免 PID 重用错误关联。
- 识别 Vanilla Minecraft 主类、Legacy LaunchWrapper、Fabric、Forge、NeoForge、Quilt，以及 Minecraft 游戏目录/资源目录/用户身份参数组合。
- 对未登记在 `JavaPaths.txt` 的自定义 Java Runtime，使用 Minecraft 命令行参数进行识别；会话开始后启动的其他 Minecraft Java 实例也会维持全局保护，普通 IDE/Gradle 不会仅因 Java 路径相同而匹配。
- 对已登记 Java 路径，仅当进程属于本会话启动器/父进程树时才作为会话 Java 进程；不会再全局匹配同一路径下的所有 Java 进程。
- 启动前检查仅拦截命令行可归属到 Minecraft 的 Java 进程，不再因为 IDE/Gradle 使用相同 Java 路径而拒绝启动。
- v17.3 遗留会话兼容：当旧 `session.json` 缺少 `ParentPath` 时，使用 GuardLauncher 可执行文件名回退识别父进程。
- Watchdog 进程快照查询失败或返回空快照时，记录日志并保持保护重试；主程序查询失败时保守地按受保护 Java 仍存活处理。
- Watchdog 日志记录被识别 Java 进程的 PID、UTC 创建时间和可执行文件路径，进程退出时记录状态变化。

## 未处理项目

本版没有修改全局互斥锁、Watchdog 心跳/生命周期、5157 审计恢复、Allow 恢复记录原子性、Tencent ACL 子目录继承，也未修改 FQDN 兼容性逻辑。以上仍按后续批次计划独立处理。
