# GuardLauncher v17.8 复核结论

- 本版修复了 v17.7 UAC 外层 `Start-Process -Wait` 会等待长期 Watchdog 子进程的问题。
- 使用 `Wait-Process -InputObject` 只等待管理员 Bootstrap 进程，避免 UAC Apply 调用被 Watchdog 生命周期阻塞。
- 新增 Watchdog 独立启动诊断文件，且保存在持久化审计目录。
- 未改动网络白名单、Tencent 保护路径、5157/ACL 恢复策略或 FQDN 降级策略。
- Go Windows amd64 编译和静态断言通过；PowerShell 5.1 Parser、UAC 和真实 Watchdog 生命周期仍必须在 Windows 实机验证。

结论：v17.8 是针对本次实机启动错误的修复候选版，不应在 Windows 实测前标记为最终稳定版。
