# GuardLauncher v17.6 持久化日志说明

## 1. 日志位置

- 普通程序日志：程序目录 `logs`；目录不可写时回退 `%LOCALAPPDATA%\HachimiGuard\logs`。
- 会话审计日志：`%ProgramData%\HachimiGuard\audit\session-<会话ID>.log`。
- 应急日志：`%ProgramData%\HachimiGuard\lifecycle-emergency.log` 或会话目录 `emergency-lifecycle.log`（主审计文件不可写时尽力写入）。
- 恢复状态文件：`%ProgramData%\HachimiGuard\session-*`。

## 2. 写入一致性

主程序 Go 日志与 PowerShell Helper/Watchdog 通过同一路径派生的 Windows 命名 Mutex 互斥追加。每条日志 UTF-8 写入后调用 `Flush(true)`；Go 同时调用 `Sync()`。会话组与 UTC 时间戳作为每条记录的前缀。

恢复状态 JSON/文本使用同目录唯一临时文件，写入并 `Flush(true)` 后执行原子替换或移动。ACL 每个对象有独立写前 JSON 记录；manifest 用 RecordCount 检查提交数量。

## 3. 事件范围

- Startup / config / UAC / Helper Apply。
- 会话锁等待、取得、交接、释放。
- Watchdog 启动、PID/创建时间、heartbeat sequence/status。
- 防火墙 Profile/规则建立和恢复结果。
- 5157 原始状态、Guard 预期状态、外部变更检测和恢复核验。
- ACL 扫描对象数量、覆盖统计、reparse point、失败路径和堆栈。
- 恢复各步骤 START/SUCCESS/FAILURE/DEFERRED、重试次数与最终 Summary。
- Go Panic 堆栈、PowerShell Exception.ToString 与 ScriptStackTrace。

## 4. 常见关键字

- `[restore-step] START`：恢复步骤开始。
- `[restore-step] SUCCESS`：该步骤完成并返回。
- `[restore-step] FAILURE`：该步骤失败，随后应保留会话状态。
- `[restore-step] DEFERRED`：因 Guard 防火墙规则仍在而延后可能放宽网络策略的恢复步骤。
- `[restore-summary]`：一组步骤的总数与失败数。
- `[acl-tree] COVERAGE_VERIFIED`：该根目录枚举完成，且未发现被跳过的 reparse point。
- `[acl-tree] COVERAGE_INCOMPLETE`：发现 reparse point，或无法宣称覆盖完整；当前 Helper 会失败关闭。
- `[acl-journal]`：写前日志 manifest、RecordCount、记录损坏/丢失或提交窗口。
- `[watchdog] RecoveryFailed` / heartbeat status：Watchdog 恢复尝试未完成，保留会话并重试。

## 5. 物理限制

软件无法保证突然断电、内核崩溃、存储设备故障或外部强制终止瞬间的最后一条日志必然写入介质。Flush/Sync 只能降低风险。状态文件的原子替换和下一次启动的 stale-session recovery 用于检测并恢复未完成操作。
