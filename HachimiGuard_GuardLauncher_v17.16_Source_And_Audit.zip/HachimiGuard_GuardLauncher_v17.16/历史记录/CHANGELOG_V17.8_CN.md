# GuardLauncher v17.8 变更记录

基线：v17.7 UAC/Audit Path Fix。此次只修复用户实测的 `Watchdog initial readiness failed`：主程序在 UAC Helper 返回后无法读取 `watchdog.heartbeat.json`。本版不改变网络白名单、FQDN 能力、Minecraft Java 进程识别、会话互斥策略、5157、ACL 或恢复规则。

## 1. 修复 UAC 等待整个进程树的问题

- v17.7 外层 UAC PowerShell 使用 `Start-Process -Wait`。
- Microsoft Learn 对 Windows PowerShell 5.1 的说明明确指出：`Start-Process -Wait` 等待指定进程及其所有后代进程；`Wait-Process` 则只等待指定的进程对象/进程。
- Helper 将 Watchdog 作为 Bootstrap 的子进程启动，Watchdog 本身需要在 Minecraft 会话期间持续运行。外层等待整个进程树会把 Bootstrap 完成与 Watchdog 退出绑定起来。
- v17.8 改为 `Start-Process -PassThru`，再以 `Wait-Process -InputObject $p` 精确等待管理员 Bootstrap 进程；随后刷新 Process 对象并读取真实 ExitCode。
- Watchdog 子进程依旧由 Helper 通过心跳/进程身份握手确认；不降低就绪校验要求，也不在未确认时放行。

## 2. Watchdog 启动诊断

- 子进程 stdout/stderr 分别重定向到会话专属审计诊断文件。
- 启动阶段日志记录配置解析、脚本入口、锁申请、锁取得和第一次心跳写入。
- 诊断文件存放在 `%ProgramData%\HachimiGuard\audit`，与可被 Watchdog 清理的 `session-*` 状态目录分离。
- Helper 在启动握手失败时收集日志尾部、stderr、stdout 和进程退出码。
- Go 主程序的独立 Watchdog ready 检查失败时，也会读取同一组诊断文件；每个文件最多读取末尾 4 KiB，避免错误消息无限增长。

## 3. 保持不变

- 不改变 AllowedDomains.txt、JavaPaths.txt、ProtectedPaths.txt。
- 不改变默认出站 BLOCK、静态 IP/FQDN 的放行边界或 FQDN 降级规则。
- 不改变 Helper/Watchdog 全局会话锁与心跳结构，只修正 UAC 父进程等待对象。
- 不改动 5157、Allow 规则、Profile、Tencent ACL 和原子恢复记录。
- 继续保留 v17.7 的 SHA-256 staging 校验与审计路径绑定规则。
