# v17.14 静态审计报告

## 本次问题的日志证据

- v17.7 历史会话六类恢复步骤全部完成，旧 StateDir 被正常清理。
- 新 v17.13 StateDir 创建、session.json、profiles.json 和初始 disabled_allows.json 写入成功。
- 一条用户宽泛 Outbound Allow 被成功禁用。之后再次更新 `disabled_allows.json` 时，`System.IO.File.Replace` 报“路径的形式不合法”。
- Helper 随后执行防火墙及 ACL 回滚，恢复步骤均报告成功，删除本次 StateDir，并由 Bootstrap 明确写出 FAILED；Go 主程序正确返回 exitCode=5。
- 因此本次错误不是 Watchdog readiness 超时；它发生在 Helper Apply 期间的重复 journal 原子替换。

## v17.14 修复

- 共享 `Write-AtomicText` 对已存在目标文件使用同目录唯一 `.bak` 路径。
- `File.Replace` 参数显式转换为 String、String、String、Boolean。
- 替换后验证目标文件存在，再尝试删除旧内容备份。
- 备份删除失败只记录警告，不把已提交的 journal 误报成失败。
- 替换失败时记录源、目标、备份路径和存在状态；保留仍存在的备份，不使用非原子覆盖回退。
- Helper 和 Watchdog 通过相同的 `powershellSessionLifecycleFunctions` 注入该实现。
- v17.14 Schema 11 被加入后续旧会话兼容映射。

## 静态验证

- 32/32 项针对性静态断言通过。
- Go 格式化、Windows amd64 / CGO 关闭交叉编译通过。
- `go test GuardLauncher_v17.go` 命令通过，Go 输出 `[no test files]`；当前项目尚无 Go 单元测试文件。
- `go vet GuardLauncher_v17.go` 通过。
- 两次独立 Windows x64 构建的 EXE 字节完全一致。
- 四份网络、保护路径、Java 与默认启动器配置 SHA-256 均与 v17.13 一致。
- ZIP 完整性和包内所有文件 SHA-256 清单通过。

## 未验证事项

当前构建环境不是 Windows，未执行 Windows PowerShell 5.1 的真实 `System.IO.File.Replace`、NTFS、UAC、NetSecurity 防火墙和真实 Watchdog 流程。v17.14 需要在目标 Windows 11 设备上对同一个 JSON 文件连续写入至少两次，并检查 `.bak` 清理和失败保留行为。静态检查不能替代实机验证。
