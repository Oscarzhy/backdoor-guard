# GuardLauncher v17.4 Java 进程识别测试矩阵

本文件用于 Windows 实机验证。本构建容器没有 Windows PowerShell，以下场景尚未执行。

| 场景 | 预期结果 |
|---|---|
| Vanilla Minecraft，主类 `net.minecraft.client.main.Main` | 识别为本会话 Minecraft Java |
| Fabric，`net.fabricmc.loader.impl.launch.knot.KnotClient` | 识别 |
| Forge/NeoForge，`cpw.mods.modlauncher.Launcher` 或对应 `--launchTarget` | 识别 |
| Quilt，`org.quiltmc.loader.impl.launch.knot.KnotClient` | 识别 |
| 命令行含 `--gameDir`、`--assetsDir`/`--assetIndex` 和身份/版本参数组合 | 识别 |
| IDE 使用同一个 `JavaPaths.txt` 中的 java.exe，但命令行无 Minecraft 标记、进程不属于本会话启动器树 | 不识别，不阻止恢复或新启动 |
| Gradle Daemon 在会话开始后启动，使用同一 Java Runtime | 不识别，不阻止恢复 |
| 自定义 Java 路径不在 `JavaPaths.txt`，但命令行包含标准 Minecraft/Fabric/Forge/Quilt 标记 | 识别 |
| 自定义 Java 路径在 `JavaPaths.txt`，且为本会话启动器的后代进程 | 识别 |
| 无 Minecraft 标记、非启动器后代、仅进程名为 javaw.exe | 不识别 |
| 模拟 PID 重用：子进程创建时间早于当前同 PID 父进程 | 不建立父子归属关系 |
| WMI 查询失败 | Watchdog 保持保护并重试；主监控不得把失败当作“Java 已退出” |
| v17.3 遗留 session.json 缺少 ParentPath | 按 GuardLauncher 文件名回退，继续识别启动器/MC Java |
| Minecraft 退出但 IDE/Gradle 继续运行 | IDE/Gradle 不延长 Minecraft 会话恢复等待 |
| 当前会话期间另一个独立 Minecraft 实例启动 | 该实例的标准 Minecraft 命令行标记会保守地维持全局保护，直至所有匹配实例退出 |
| WMI 查询成功但返回空快照 | 作为无法安全判断处理，不得触发退出恢复 |

建议实际测试启动器：官方 Minecraft Launcher、一个基于 Fabric 的第三方启动器，以及一个 Forge/NeoForge 或 Quilt 启动器。测试前保留 v17.3，使用独立目录运行 v17.4，并检查 `GuardLauncher.log` 与管理员审计日志中的 `[process]` 记录。
