# Watchdog 父进程租约与 StateDir 清理测试矩阵（v17.11）

以下是待执行的 Windows 实机测试场景；本源码包的静态构建不代表这些运行测试已经通过。

| 场景 | 操作/条件 | 预期行为 |
|---|---|---|
| 正常启动 | GuardLauncher 先创建 Mutex，再启动 UAC Helper 与 Watchdog | Watchdog 报告 `ParentLeaseState=Held` 或父进程由 CIM 识别为存活；收到 parent-ready 文件前不清理 |
| WMI 瞬时漏报 | 在测试环境让 CIM 快照暂时没有 ParentPID，但保持 GuardLauncher 活着 | Mutex `Held` 应使 `ParentAlive=true`；保护与心跳持续 |
| 直接进程探测兜底 | 仅在隔离测试环境模拟 Mutex 不可用，而父进程仍存在 | `Alive` / `UnknownAlive` / `Unknown` 不得启动清理 |
| 父进程正常退出 | 父进程句柄结束，Mutex 进入 `Abandoned`，PID 不存在 | 进入设定宽限期，最终复核确认退出后才可恢复 |
| PID 重用 | 测试进程取得相同 PID 但创建时间晚于 SessionStartUtc | 识别为 `ReusedPID`，不能把新进程当成旧 GuardLauncher |
| parent-ready 最后时刻到达 | 孤儿宽限期末尾前写入正确确认文件 | 最终闸门重新读取确认文件并继续监控，不清理 |
| 正常无目标退出闸门 | 主程序先退出且没有游戏目标 | 宽限期到期后再次核验父进程，仍存活时取消清理 |
| 已见游戏目标退出 | Java 与启动器退出，静默期达到既定条件 | 按目标生命周期恢复；删除审计日志应正确回退到最近快照，不因空值错误中断 |
| WMI 不可用 | CIM 抛出异常/空快照 | Watchdog 保留保护并重试，不推断游戏退出 |
| 恢复步骤失败 | 防火墙/ACL 恢复任一步失败 | 保留会话目录和恢复资料，输出持久化错误 |
| 旧版会话 | v17.10 Schema 11、v17.9 Schema 10 等现存会话 | 按版本映射执行兼容检查；不需要旧版已不存在的 Mutex |
| 错误计数 | `os.Stat` 错误经 `%w` 包装为 `os.ErrNotExist` | `errors.Is` 能正确递增缺失目录观察计数 |

## 需要采集的结果

- 主日志中的 `parent liveness mutex acquired before UAC`。
- Watchdog 持久化日志中的父进程状态变化及 `ParentLeaseState` / `ParentProbeState`。
- `STATE_DIR_DELETE_BEGIN` 是否出现，以及当时的 `parentReadyAcknowledged`、`targetSeen`、PID 和父进程状态。
- 进程正常退出与强制结束两种情况下，防火墙 Profile、规则、5157 和 ACL 的最终状态。
