# v17.15 UTF-8 读取测试矩阵

## 静态调用点

| 数据 | 读取位置 | v17.15 处理 |
|---|---|---|
| `acl_journal_manifest.json` | 初始化、完整性检查、写前日志更新 | `Read-GuardUtf8Text` |
| `acl_journal/*.json` | 逐条 ACL 恢复记录 | `Read-GuardUtf8Text` |
| `acl_state.ndjson` | 旧版逐行 ACL 记录 | 严格 UTF-8 解码后按行解析 |
| 旧 `session.json` | `Recover-StaleSessions` | `Read-GuardUtf8Text` |
| 当前 `session.json` | `ResumeWatchdog` | `Read-GuardUtf8Text` |
| 当前 `session.json` | Go Watchdog 身份校验 | 去除可选 UTF-8 BOM、验证 `utf8.Valid`、再解析 JSON |

`Read-GuardUtf8Text` 位于 Helper/Watchdog 共用的持久化函数中，因此 ACL 记录的相同解码规则同时作用于两条恢复路径。

## 字节边界用例

| 输入 | 预期 | 模型结果 |
|---|---|---|
| UTF-8 中文目录路径，无 BOM | 正常解码 | 通过 |
| UTF-8 中文目录路径，带 UTF-8 BOM | 去 BOM 后正常解码 | 通过 |
| 非法 UTF-8 字节序列 | 明确失败 | 通过 |
| UTF-16 LE BOM | 拒绝猜测编码 | 通过 |
| UTF-16 BE BOM | 拒绝猜测编码 | 通过 |
| UTF-32 BE BOM | 拒绝猜测编码 | 通过 |

上述字节模型由 Python 严格 UTF-8 解码器验证；它验证预期字节边界，不等于 Windows PowerShell 5.1/.NET 实机测试。

## 安全失败行为

编码不合法或 JSON 解析失败时，恢复流程应当抛出错误并保留原会话目录/journal。不得回退到系统代码页，也不得把解析失败的路径当成“目标不存在”或“无需恢复”。
