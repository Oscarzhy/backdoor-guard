# GuardLauncher v17.2 变更记录

v17.2 在 v17.1 基础上做恢复路径及启动流程修复，未扩大网络允许目标或 Tencent 保护路径范围。

## 管理员启动与 Watchdog

- 修复 UAC 启动命令嵌套 Base64 导致 `CreateProcess` 命令行超过 Windows 长度限制的问题。Bootstrap 仍以 UTF-16LE Base64 传递给 UAC 子进程；外层启动命令改为普通 `-Command`，不再二次编码。
- 增加 Bootstrap Base64 长度与外层 UTF-16 命令长度的启动前保护阈值，并记录实际长度，避免未来脚本增长后再次以不明确的进程创建错误失败。
- Watchdog 先前以 `-EncodedCommand` 把约 31 KB 的脚本文本继续编码并传给新 PowerShell 进程，可能产生更长的命令行。现改为由已校验的 Helper 将脚本写入 ACL 已保护的当前会话目录，再以 `-File` 启动；脚本使用 UTF-8 BOM。

## 恢复逻辑

- Stale-session recovery 现在检查旧会话 `SessionStartUtc` 之后启动的所有 `java.exe` / `javaw.exe`，不再只检查旧配置中列出的 Java 路径。
- 被临时禁用的出站 Allow 规则在禁用前保存过滤条件、程序/包、端口、地址、服务、接口、安全过滤器、规则身份及策略来源指纹。
- Helper、Watchdog、正常清理和 stale-session recovery 共用同等的指纹恢复判断：规则仍禁用且指纹不变才重新启用；已删除、已启用、名称不唯一或内容已变化的规则不会被盲目重建/启用。
- 旧版本没有指纹的禁用规则恢复记录会被记录并跳过自动启用，避免用不完整的旧数据覆盖后续更改。
- stale-session 5157 审计恢复改用正常恢复函数的状态读取流程，仅在当前 Failure 审核确实仍启用时执行关闭，并验证关闭结果。

## 版本

- 配置 Schema：6 → 7。
- 版本显示、控制台标题及构建产物名称更新为 v17.2。
