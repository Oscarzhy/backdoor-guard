# v17.9 Watchdog 父进程生命周期测试矩阵

| 场景 | 预期结果 | 检查重点 |
|---|---|---|
| UAC 完成、主程序仍活着、游戏启动器尚未出现 | Watchdog 持续 Monitoring，不删除状态目录 | 心跳 Message 包含 parent alive；无 cleanup marker |
| 主程序等待启动器超过 60 秒 | 保护持续，不因旧 60 秒启动宽限期自动恢复 | `ParentAlive=true` 时不进入 no-target recovery |
| 主程序存活期间启动 Minecraft | Watchdog 识别 launcher/Java，开始目标进程监控 | targetSeen 转为 true |
| Minecraft 正常退出但 GuardLauncher 仍在运行 | 仍按目标进程 30 秒交接逻辑恢复 | ParentAlive 不会无限阻止已出现目标的正常恢复 |
| 游戏尚未启动，用户关闭 GuardLauncher | 从父进程确认退出后开始 60 秒宽限期 | 日志有 parent exit 与 deadline 时间 |
| WMI/CIM 暂时查询失败 | 不恢复、不删状态目录 | `processState=null` 分支持续保留保护 |
| ParentPath 完整路径匹配 | ParentAlive=true | 精确路径比较成功 |
| ParentPath 表示不同但 PID/创建时间/basename 相同 | 兼容回退，记录 ParentPathMatchedByName | 不以进程名单独匹配 |
| ParentPID 被会话后进程复用 | ParentAlive=false | 创建时间晚于 SessionStartUtc 时拒绝回退 |
| StateDir 在 Go 就绪轮询期间短暂不可用 | 继续轮询至心跳验证或超时 | 不在第一次 Stat 错误时立即失败 |
| StateDir 在整个就绪窗口内均不存在 | 失败关闭并输出观察次数、最后错误和 Watchdog 诊断 | 不误报 Watchdog 就绪 |

## 当前环境可做

- Go Windows amd64 交叉编译、`go vet`、`gofmt`。
- 源码定向断言：no-target 分支必须检查 ParentAlive；targetSeen 分支不使用 ParentAlive 阻止退出；WMI 查询失败保持继续；就绪检查不在第一次 Stat 失败时 return。
- 配置与白名单文件相对 v17.8 未变化。

## 必须在 Windows 实机做

- PowerShell 5.1 Parser。
- CIM `Win32_Process` 的 ParentPID、CreationDate、ExecutablePath 实际格式。
- UAC/Bootstrap/Watchdog 文件锁交接。
- 延迟启动和正常退出的真实时序。
