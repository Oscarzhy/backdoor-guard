# HachimiGuard GuardLauncher v17.10

## 本版本定位

v17.10 基于 v17.9，针对 Watchdog 初始就绪失败、`session-*` 状态目录在启动交接期间消失、旧版 ProgramData 遗留状态和启动版本横幅错误进行修复。

本版本保留原有网络白名单、Tencent 默认保护目录、QQ `UserDataSavePath` 扫描目标、Java 进程识别规则、5157 审计和恢复策略。配置文件内容未改变。

## 主要修复

1. **主程序与 Watchdog 增加明确的就绪交接。** Helper 在持久化审计目录预创建一个由调用用户可写、但不能由其创建/删除的确认文件。Watchdog 在收到包含本次 Group、ParentPID、随机 Token 和 ReadyUtc 的有效确认之前，不允许按常规生命周期清理会话目录。
2. **Helper 与主程序双向核对状态文件。** Helper 启动 Watchdog 后必须验证 `session.json`、`watchdog.pid` 和首次心跳均存在，并且 PID/Group 一致。主程序随后核对 `session.json` 中的 Schema、Version、Group、ParentPID、StateDir、随机 Token，以及 `watchdog.pid` 与心跳 PID。
3. **修正 Watchdog PID 文件路径写入。** 之前的 v17.10 构建草稿曾将多个子路径错误传给同一个 `Join-Path`；正式源码现只生成 `watchdog.pid` 的单一路径，写入后立即读回验证。该错误已在正式交付构建前修正。
4. **统一版本显示。** 启动日志、控制台标题和启动提示均读取 `appVersion = v17.10`，不再各自硬编码版本号。历史版本表中出现的 v17.7 仅用于识别旧会话，不是当前版本显示。
5. **旧 ProgramData 会话采取保守迁移策略。** 支持识别 v17.1–v17.10 对应的历史 Schema。无法识别、元数据损坏、缺少元数据但目录非空、所有者不是 Administrators/SYSTEM 的会话目录会被保留，并阻止新会话启动，避免丢弃潜在恢复资料。

## ProgramData 文件说明

位置：`%ProgramData%\HachimiGuard\`

- `active-session.lock`：锁文件可在会话结束后继续存在。文件存在本身不代表锁仍被占用；实际锁由 Windows 独占文件句柄持有，进程退出后句柄释放。
- `audit\`：保存每次会话的持久化审计日志、Watchdog startup/stdout/stderr 诊断和 parent-ready 确认文件。历史审计记录不会被当成活动会话，也不会在普通会话清理中删除。
- `session-*\`：保存防火墙基线、5157 初始状态、ACL 逐对象变更记录、动态关键词 ID、Watchdog PID/心跳和会话元数据。只有完成恢复后才删除。

### 旧文件处理规则

- 元数据有效且版本/Schema 在支持列表内：按对应恢复流程检查和恢复。
- 没有 `session.json` 且目录完全为空：可以清理空目录。
- 没有 `session.json` 但目录非空：保留，并阻止新保护会话。
- `session.json` 损坏、版本/Schema 不支持、缺少必要 Group/SessionStartUtc，或目录所有者不符合预期：保留并阻止新会话。
- **不要直接删除整个 `C:\ProgramData\HachimiGuard`。** 如果启动提示某个 `session-*` 目录阻止恢复，请保留该目录及审计日志，把具体路径和日志发来核对。

## 测试与运行

1. 将 v17.10 解压到独立目录，不覆盖 v17.9 及更早版本。
2. 首次运行可以先使用 `--diagnose` 检查配置；诊断模式不修改防火墙和 ACL。
3. 正常启动时，先观察管理员 Helper 是否完成应用、Watchdog 是否写入心跳、主程序是否完成 parent-ready 确认。
4. 在确认游戏正常启动前，不要手动删除 `session-*` 或 `audit` 内容。
5. 游戏退出后，核对日志中防火墙规则移除、Profile 恢复、5157 恢复、Tencent ACL 恢复和状态目录清理结果。

## 日志

- 主程序运行日志：沿用当前用户本地应用数据目录中的 GuardLauncher.log。
- 管理员持久化审计：`%ProgramData%\HachimiGuard\audit\session-<id>.log`。
- Watchdog 诊断：对应审计日志旁边的 `.watchdog.startup.log`、`.watchdog.stdout.log`、`.watchdog.stderr.log`。
- 不要仅提供 OCR 识别文本；若再次失败，尽可能复制原始日志文件，以免全半角符号或空格识别错误。

## 安全与兼容性说明

- 仍按明确配置的程序路径、目标 IP/FQDN、协议和端口进行网络规则管理；不扩大到任意远端地址。
- 动态 FQDN 前置条件不满足时，继续走静态 IP 降级；失败不会扩大放行范围。
- reparse point/junction/symlink 不会被递归跟随修改；遇到时会报告 ACL 覆盖不完整。
- 本版本尚未在真实 Windows 环境完成 UAC、Windows PowerShell 5.1 Parser、NTFS ACL、Firewall ActiveStore、`auditpol`、Watchdog 故障注入和旧会话恢复实测。请先在可回滚的 Windows 测试环境验证。
