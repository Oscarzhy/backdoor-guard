# GuardLauncher v17.1 变更记录

## 防火墙策略与自检

- 启动自检、Watchdog 健康检查改为读取 Windows Firewall ActiveStore，检查实际合并生效的配置文件、默认出站 BLOCK 和本次 Guard 精确允许规则，而不是只检查 PersistentStore 或只统计规则数量。
- 严格模式会检查 ActiveStore 中未受管理的宽泛出站 Allow，以及针对本次启动器/Java 路径的冲突 Allow；如果 GPO/MDM 或其他策略导致实际有效策略无法满足要求，则失败关闭。
- Guard 规则按方向、动作、启用状态、Profile、程序路径、TCP 协议、远端端口、远端 IP 或 FQDN 动态对象进行语义检查。
- Watchdog 审计/修复流程跳过本次 Guard 自己创建的规则，避免误禁用自己的白名单。
- 恢复前比较当前配置与 Guard 施加的临时状态；若检测到用户/外部策略已独立修改，不覆盖新状态。
- 防火墙快照同时记录 DefaultOutboundAction 与 Enabled，并兼容旧版只记录 DefaultOutboundAction 的状态文件。
- 新增 `firewall_cleanup_started` 写前日志，覆盖“删掉 Guard 规则后、恢复原始 profile 前崩溃”的恢复窗口。

## ACL 与用户身份

- 使用 Windows `%APPDATA%` / `%USERPROFILE%` / `%PUBLIC%` 变量展开，不再错误使用 Go `os.ExpandEnv` 展开 `%NAME%`。
- ACL 自检按 SID 比较，验证明确的 Deny FullControl 和子目录/文件继承标志，不再把局部 Deny 权限误判为完整保护。
- 新增 `acl_state.ndjson` 写前记录，只撤销 Guard 明确添加的 Deny ACE；无法追溯来源的旧会话 ACE 不会被猜测性删除。
- QQ `UserDataInfo.ini` 搜索覆盖当前启动用户的默认 Tencent 根目录，并展开已知调用用户环境变量。
- 在 UAC 选择其他管理员凭据的情况下，将原启动用户的环境路径传递给 elevated helper，避免保护错管理员自己的用户目录。
- 暂存目录在 helper 校验/执行完成后恢复原调用用户访问权限，避免不同管理员凭据导致普通用户进程无法清理临时目录。

## Watchdog 与生命周期

- 删除重复 Watchdog 启动，只保留由已提权 Helper 启动的一份 Watchdog。
- 修复 PowerShell 自动只读变量 `$PID` 被当成可写变量使用的问题；5157 PID 的十六进制格式先剥离 `0x` 再解析。
- 进程树检查排除 GuardLauncher 自己短时启动的 PowerShell 监控进程及其子进程，避免将监控脚本误判为仍有游戏进程运行。
- Watchdog 兼顾路径未知的 `java.exe` / `javaw.exe` 和启动器子进程；给启动器向 Java 交接留出 30 秒窗口。
- Watchdog 恢复 ACL 失败时保留错误并重试，不再吞掉异常。
- PowerShell 可执行文件由 `GetSystemDirectoryW` 定位到系统 Windows PowerShell 路径，不依赖 PATH 搜索。

## 用户体验与兼容性

- `--background` 会先检查保存的默认启动器；只有无有效保存值时才要求明确指定启动器。
- CLI 允许 flags 位于显式启动器路径之前，例如 `--background C:\\Minecraft\\Launcher.exe`。
- 统一控制台标题、启动消息和配置版本为 v17.1。
