# Watchdog 父进程存活保护继承说明（v17.12）

v17.12 保留 v17.11 的父进程内核 Mutex 租约、PID/映像路径/创建时间复核、parent-ready 文件确认，以及 Watchdog 清理前最后一道父进程检查。v17.12 没有改变该机制；本版处理的是用户日志中新确认的 Helper 旧会话恢复失败及 UAC Bootstrap 误报成功。
