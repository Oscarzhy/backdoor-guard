# GuardLauncher v17.7 构建状态（2026-11-08）

- 基线：v17.6 Recovery/Audit Complete。
- 版本：v17.7，Windows amd64，Console 子系统。
- Go：1.23.2。
- 构建环境：Linux amd64 交叉编译 Windows；未安装 powershell/pwsh。
- 构建命令：
  - `gofmt -w GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet GuardLauncher_v17.go`
  - `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o GuardLauncher_v17.7_x64.exe GuardLauncher_v17.go`
- 结果：全部命令退出码为 0；`go test` 输出 `[no test files]`。
- PE：PE32+ Windows x86-64 Console executable。
- 可重复构建：两次独立构建产物逐字节一致；最终 EXE SHA-256 已核对。
- UAC trampoline：代表性路径下 8,976 Base64 字符；outer command 9,270 UTF-16 单元；实际运行时重新计算并严格检查。
- PowerShell Parser：源码已加入 bootstrap/trampoline/helper/watchdog 四部分本机 Parser 预检；当前容器无 PowerShell，故未运行。
- Windows 实机：未执行；UAC、Staging ACL、ProgramData 审计文件、Apply、Watchdog 和恢复仍待实机验证。

注意：本构建证明 Go Windows 目标编译成功，不证明 UAC/PowerShell/NTFS 功能已运行。
