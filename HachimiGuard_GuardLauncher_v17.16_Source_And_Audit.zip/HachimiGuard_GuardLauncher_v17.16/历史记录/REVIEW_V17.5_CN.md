# GuardLauncher v17.5 第一半代码复审

## 审查基线

- 基线：用户提供的 v17.4 完整 ZIP。
- 当前版本：v17.5，第一半。
- 修改文件：`GuardLauncher_v17.go`、构建脚本、版本文档和测试矩阵。
- 未修改配置：AllowedDomains / JavaPaths / ProtectedPaths / DefaultLauncherPath。

## 已实施的保护措施

1. **同一会话只能有一个修改者**：Helper 在遗留恢复和初始化前取得全局独占文件句柄；Watchdog 接管后持有到恢复退出。锁内容仅用于诊断，OS 句柄状态才决定锁是否有效。
2. **交接不是 PID 文件即成功**：Helper 等待新 Watchdog 取得锁并写入新鲜心跳。主程序又独立验证心跳、PID、PowerShell 映像路径和进程创建时间。
3. **PID 重用有第二重检查**：心跳保存进程创建时间；主程序定期查询 CIM CreationDate，容差 3 秒。
4. **Watchdog 停止不直接触发恢复**：主程序监督心跳；可尝试一次 ResumeWatchdog。若监控本身无法确认游戏已退出，主程序不会仅凭超时执行 Restore。
5. **最终恢复再次确认目标进程**：Restore Helper 取得全局锁后重新获取 Win32_Process 快照；启动器/归属 Java 仍在、WMI 查询失败或快照为空时全部拒绝恢复。
6. **旧版交接保护**：发现 v17.4 Watchdog 仍然运行时，新版本不并发处理其旧会话。
7. **持久化日志**：Go 主程序、UAC Bootstrap、Helper、Watchdog 共用会话审计日志路径和命名互斥量；记录生命周期事件、恢复重试和失败详情。Go Panic 带堆栈；PowerShell 错误包含 ExceptionToString 与 ScriptStackTrace。

## 复审中修正的额外问题

- 移除 Watchdog 脚本中未使用的 Helper 专用启动函数，避免将 `$Mode`、`$ConfigB64` 和 Watchdog 启动占位符带入 Watchdog 自身脚本。
- Watchdog 启动后写入 PID/创建时间记录失败时，Helper 在仍持有锁的条件下校验子进程身份，再决定是否停止；身份不一致时不杀进程。
- WMI 返回空快照视为不可信，不作为“目标进程全部退出”的证据。
- 主程序进程监控超过 30 秒后，先继续等待最多 120 秒；如果仍无法确认且 Watchdog 没有删除会话状态目录，则保留保护并报告，不执行最终 Restore。
- 最终 Restore Helper 自身增加进程快照检查，避免调用者路径绕过主程序监控超时门禁。
- v17.4 的辅助 `Wait-ProtectedProcesses` 不再把仍在等待恢复的 GuardLauncher 父进程本身当成游戏进程，否则会等不到父程序退出。

- UAC Bootstrap 的早期诊断也通过同一日志命名互斥量写入审计文件，并在写入后 Flush(true)；若审计文件不可用则保留私有暂存诊断副本。

## 未解决或需要实测的边界

- 主程序对 Watchdog 故障只发起有限的管理员接管请求，避免循环 UAC 提示。如果 Watchdog 处于“进程仍活着但完全挂死且持有锁”的状态，接管可能因锁仍被占用而失败；本版不会仅凭心跳停止强杀一个身份未充分确认的 PowerShell 进程，会保留会话状态并报告。
- `Local\` 命名 Mutex 与不同 UAC 身份/用户切换时的 ACL 兼容性需要 Windows 实测。本项目默认同一登录用户通过正常 UAC 提升。
- 硬断电、系统崩溃或外部 TerminateProcess 无法保证进程写出最终 crash 记录；下一次启动通过文件锁释放和陈旧心跳恢复。
- 当前没有 Windows PowerShell 5.1 Parser；Go 交叉编译不会验证嵌入 PowerShell 代码的运行时语义。
- 当前没有添加真正的 Go 业务测试；`go test` 显示 `[no test files]`。本包的 57/57 是静态结构检查，不是系统功能测试。

## 下一半的明确范围

- 5157 恢复状态在 Helper 与 Watchdog 间统一，恢复各步骤独立执行、失败不跳过 ACL。
- Allow/ACL 恢复记录采用临时文件、校验和原子替换；损坏记录保留并停止破坏性处理。
- Tencent 目录子树 ACL 先只读扫描，再有来源记录地补充保护；不跟随 junction/symlink/reparse point。
