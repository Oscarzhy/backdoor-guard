# GuardLauncher v17.6 第二半测试矩阵

请在独立 Windows 测试环境使用管理员账户测试；不要直接在唯一工作环境首次启用严格网络隔离。先保留 v17.5，必要时创建系统还原点或虚拟机快照。

| ID | 场景 | 期望结果 | 重点日志 |
|---|---|---|---|
| A5157-01 | 初始 No Auditing | 启用 Failure；退出后恢复 No Auditing | audit_policy.json、audit_policy_apply_started、audit step |
| A5157-02 | 初始 Success | 启用 Success+Failure；退出后恢复 Success | OriginalKind/ExpectedKind 与恢复后核验 |
| A5157-03 | 初始 Failure | 不改变原始策略 | Guard 未修改说明 |
| A5157-04 | 初始 Success+Failure | 不改变原始策略 | Guard 未修改说明 |
| A5157-05 | 运行中由外部改动 5157 | 不覆盖外部状态，明确记录 mismatch | original/current/expected |
| A5157-06 | 删除 audit_policy.json 但保留 apply marker | 不宣称成功；保留会话资料 | FAILURE + missing journal |
| JRN-01 | ACL 正常写前记录 | 每个 ACE 修改前已有对应 JSON，manifest count 同步 | RecordCount 增长 |
| JRN-02 | 模拟记录文件多于 manifest count | 恢复识别提交窗口并校正 manifest | counter lag |
| JRN-03 | 删除一个已提交记录文件 | 不自动删除 ACL，不清理会话目录 | record loss |
| JRN-04 | 损坏单个 ACL JSON | 恢复失败并保留现场 | 文件路径 + JSON parse error |
| JRN-05 | per-object JSON 存在但 manifest 缺失 | 拒绝自动恢复/删除 ACE | manifest missing |
| JRN-06 | ACL 写入中途制造未提交 .tmp | 记录 warning，不把临时文件当已完成记录 | ignored temp |
| ACL-01 | 正常继承树 | 根/子目录/文件均验证有效 Deny | COVERAGE_VERIFIED |
| ACL-02 | 关闭继承的现有子目录 | 添加显式 ACE、写前日志、可正确恢复 | child path record |
| ACL-03 | 关闭继承的既有文件 | 添加文件级显式 ACE、可正确恢复 | file path record |
| ACL-04 | reparse point/junction | 不跟随、不修改目标；根目录标记覆盖不完整并失败关闭 | path + COVERAGE_INCOMPLETE |
| ACL-05 | 子目录无权限读取/枚举失败 | 不报告保护成功；保留可恢复记录 | failing path + stack |
| ACL-06 | 大型目录 | 进度按 500 项记录；无逐对象成功日志风暴 | progress + summary |
| REC-01 | 防火墙规则删除失败 | 不恢复更宽 Profile/用户 Allow；ACL/5157 仍单独尝试 | DEFERRED + ACL/audit result |
| REC-02 | 5157 恢复失败 | ACL 仍继续恢复；会话资料保留 | separate step outcomes |
| REC-03 | ACL 某个对象恢复失败 | 其他对象继续处理；不删除会话目录 | path failure + retry |
| REC-04 | 第一次恢复失败，第二次恢复成功 | 第二次能读取原记录并完成恢复 | attempt=1/2 |
| LOG-01 | 正常退出 | 记录每组开始、结果、最终状态 | session audit |
| LOG-02 | 强制结束 Watchdog | 下一次启动发现遗留锁/会话并保留错误上下文 | lifecycle emergency/audit |
| LOG-03 | 审计日志无法追加 | 尝试 emergency log 并输出日志写失败信息 | lifecycle-emergency.log |

注意：强制断电或硬件掉电时，不可能保证最后一条日志一定落盘；验证重点是此前已 Flush 的记录、原子状态和下一次启动的恢复能力。
