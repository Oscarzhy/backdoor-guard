# v17.12 静态审计报告

日期：2026-11-08

## 审计目标

针对用户提供的 Windows 11 / Windows PowerShell 5.1 日志，确认旧会话恢复失败与 Bootstrap 成功状态误判的源码原因，并在不放宽防火墙策略、不丢弃恢复记录的前提下修复。

## 已确认的源码问题

1. `Recover-StaleSessions` 直接以 `Remove-NetFirewallRule -Group $old.Group -ErrorAction Stop` 删除旧 Group。用户实机输出显示，在没有匹配 Group 的规则时，NetSecurity CIM Provider 抛出“找不到任何 RuleGroup 属性等于该值的 MSFT_NetFirewallRule 对象”。该步骤被记录为失败，之后动态关键词、禁用的用户 Allow 和 Profile 恢复被延迟，最终抛出旧会话恢复不完整。
2. Bootstrap 已把异常写入诊断文件并记录 `[bootstrap] FAILED`，但 `runElevated` 只根据外层 PowerShell 进程是否返回错误判断；若外层进程报告 0，Go 主程序会把该阶段视为成功，不再检查 Bootstrap 是否写出 `HELPER_RESULT=OK`。这与用户日志中的“Bootstrap FAILED”后紧接“管理员保护组件执行完成”一致。
3. 当前 StateDir 的创建发生在 `Recover-StaleSessions` 完成之后。因此旧会话恢复抛出异常时，本次 `session-*` 尚未创建；Watchdog StateDir 不存在是次生症状。

## 已实施修改

- 新增共享 `Get-GuardFirewallRulesByGroup`：完整枚举指定 Firewall PolicyStore，再以 .NET ordinal-ignore-case 比对 Group，避免使用空匹配的 CIM `-Group` 查询。
- 新增共享 `Remove-GuardFirewallRulesByGroup`：只从 `PersistentStore` 删除精确 Group 对象；零匹配视为幂等成功；删除后再次枚举 `ActiveStore`。有任何残留或查询失败均抛错并保留恢复材料。
- Helper 的旧会话恢复、Apply 预清理、Helper Restore、Watchdog 重建及 Watchdog Restore 统一使用共享函数。源码不再包含 `Remove-NetFirewallRule -Group` 形式。
- 新增 `waitForElevatedBootstrapResult`：在本次临时 Bootstrap 诊断中，只有出现 `[bootstrap] HELPER_RESULT=OK` 才允许 `runElevated` 返回成功；`FAILED`、错误文件或 120 秒内未拿到标记都按失败处理。
- 主程序只有 `runElevated` 验证成功后才输出“管理员保护组件执行完成”，避免 Helper 未执行完就进入 Watchdog 等待阶段。

## 安全行为检查

- 无匹配 Group 不会调用删除命令，也不会导致恢复链被错误阻断。
- 只删除来自 `PersistentStore` 且 Group 精确相符的规则对象。
- 如果 ActiveStore 仍有同 Group 规则（包括 GPO/其他策略来源），不会删除其他策略，也不会继续恢复可能放宽网络访问的 Allow/Profile 状态。
- PolicyStore 枚举失败不会被当成空列表；仍然失败关闭并保留旧会话目录。
- Bootstrap 没有显式成功标记时，Go 返回管理员组件失败，不启动 Minecraft Launcher/Java。

## 本地自动检查

- Windows amd64 Go 交叉编译：通过。
- Go test：通过（单文件项目没有测试文件）。
- go vet：通过。
- 重复构建：检查二进制 SHA-256 一致性。
- 静态断言：检查版本统一、幂等清理入口覆盖、没有 `Remove-NetFirewallRule -Group`、Bootstrap 成功/失败握手顺序、旧版本映射与配置文件一致性。
- ZIP 完整性及包内 SHA-256 清单：通过。

## 未完成的实机验证

当前构建环境不是 Windows。未执行 Windows PowerShell 5.1 Parser、UAC 提升、NetSecurity CIM Provider、PersistentStore/ActiveStore 删除与查询、GPO 残留验证、WMI/CIM、Mutex 跨进程行为、NTFS ACL 和实际恢复测试。因此本报告不能替代目标电脑实测。
