# GuardLauncher v17.5 第一半静态审计

## 静态检查结果

- 生命周期/会话锁/日志结构断言：57/57 项通过。
- `gofmt`：通过。
- Windows amd64 `go test` 编译检查：命令通过，输出 `[no test files]`。
- Windows amd64 `go vet`：通过。
- Windows amd64 `go build`：通过。
- 生成物：PE32+ Windows x86-64 Console。
- ZIP 完整性和内部文件 SHA-256：打包阶段再次验证。

57 项静态断言覆盖：

- Helper、Watchdog 共享锁和日志设施是否正确注入。
- Helper 取得锁后才做遗留会话恢复。
- Watchdog 交接和持锁生命周期。
- 原子心跳字段、临时文件和 File.Replace/Move。
- PID、进程映像和创建时间的身份核对。
- 心跳过期、`Failed` 状态、WMI 错误/空快照的失败关闭处理。
- 主程序监控超时不能直接授权 Restore。
- Restore Helper 的二次进程检查。
- Go/UAC Bootstrap/Helper/Watchdog 日志互斥、Flush/Sync 和崩溃堆栈。
- UAC 故障日志、Helper 栈信息、Watchdog 重试和恢复状态日志。
- Helper/Watchdog 模板的占位符替换关系。

## 明确未验证

1. **PowerShell 语法**：当前环境无 Windows PowerShell 5.1、PowerShell 7 或 `System.Management.Automation.dll`，未实际执行 Parser。目标 Windows 上 `runElevated` 仍会在 UAC 前通过系统 Windows PowerShell Parser 检查 Helper 和 Watchdog 脚本。
2. **Windows 文件锁**：未在 Windows 实测 `FileShare.None` 的跨进程互斥、异常终止自动释放、UAC 提升同用户访问和锁交接。
3. **Windows Mutex**：未实测 Go `CreateMutexW` 与 .NET `System.Threading.Mutex` 对同一 `Local\\` 名称的跨进程互斥和不同 Token 情况。
4. **进程身份**：未实测 CIM `CreationDate` 的精度/时区和 PowerShell `Get-Process` 对退出/访问拒绝状态的表现。
5. **Watchdog 生命周期**：未实测挂起、崩溃、强制终止、UAC 接管、快速恢复以及系统重启后遗留状态。
6. **日志落盘**：未进行断电/强杀试验。Flush/Sync 是最佳努力，不代表硬件缓存和断电场景绝对持久。

## 本次没有修改的功能

- v17.3 FQDN 预检和静态 IP 降级。
- v17.4 Java 进程匹配规则和用户配置白名单。
- 5157 审计恢复逻辑。
- `disabled_allows.json` 和 ACL NDJSON 恢复记录写入协议。
- Tencent ACL 递归覆盖。

以上未修改项不得因本次 Go 构建通过而视为已验证。
