# v17.11 静态审计与构建结果

## 检查范围

- 完整审阅用户上传的 v17.10 ZIP，检查 Go 主程序、嵌入式 PowerShell Helper/Watchdog、会话状态读写与清理路径。
- 修改父进程存活判断、Watchdog 清理闸门、错误包装识别、删除审计以及版本元数据。
- 保留 v17.10 及更早版本的历史 Markdown 记录（集中放入 `历史记录/`），但发布包不再携带旧版 EXE；当前配置文件与 v17.11 二进制保留在项目根目录。

## 静态结果

- Go 格式化：通过。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go`：通过，提示 `[no test files]`，因此只代表编译/测试驱动加载成功，没有项目单元测试。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet GuardLauncher_v17.go`：通过。
- Windows x64 `go build -trimpath -ldflags='-s -w'`：通过。
- 48/48 项关键静态断言通过：版本号、schema 映射、父进程 Mutex 生命周期、独立进程探测、清理前复核、`errors.Is`、所有已知状态目录删除路径的前后审计标记、空值安全日志、构建脚本/版本文件及配置文件哈希均核对通过。
- 配置文件 SHA-256 与 v17.10 包内记录一致：`AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 未修改。

## 修复逻辑边界

- Mutex `Held`：父进程仍持有内核租约，阻止父进程被误判退出。
- Mutex `Abandoned`：原持有线程/进程异常结束；仍使用直接 PID/进程创建时间探测来确认是否 PID 重用。
- 直接探测 `Alive` / `UnknownAlive` / `Unknown`：保守认为父进程可能存活，保留保护。
- WMI 查询失败：沿用原策略，Watchdog 不推断目标退出，保留保护并重试。
- 清理前重新读取 parent-ready 文件并重新查询父进程；确认文件出现或父进程仍存活时不清理。
- 观察计数器用 `errors.Is` 识别被 `%w` 包装的 `os.ErrNotExist`。

## 未验证项

此工作环境没有 Windows PowerShell 5.1 / `powershell.exe`，未执行真实 PowerShell Parser。也没有 Windows UAC、CIM/WMI、NTFS ACL、Firewall ActiveStore、5157 auditpol 环境，未执行实机测试。特别是 `.NET Mutex.OpenExisting` 与 Go `CreateMutexW` 的跨进程、不同完整性级别互操作，必须在真实 Windows 环境验证。

## 风险声明

本次源代码确认 v17.10 的 Watchdog 父进程判定依赖 CIM 快照；当快照漏报父 PID 时，理论上可能提早进入“父进程已退出”的无目标恢复路径。v17.11 加入独立租约和探测来降低该风险。但用户本次日志没有提供原始 Windows 文件系统审计或 Watchdog 持久化审计，故不能断言本机目录一定由 Watchdog 删除，也不应把候选原因写成运行时确诊。


## 发布包整理

- 根目录只保留 v17.11 当前源码、当前 EXE、构建脚本、运行配置及当前版本文档。
- v17.10 与更早版本的 EXE 及其独立哈希文件已从发布包移除。
- 旧版 README、CHANGELOG、BUILD_STATUS、STATIC_AUDIT、REVIEW 和测试矩阵均保留在 `历史记录/`，没有删除历史 Markdown。
- `FILE_HASHES_SHA256.txt` 重新生成，覆盖当前源码、EXE、配置、脚本及历史文档。
