# GuardLauncher v17.5 变更记录

v17.5 以 v17.4 为基线，按用户要求拆成两半。本包只交付第一半：会话互斥、Watchdog 生命周期监督、统一持久化日志基础。第二半（5157 恢复、Allow/ACL 恢复记录原子写入、Tencent ACL 子目录覆盖）尚未修改。

## 1. 全局会话互斥

- 新增 `%ProgramData%\HachimiGuard\active-session.lock` 独占文件句柄锁，使用 `FileShare.None`，不靠锁文件是否存在推断会话活跃。
- Helper 在遗留会话检查和任何本会话 ACL/防火墙变更前取得锁。
- Helper 启动 Watchdog、保存其 PID/创建时间后释放锁；Watchdog 必须取得同一锁并写入有效心跳，Helper 才确认启动完成。
- Watchdog 持锁覆盖监控、策略重建及恢复过程，恢复成功或失败退出时释放句柄。
- Helper/Watchdog 崩溃时由 Windows 关闭文件句柄。锁文件保留最后持有者元数据作诊断，但该文本不会被当作锁状态。
- v17.5 新 Helper 检查仍在运行的 v17.4 Watchdog，避免与旧版没有共享锁的恢复进程并发操作。

## 2. Watchdog 生命周期

- 新增原子更新的 `watchdog.heartbeat.json`，字段包括 Schema、会话组、PID、进程创建时间、UTC 心跳、序号、状态和消息。
- 主程序在 Helper 启动握手后验证心跳组、PID、PowerShell 映像路径和进程创建时间。
- 运行期间每 3 秒检查心跳/进程状态；每 12 秒重新查询 CIM 进程身份，避免只凭 PID 判断 Watchdog 健康。
- 识别 `Starting`、`Monitoring`、`Restoring`、`RecoveryRetry`、`RecoveryFailed`、`Restored` 和 `Failed` 状态。
- Watchdog 未就绪、异常退出或报告 Failed 时，主程序记录故障并请求一次管理员接管；成功启动替代 Watchdog 后恢复监督。不会对同一故障无限弹出 UAC。
- 新 Watchdog 的正常启动宽限期为 60 秒；明确的 Watchdog 接管重启使用 5 秒宽限期，防止目标进程已经退出时再等待完整启动时间。
- Helper 写入 PID/创建时间元数据失败时，只会在验证子进程映像路径、脚本命令行及创建时间后尝试终止刚启动的 Watchdog。
- 最终 Restore Helper 持有全局锁后重新查询启动器和 Minecraft Java；只要目标仍在运行、WMI 查询失败或快照为空/不可信，就拒绝恢复。
- 主程序监控超时不再等同于“游戏已退出”。如果监控无法确认且 Watchdog 未完成清理，保留状态并报告，不通过超时强制撤销保护。

## 3. 统一持久化日志

- 主程序每次正常启动记录版本、PID、参数、启动器和会话组。
- 主程序日志在会话开始后镜像到 ProgramData 会话审计文件。
- Go、UAC Bootstrap、Helper 和 Watchdog 使用同一规范化日志路径派生的 Windows `Local\` 命名互斥量，减少多进程并发写入交错。
- UAC Bootstrap 的早期诊断写入同一审计日志互斥量并执行 `Flush(true)`；暂存目录仍保留私有诊断副本。
- PowerShell 追加记录后执行 `Flush(true)`；Go 追加后执行 `Sync()`。
- 记录 Helper 模式、锁取得/竞争/释放、Watchdog 启动和交接、心跳健康检查、恢复开始/重试/失败/成功、UAC 失败、Helper 异常详情及 Watchdog 脚本栈。
- 未处理 Go Panic 记录 `debug.Stack()`；常规日志初始化前 Panic 使用用户本地日志目录的早期崩溃日志回退。
- 审计日志无法写入时，PowerShell 尝试写入 StateRoot 或会话目录的应急日志。UAC 启动失败详情仍保存在主程序日志和独立 `uac-failure-*.log`。

## 4. 安全回归与范围限制

- 保留 v17.3 FQDN 兼容性检查和静态 IP 安全降级。
- 保留 v17.4 Minecraft Java 进程归属检测；普通 IDE/Gradle Java 进程不因共享 `java.exe` 路径而延迟恢复。
- 没有更改 `AllowedDomains.txt`、`JavaPaths.txt`、`ProtectedPaths.txt`、`DefaultLauncherPath.txt`。
- 没有修改 ACL 子目录递归、5157 恢复策略或 Allow/ACL 恢复日志的原子写入；这些属于第二半。

## 5. 未完成的实机验证

当前构建环境没有 Windows PowerShell 5.1 Parser 和真实 Windows 内核/防火墙/NTFS 环境。文件锁交接、Mutex 权限、UAC、CIM 心跳、Watchdog 强制退出接管和最终 Restore 门禁仍需 Windows 实测。突然断电或被外部强制终止时，进程可能无法写出最后一条崩溃日志；下一次启动依靠心跳陈旧、锁句柄释放和遗留会话恢复处理。
