# v17.9 构建状态

- 基线：GuardLauncher v17.8 Watchdog Wait Fix。
- Go：go1.23.2 linux/amd64。
- 目标：Windows amd64，`CGO_ENABLED=0`。
- 构建参数：`-trimpath -ldflags="-s -w"`。
- `gofmt`：已执行。
- Windows amd64 `go test` 编译检查：通过，输出 `[no test files]`（没有 Go 业务测试用例）。
- `go vet`：通过。
- 独立重复构建：与交付 EXE 字节级一致。
- Watchdog/父进程定向静态断言：13/13 通过。
- 网络及路径配置：AllowedDomains、ProtectedPaths、JavaPaths、DefaultLauncherPath 与 v17.8 逐字节一致。
- PowerShell 5.1 Parser：未执行，当前构建主机没有 Windows PowerShell。
- Windows 实机/UAC/CIM/NTFS/防火墙测试：未执行。

本包 EXE 由附带 `GuardLauncher_v17.go` 构建。完整文件 SHA-256 见 `FILE_HASHES_SHA256.txt`。
