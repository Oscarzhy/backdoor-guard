# v17.10 静态审计报告

## 本次核对重点

1. 启动版本显示是否统一：`appVersion = v17.10`；旧版本字符串只出现在历史 Session Schema 表中。
2. Watchdog 是否在主程序完成心跳与身份验证前拥有删除 StateDir 的权限：新增随机 Token 的 parent-ready 文件确认；无有效 ack 时仅保持保护/等待父进程退出宽限。
3. Helper 是否验证 `session.json`、`watchdog.pid`、`watchdog.heartbeat.json` 同一会话身份。
4. Go 是否验证 session Group/Schema/Version/ParentPID/StateDir/Token，并比较 watchdog.pid 与 heartbeat PID。
5. 修复 Watchdog PID 元数据路径：`Join-Path $cfg.StateDir 'watchdog.pid'`，不再向一个 Join-Path 传入多个 ChildPath。
6. ProgramData 遗留目录是否被静默忽略：隐藏 session 目录也枚举；非空孤儿、损坏/未知 Schema、必要字段缺失和所有者不可信时保留并阻止新 Apply。
7. `active-session.lock` 文件存在本身不代表占用；audit 日志不参与 stale session 恢复。

## 静态检查结果

- Go Windows amd64 `go test` 编译检查：命令成功，输出 `[no test files]`。
- Go `go vet`：通过。
- Go Windows amd64 两次独立构建：字节级一致。
- PowerShell 结构平衡检查：Helper、Watchdog、公共函数模板括号/引号结构通过。
- 定向源码断言：30/30 通过。
- ZIP 完整性及包内 SHA-256：打包后核验。

## 限制

本审计不是 Windows 实机测试。当前构建环境没有 Windows PowerShell 5.1、NTFS、真实 UAC 或 Windows Firewall/ActiveStore/auditpol，因此无法证明脚本可在目标 Windows 版本上完整运行。PowerShell 结构平衡检查不能替代 `[System.Management.Automation.Language.Parser]::ParseFile()`。UAC、ACL、Watchdog 交接、旧会话恢复和故障注入仍需真实 Windows 验证。
