# ProgramData 旧状态目录处理指南（v17.10）

## 为什么不能直接清空

`%ProgramData%\HachimiGuard\session-*` 可能保存原防火墙 Profile、用户 Allow 规则启用状态、5157 审计状态、动态 FQDN 关键词 ID，以及 Guard 添加的 ACL Deny ACE 的逐对象来源记录。删除目录可能让后续版本失去恢复原状所需的信息。

## 文件类型

- `active-session.lock`：由独占文件句柄实现互斥。文件可持续存在；只有句柄占用才表示锁活跃。
- `audit\`：历史主程序/Helper/Watchdog 日志，不作为活动会话证据。
- `session-*\`：实际恢复状态目录，必须逐个检查。

## v17.10 识别的历史版本

| Version | Schema |
|---|---:|
| v17.1 | 6 |
| v17.2–v17.4 | 7 |
| v17.5 | 8 |
| v17.6–v17.9 | 10 |
| v17.10 | 11 |

已知版本只有在 session.json 能正确解析、Group/SessionStartUtc 完整、所有者为 Administrators/SYSTEM 且进程归属确认无活动后，才会进入对应恢复流程。

## 哪些情况会阻止新会话

- 非空 `session-*` 目录缺少 `session.json`。
- `session.json` 损坏、版本/Schema 不受支持、缺少 Group 或 SessionStartUtc。
- 目录所有者不是 Administrators/SYSTEM。
- 任何恢复步骤失败、WMI 无法可靠判断旧会话活动状态或旧 Watchdog 仍在运行。

这些情况下，v17.10 会保留目录并写入明确错误，不会猜测原始状态，也不会为了让程序启动而删除恢复资料。

## 哪些文件不影响新会话识别

- 没有被占用的 `active-session.lock` 文件。
- `audit\` 下历史 `.log` 和 `.watchdog.*.log` 文件。
- 不在 `session-*` 下的普通历史审计文件。

## 用户应如何处理

不要手工删除整个 StateRoot。若程序报告某个 `session-*` 阻止启动，请保留该目录、相关 audit 日志和错误文本。根据具体文件、版本和恢复标记确定是否可以用兼容恢复流程处理。只有确认目录完全为空、缺少 `session.json` 且没有任何修改证据时，程序才自动清理。
