# ProgramData 旧状态目录处理指南（v17.12）

## 不要直接清空

`%ProgramData%\HachimiGuard\session-*` 可能保存防火墙 Profile、5157 初始状态、曾禁用的用户 Allow 规则、动态 FQDN 关键词 ID，以及 Guard 添加 ACL Deny ACE 的逐对象恢复记录。不要手动删除整个目录或任意非空会话目录。

## 本版对 v17.7 会话的处理

v17.7 使用 Schema 10，仍在 v17.12 的兼容映射中。恢复时先确认进程与旧 Watchdog 状态，再恢复防火墙、动态对象、用户 Allow、Profile、5157 和 ACL。

防火墙清理现在先枚举 `PersistentStore` 的规则对象，并在内存中按旧会话随机 Group 精确比对：

- 匹配数量为 0：只代表本地持久规则已不存在，按幂等成功处理，然后继续检查 ActiveStore 和其余恢复材料。
- 匹配数量大于 0：只删除这些精确 Group 的 Guard 本地规则。
- 删除后 ActiveStore 仍有同 Group 规则：恢复步骤失败，继续保留会话目录，不恢复可能放宽网络访问的用户 Allow/Profile 状态。
- 查询 PersistentStore/ActiveStore 本身失败：作为真实错误处理，保留目录，不把查询失败误当成零匹配。

这避免了 `Remove-NetFirewallRule -Group` 在零匹配时引起的 CIM 异常，同时不扩大删除范围。

## 版本映射

| Version | Schema |
|---|---:|
| v17.1 | 6 |
| v17.2–v17.4 | 7 |
| v17.5 | 8 |
| v17.6–v17.9 | 10 |
| v17.10–v17.12 | 11 |

## 常见残留

- `active-session.lock` 文件本身不代表锁仍被持有；真正互斥由独占句柄实现。
- `audit\` 下的历史 `.log`、Watchdog 诊断及 parent-ready 文件通常不会被作为活动会话依据。
- 非空 `session-*` 缺少 `session.json`、元数据损坏、版本/Schema 未知、进程归属无法确认、或恢复步骤失败，都会保留现场并阻止新会话覆盖。

## 本次故障排查建议

如果再次失败，优先保留并提供：

- `audit\session-<本次会话ID>.log`
- 对应的 `uac-failure-*.log`
- `.watchdog.startup.log`、`.watchdog.stdout.log`、`.watchdog.stderr.log`（若已经启动 Watchdog）
- 旧 `session-*\session.json` 与恢复日志（分享前应遮盖个人路径和任何令牌）

不要因为看到 `StateDir` 不存在就手工创建同名目录；如果 Helper 尚未通过旧会话恢复，创建空目录只会掩盖前置失败。
