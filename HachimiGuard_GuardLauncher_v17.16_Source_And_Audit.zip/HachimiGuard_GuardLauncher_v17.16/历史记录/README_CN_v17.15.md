# HachimiGuard GuardLauncher v17.15

## 新对话接手前请先阅读

1. `00_优先阅读_兼容性与启动中止问题复筛_v17.15.md`：当前剩余的条件性启动中止/恢复兼容问题。
2. `01_AI交接_项目初衷功能与用户要求.md`：项目初衷、完整功能、用户要求、当前架构冲突和后续 AI 工作规则。

本包新增以上两份交接文档，不修改 v17.15 程序源码、EXE 或配置。

本包只包含当前 v17.15 程序、源码、构建脚本、配置和当前版本说明。以前版本的 Markdown 全部保存在 `历史记录/`，不包含旧版 EXE。

## 本版范围

本版只修复 v17.14 未修改代码审计中的两项 UTF-8 读取问题：

1. **ACL journal**：Helper 与 Watchdog 共用的持久化函数统一使用严格 UTF-8 读取 `acl_journal_manifest.json`、`acl_journal/*.json` 和旧版 `acl_state.ndjson`。此前写入端使用 UTF-8，而部分读取端使用 Windows PowerShell 5.1 默认代码页，含中文/非 ASCII 路径时可能发生乱码。
2. **session.json**：旧会话恢复、Watchdog 重启流程均改用相同的严格 UTF-8 读取。Go 端 Watchdog 身份校验也接受可选 UTF-8 BOM，并在 JSON 解析前拒绝非法 UTF-8，避免路径和身份字段被替换字符污染。

读取器只接受 UTF-8（允许 UTF-8 BOM），不猜测 ANSI、UTF-16 或 UTF-32。编码损坏时明确失败并保留会话恢复资料，不会把乱码路径当成可安全跳过的目标。

## 未改变的行为

- Schema 保持 11，并增加 v17.15 的旧会话版本识别。
- 防火墙默认出站 BLOCK、精确网络白名单、Helper/Watchdog 生命周期和 ACL 保护策略均未修改。
- `AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 与 v17.14 完全一致。
- 本版没有扩大程序拦截范围，也没有改变与 Minecraft/相关模组无关程序的既有处理方式。

## 运行

在可信的本地目录解压后，运行 `GuardLauncher_v17.15_x64.exe`。启动失败时保留 `%ProgramData%\HachimiGuard` 中的恢复记录和 `audit` 日志，不要直接删除整个目录。

## 验证限制

本版在 Linux 环境完成 Windows x64 交叉编译、Go 静态检查和源码定向断言。当前环境没有 Windows PowerShell 5.1、UAC、NTFS 和 NetSecurity 防火墙实机，因此严格 UTF-8 PowerShell 解码及真实 ACL 恢复仍需在目标 Windows 设备验证。
