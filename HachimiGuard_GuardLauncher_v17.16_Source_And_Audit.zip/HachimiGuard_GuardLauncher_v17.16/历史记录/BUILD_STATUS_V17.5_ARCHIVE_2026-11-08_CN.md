# GuardLauncher v17.5 构建状态（2026-11-08）

## 构建环境

- 构建环境：Linux，Windows x64 交叉编译。
- Go：1.23.2。
- 目标：`GOOS=windows GOARCH=amd64 CGO_ENABLED=0`。
- 子系统：Windows CUI。

## 执行结果

```sh
gofmt -w GuardLauncher_v17.go
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet GuardLauncher_v17.go
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o GuardLauncher_v17.5_x64.exe GuardLauncher_v17.go
```

- `gofmt`：通过。
- `go test` 编译检查：通过，输出 `[no test files]`，没有 Go 业务测试用例。
- `go vet`：通过。
- `go build`：通过。
- PE：PE32+ Windows x86-64 Console。
- 生命周期静态断言：57/57 项通过；这是源码/模板结构核对，不是 PowerShell Parser 或 Windows 功能测试。
- Go 源码 SHA-256：`85c303d6ac02a22c8564f8f5ffb85ed192a3291e3d36e0df996d5cd5e86d3530`。
- Windows x64 EXE SHA-256：`005a1e5ea44eea100cb3c63cde14b50161ce86343f1a96480defca4025745f6a`。

## 未执行的验证

当前环境没有 PowerShell 5.1/7 Parser、Windows CIM/WMI、NTFS、UAC 和 Windows Firewall 运行环境。PowerShell Parser 将在目标 Windows 上由程序在 UAC 前执行，但当前构建环境不能预先证明它通过。文件锁、Mutex、心跳进程身份和 Watchdog 接管都需要目标 Windows 实机验证。

## SHA-256

参见 `FILE_HASHES_SHA256.txt` 和 `GuardLauncher_v17.5_x64.exe.sha256`。
