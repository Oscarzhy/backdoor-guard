# GuardLauncher v17.11 构建状态（2026-11-08）

- 版本：v17.11
- 目标：Windows x64 / amd64
- Schema：11（兼容 v17.10）
- Go 工具链：go1.23.2 linux/amd64（交叉编译）
- EXE：GuardLauncher_v17.11_x64.exe
- EXE 大小：3419648 bytes
- EXE SHA-256：

```text
08d5b836cc0a6d86a9a13d6b08608d41121fed3caa1fb0aa837ba90b955b6a2d  GuardLauncher_v17.11_x64.exe
```

## 已完成

- gofmt
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go（无测试文件；编译检查通过）
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet GuardLauncher_v17.go
- Windows x64 go build（-trimpath -ldflags='-s -w'）
- 48/48 项针对父进程租约、清理闸门、错误链识别、全部状态目录删除路径及审计先后顺序、版本映射和配置文件不变性的静态断言
- PE 文件检查：Windows PE32+ x86-64

## 未完成

当前构建环境不是 Windows，未运行 PowerShell 5.1 Parser、UAC、CIM/WMI、NTFS ACL、Firewall ActiveStore、auditpol、命名 Mutex 跨进程互操作及完整 Minecraft 启动/恢复实测。不得把交叉编译结果解释为 Windows 实机验证通过。
