# GuardLauncher v17.3 修复审查

## 本次范围

本版只处理 v17.2 的动态 FQDN 兼容性和降级链路。没有改动 Java 进程识别，也没有顺带修复上一轮复审列出的其他 P2 项。

| 项目 | v17.2 问题 | v17.3 处理 | 证据边界 |
|---|---|---|---|
| FQDN 先决条件 | 把动态关键词 cmdlet 存在当成 FQDN 一定可用 | 检查 OS build、Defender 平台/状态、Network Protection 与可观察到的 DoH | 源码静态核对；需 Windows 实机验证属性值和策略读取 |
| 静态 IP 规则 | 原本与动态 FQDN 规则处于同一建立路径，FQDN 失败容易使整个流程失败 | 静态 IP 规则先独立建立；FQDN 另行建立 | 源码静态核对；需 ActiveStore 测试 |
| FQDN 对象/规则失败 | 失败可能造成 Guard 整体启动失败，或让部分规则残留 | 对象失败则跳过；规则失败则删除本轮 Guard 规则并重建 IP-only | 源码静态核对；需模拟 PowerShell cmdlet 中途失败 |
| Watchdog 运行期兼容性变化 | 已建立 FQDN 后，系统前提变化没有明确降级路径 | 检查到能力不可用时移除 FQDN 规则并改为 IP-only | 源码静态核对；需 Windows 实机故障注入 |
| 零目标 | 规则期望数量为 0 会被当作不健康，空活动列表 JSON 可能为空文件 | Helper、Watchdog 保存 `[]`；Go 主程序再校验本会话空数组、ActiveStore BLOCK 和零 Guard 规则 | 源码静态检查；需 Windows ActiveStore 测试 |
| 规则关联 | 只核对动态对象存在不够完整 | 核对规则关联 ID、对象 FQDN 和 AutoResolve | 源码静态核对；需确认不同 Windows build 的 NetSecurity CIM 字段 |

## 尚未确认/实测项目

1. PowerShell 5.1 Parser 语法检查未执行；当前构建容器没有 `powershell.exe` / `pwsh`。
2. `Get-MpComputerStatus`、`Get-MpPreference` 的真实输出字段及不同 Defender 模式下的值，必须在目标 Windows 版本实测。
3. Edge/Chrome/Firefox 用户级偏好和应用自带 DoH 无法由当前策略注册表检查完整枚举；程序会警告，不能声称已经证明所有 DoH 均关闭。
4. Windows Server 不同版本、版本基线、Network Protection 开关组合尚未实测。
5. `Get-NetFirewallAddressFilter` 中动态地址 ID 的实际对象属性需在 Windows 10/11 的 ActiveStore 结果中确认。
6. 动态 FQDN 地址填充依赖应用实际 DNS 查询；代理、Secure DNS、VPN、DNS 缓存以及首连更新延迟可能让连接仍被 BLOCK。
7. 当前环境未执行 UAC、ACL、ActiveStore、WFP 5157 或异常退出测试。

## 结论

Go Windows x64 交叉编译、go vet 和 go test 编译检查成功。源码层面已建立“预检 → 静态 IP → 可选 FQDN → 失败退回 IP-only → 零目标保持 BLOCK-only”的流程，但不能据此声称 Windows 上的动态 FQDN 实际工作已通过验证。
