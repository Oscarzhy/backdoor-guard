# HachimiGuard GuardLauncher v17.3

Windows x64 Minecraft 防护启动器。v17.3 是基于 v17.2 的**FQDN 兼容性定向修复版**。本版只修改动态 FQDN / Windows Firewall Dynamic Keyword 的预检、建立、降级和重建路径；不改变允许域名、端口、Tencent 目录保护范围，也不修改 Java 进程识别逻辑。

## 保护行为（继承 v17.2）

- 保护当前用户默认 Tencent 目录，并读取 QQ `UserDataInfo.ini` 中的 `UserDataSavePath` 补充自定义路径。
- 严格出站隔离默认开启：Domain、Private、Public 配置文件设为默认出站 BLOCK，仅为指定启动器和 Java 可执行文件建立精确 TCP 目标规则。
- 默认目标来自 `AllowedDomains.txt`；Minecraft 服务器目标为 `3c3u.org:25565`，不会泛化放行整个 Minecraft 域名家族。
- 只撤销 Guard 有记录新增的 ACL Deny ACE；退出与遗留会话恢复继续使用 v17.2 的原有流程。
- 不修改 hosts。`--diagnose` 只检查，`--background` 只隐藏控制台，`--no-network-lock` 明确关闭本次会话的全局网络隔离。

## v17.3 FQDN 兼容性修复

1. **能力预检**：Helper 和 Watchdog 分别检查动态关键词相关 NetSecurity 命令及必要参数、Windows build、Microsoft Defender Antivirus 状态/平台版本、Network Protection 状态，以及可观察到的 DoH 配置。
2. **静态 IP 与 FQDN 分离**：已解析的静态 IP 规则独立建立，不依赖 FQDN 功能是否可用。FQDN 仅是补充能力，不再被当作系统必然支持的功能。
3. **不支持时降级**：系统版本、Defender 平台/状态、Network Protection 或已检测到的 DoH 条件不满足时，只保留已经解析的静态 IP 目标；未解析的域名跳过，默认出站 BLOCK 保持，不会降级为 `Any` 或宽泛地址放行。
4. **建立失败回退**：动态关键词对象或 FQDN 防火墙规则建立失败时，移除本轮 Guard 规则并仅重建明确解析出的静态 IP 规则。Watchdog 在运行期发现前置条件不再满足时，也会先移除 FQDN 规则，再按静态 IP 清单重建。
5. **零目标处理**：当静态 IP 和 FQDN 都不可用时，`active_endpoints.json` 保存为合法 JSON 空数组 `[]`。Helper、Watchdog 和主程序三层都认可这一状态：主程序会额外验证本会话的 `active_endpoints.json` 确实是合法空数组 `[]`，且 ActiveStore 三个配置文件仍然启用并默认出站 BLOCK；其他“规则数为 0”的情况仍然失败关闭。
6. **规则关联核对**：FQDN 规则自检会核对关联过滤器中的动态关键词 ID，并核对该 ID 对应的 FQDN 与 AutoResolve 属性。

## FQDN 的 Windows 前提与限制

- Microsoft Defender Antivirus 必须开启，平台版本至少 `4.18.2209.7`。
- Network Protection 必须为 Block 或 Audit。Windows Server 还需要相应的 Network Protection Server 开关。
- DoH 必须关闭。程序只读取可观察到的浏览器策略和 Windows DNS Client DoH AutoUpgrade 状态；它**无法枚举所有浏览器用户偏好、代理、VPN 或应用自带的 DNS-over-HTTPS 实现**。无法确认的情况会写入兼容性警告，仍需人工确认实际使用的应用已关闭 DoH。
- Windows Firewall FQDN 规则必须由应用实际发起匹配域名的 DNS 查询才能获得地址；代理、安全 DNS、某些 VPN 配置和缓存 IP 都可能使解析/放行无法按预期发生。首次连接也可能因防火墙地址更新延迟而被阻止，应用重试后才成功。
- Microsoft Firewall CSP 列出的客户端动态关键词最低支持基线为 Windows 10 20H2/21H1/21H2 对应 `KB5013942`（build `19042/19043/19044.1706`）及后续版本，以及 Windows 11 21H2 build `22000` 及后续版本。程序只把这些已知客户端基线用于版本预检；命令存在本身不代表运行环境满足全部 FQDN 条件。
- 程序不会为了启用 FQDN 自动修改 Defender、Network Protection、DoH、DNS、浏览器策略或 VPN 设置。

## 使用

- 解压到普通用户有写入权限的固定目录，保留 v17.1/v17.2 目录，不要覆盖旧版。
- 运行 `GuardLauncher_v17.3_x64.exe`，首次选择 Minecraft 启动器 EXE；也可传入路径：
  - `GuardLauncher_v17.3_x64.exe "C:\Path\MinecraftLauncher.exe"`
  - `GuardLauncher_v17.3_x64.exe --background "C:\Path\MinecraftLauncher.exe"`
  - `GuardLauncher_v17.3_x64.exe --diagnose`
  - `GuardLauncher_v17.3_x64.exe --no-network-lock "C:\Path\MinecraftLauncher.exe"`
- `--diagnose` 不修改 ACL 或防火墙；正式测试仍应使用独立测试目录，并准备好恢复点。

## 日志与状态

- 普通日志：程序目录的 `GuardLauncher.log`，不可写时回退用户本地应用数据目录。
- 管理员审计日志：`%ProgramData%\HachimiGuard\audit`。
- 会话状态：`%ProgramData%\HachimiGuard\session-*`。
- FQDN 前置条件、DoH 可见性、降级原因、动态关键词对象创建失败和规则重建结果会写入管理员审计日志。

## 安全边界

程序按可执行文件路径匹配启动器/Java，不等于签名或哈希身份验证；管理员级恶意程序不在威胁模型内。静态 IP 放行只适用于配置中明确解析出的地址，域名地址变更可能需要重新启动保护会话以刷新静态 IP 清单。

**本包不是 Windows 实机验证版。** 当前构建环境没有 Windows PowerShell Parser 和 Windows 防火墙/Defender 实机；首次使用前请在可恢复环境里验证 UAC、ActiveStore、Defender 状态读取、动态关键词 AutoResolve、DoH 场景以及 Watchdog 降级行为。

## 本地构建

在 Windows PowerShell 中运行 `build-local.ps1`。目标为 Windows amd64 Console 子系统，使用当前目录的 `GuardLauncher_v17.go`。
