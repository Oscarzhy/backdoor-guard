# v17.12 核心回归检查矩阵

| 场景 | 预期结果 |
|---|---|
| 旧会话 Group 在 PersistentStore 中不存在，ActiveStore 也不存在 | 规则清理成功，移除数为 0，继续恢复 dynamic/Allow/Profile/ACL |
| 旧会话 Group 在 PersistentStore 有规则 | 只删除精确 Group 的本地规则，继续检查 ActiveStore |
| 删除后 ActiveStore 仍有同 Group 规则 | 恢复步骤失败，保留恢复记录，不放宽用户 Allow/Profile |
| PersistentStore 或 ActiveStore 枚举失败 | 失败关闭，不作为零匹配成功 |
| Bootstrap 日志写入 FAILED，外层 PowerShell 返回 0 | Go 仍返回管理员组件失败，不显示管理员保护组件执行完成，不开始 Watchdog readiness 检查 |
| Bootstrap 写入错误文件但诊断日志无法读取 | Go 读取错误文件后返回失败 |
| Bootstrap 未写成功或失败标记 | 最多等待 120 秒后失败关闭 |
| Bootstrap 写入 HELPER_RESULT=OK | `runElevated` 可返回成功，主程序才开始 Watchdog readiness 验证 |
| Watchdog parent-ready/Mutex 父进程机制 | 维持 v17.11 行为 |

本矩阵为源码逻辑和静态检查目标，不代表已在 Windows 实机执行。
