# GuardLauncher v17.7 复审记录

## 本轮范围

只修复 v17.6 用户现场明确报告的两条启动/日志错误；不修改网络防火墙规则策略、ACL 保护策略、5157、会话锁、Watchdog 或 Java 进程归属。

## 静态确认

- 完整 Bootstrap 已从命令行移出，改为临时脚本文件。
- 只有小型安全 trampoline 经 `-EncodedCommand` 传递。
- trampoline 对 staging 路径、reparse point、目录 ACL、文件 ACL 进行检查/加固。
- trampoline 在执行 Bootstrap 前校验其 SHA-256。
- Helper、Config 的 SHA-256 核对保留。
- 新增 Bootstrap 和 trampoline PowerShell Parser 预检。
- UAC 长度限制从 26,000 Base64 字符改为 trampoline 14,000 Base64 字符、outer command 16,000 UTF-16 单元。
- `setSessionAuditPath` 在文件存在、普通文件、可追加全部通过后才绑定；初始化失败时错误留在 per-run log。
- ProgramData 环境变量去首尾空格并验证为绝对路径，输出路径改为 `%q`。
- 原有 FQDN、网络白名单、Tencent 路径、Java 识别、会话锁、Watchdog、5157、恢复记录和 ACL 逻辑未作功能修改。

## 构建结果

- `gofmt`：通过。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go`：退出码 0；输出 `[no test files]`。
- `go vet`：通过。
- Windows amd64 PE 构建：通过。
- 重复构建：两次独立构建逐字节一致。
- 代表性路径下 trampoline 长度：约 12,432 Base64 字符；outer command 约 12,726 UTF-16 单元。对 160/220/240/260 字符 staging 路径的估算仍低于 14,000/16,000 上限。
- 两次使用相同源码的独立 Windows amd64 构建产物逐字节相同。

## 未验证

- Windows PowerShell 5.1 Parser 和实际 -EncodedCommand 解析。
- UAC RunAs 行为、外层/提升进程 ExitCode 传递。
- Staging 文件/目录 ACL 与不同凭据的 UAC 情况。
- ProgramData 实际审计目录/文件创建及用户追加权限。
- 完整 Apply → Watchdog 就绪 → 正常恢复链路。

本报告不将交叉编译或静态分析等同于 Windows 功能通过。
