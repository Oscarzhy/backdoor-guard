# v17.12 构建状态（2026-11-08）

## 构建目标

- Windows x64（PE32+）
- Go 1.23.2
- `CGO_ENABLED=0`
- Schema 11

## 构建与检查

- `gofmt`：通过。
- `GOOS=windows GOARCH=amd64 go test GuardLauncher_v17.go`：通过；源文件无测试文件。
- `GOOS=windows GOARCH=amd64 go vet GuardLauncher_v17.go`：通过。
- `GOOS=windows GOARCH=amd64 go build -trimpath -ldflags="-s -w"`：通过。
- 重复构建：两次输出字节完全一致。
- 29 项针对性静态断言：全部通过。
- 配置文件 SHA-256 与 v17.11 一致。

## 当前 EXE SHA-256

`7eba0f11b2d88f477bdcef5440a6e5cb025df0fc5f3427c1e4adabd2e8bcff54`

## 运行时限制

构建容器不是 Windows，未执行真实 UAC/PowerShell 5.1/NetSecurity/CIM/NTFS/WMI 测试。请将本构建视为已编译并通过静态检查，不能将交叉编译描述为实机测试。
