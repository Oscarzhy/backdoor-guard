# ProgramData 旧状态目录处理指南（v17.11）

## 不要直接清空

`%ProgramData%\HachimiGuard\session-*` 可能保存防火墙 Profile、5157 初始状态、曾禁用的用户 Allow 规则、动态 FQDN 关键词 ID，以及 Guard 添加 ACL Deny ACE 的逐对象恢复记录。删除这些资料会破坏自动恢复所需的信息。

## 识别的历史版本

| Version | Schema |
|---|---:|
| v17.1 | 6 |
| v17.2–v17.4 | 7 |
| v17.5 | 8 |
| v17.6–v17.9 | 10 |
| v17.10–v17.11 | 11 |

v17.11 保持 Schema 11，与 v17.10 的 `session.json` 结构兼容。新版本使用的父进程 Mutex 名称由 Group 派生，不需要把 Mutex 句柄持久化到状态目录；旧会话没有 Mutex 时会退回直接 PID/进程创建时间探测。

## 会影响新会话的残留

- 非空 `session-*` 缺少 `session.json`。
- 元数据损坏、版本/Schema 未知、缺少 Group 或 SessionStartUtc。
- 会话目录所有者不符合 Administrators/SYSTEM 要求。
- Watchdog 仍在运行、进程归属无法确定、或任一恢复步骤失败。

这类情况会保留状态并阻止新会话，不会因“清空后重试”而跳过恢复。

## 通常不代表活动会话的残留

- 没有进程占用的 `active-session.lock` 文件本身；真正互斥由打开的独占句柄实现。
- `audit\` 下的历史 `.log`、`.watchdog.startup.log`、`.watchdog.stdout.log`、`.watchdog.stderr.log` 和 parent-ready 审计文件。
- 普通历史日志不会被作为活动会话依据，也不会在普通会话清理时删除。

## 处理建议

不要手工删除整个 StateRoot 或任意非空 session 目录。先关闭正在运行的 GuardLauncher/Watchdog 会话；不要结束不相关的 PowerShell 进程。保留 `audit\` 和异常 `session-*` 目录，提供目录列表、`session.json`（注意保留敏感信息，不要公开分享令牌）、相应 Watchdog 审计和主程序日志，由恢复逻辑识别具体版本及剩余规则/ACL 后再处理。
