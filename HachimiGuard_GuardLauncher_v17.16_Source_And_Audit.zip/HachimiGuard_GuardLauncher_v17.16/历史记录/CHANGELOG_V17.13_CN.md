# GuardLauncher v17.13 更新记录

## 本次修复

1. **旧 `disabled_allows.json` 兼容读取**
   - 使用 UTF-8 显式读取旧恢复日志，避免 Windows PowerShell 5.1 默认 ANSI 代码页破坏非 ASCII 防火墙规则名称。
   - 正常 JSON 解析失败时，仅尝试修复 `Fingerprint` 字段中未转义的双引号；不修改 `Name`、`Group`、`WasEnabled` 等字段。
   - 修复后仍无法解析则保留恢复记录并失败关闭，不会跳过整份恢复记录或盲目启用规则。
   - Helper 与 Watchdog 两套独立恢复/追加路径使用同一读取逻辑。

2. **防火墙 Profile 的 Enabled 类型修复**
   - 不再将普通 `System.Boolean` 直接传给 `Set-NetFirewallProfile -Enabled`。
   - 根据当前 NetSecurity 参数类型将基线中的 `True`、`False` 或 `NotConfigured` 转成对应 `GpoBoolean` 值；兼容转换器参数类型时，只传递上述白名单字符串。
   - Helper 的 `Restore-ProfileState` 与 Watchdog 的 `Restore-Profiles` 都已修复。

3. **恢复安全边界**
   - 只有指纹完全匹配的、此前确实启用的用户 Allow 规则才会重新启用。
   - 无法安全读取或验证的规则继续保持当前状态，恢复记录保留供检查/重试。
   - 不改变网络白名单、受保护目录、Java 路径和默认启动器配置。

## 兼容性

- 保持 Schema 11。
- 继续识别 v17.7–v17.13 历史会话格式。
- 版本历史文档集中在 `历史记录/`。
