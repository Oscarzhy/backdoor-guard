# GuardLauncher v17.7 静态审计摘要

## 审计范围

针对 v17.6 用户现场日志涉及的两个故障点，检查 UAC staging 生成、Bootstrap 完整性校验、Start-Process 参数构造和会话审计路径挂接时序；与 v17.6 源码逐行对比，确认改动未触及防火墙规则策略、ACL 保护策略和恢复算法。

## 结果

1. 完整 Bootstrap 不再进入 `-EncodedCommand`；只编码小型 trampoline，完整脚本写入 `bootstrap.ps1`。
2. trampoline 检查 staging 目录存在、是目录且不是 reparse point；收紧目录和文件 ACL 后才读取 Bootstrap。
3. trampoline 校验 Bootstrap SHA-256；Bootstrap 仍校验 Helper 和 Config SHA-256。
4. Bootstrap、trampoline、Watchdog、Helper 均进入本机 PowerShell Parser 预检流程。
5. staging 加固后如果 trampoline 尚未运行 Bootstrap 就失败，失败分支尝试恢复原调用用户的临时目录清理权限，避免临时目录因 ACL 收紧而残留；恢复时跳过 reparse point，不跟随链接修改外部目标。
6. 编码长度限制为 trampoline 14,000 Base64 字符，外层命令 16,000 UTF-16 单元；代表性路径测试结果如下：

| staging 根路径长度 | trampoline Base64 字符 | outer command UTF-16 单元 | 结果 |
|---:|---:|---:|---|
| 80 | 12,432 | 12,726 | 通过 |
| 160 | 13,072 | 13,366 | 通过 |
| 220 | 13,552 | 13,846 | 通过 |
| 240 | 13,712 | 14,006 | 通过 |
| 260 | 13,872 | 14,166 | 通过 |

7. `setSessionAuditPath` 只有在目标已存在、是普通文件且当前调用用户可追加时才绑定共享日志路径；UAC 启动前失败不会创建/绑定不存在的 ProgramData 文件。
8. UAC 失败详情仍保存在用户可写的每次运行日志和 staging 诊断文件；诊断文件创建失败会在 UAC 前明确返回错误，不再静默忽略。
9. `ProgramData` 环境值去除首尾空白并验证绝对路径，路径诊断使用带引号格式。

## 定向静态检查

- 旧 `encodedBootstrap` 命令行载荷已删除。
- 新 trampoline 与 Bootstrap 文件存在。
- Bootstrap、Helper、Config SHA-256 校验存在。
- 四个 PowerShell 脚本均加入 Parser 预检。
- Staging reparse point 检查与失败后清理权限恢复逻辑存在。
- 会话审计绑定前置 `Stat`、普通文件和追加权限检查存在。
- UAC 失败分支不再无条件绑定预计路径。
- ProgramData 首尾空白清理与绝对路径检查存在。

上述定向源码断言：**24/24 通过**。

## 构建

- Go 1.23.2。
- `gofmt` 通过。
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test GuardLauncher_v17.go` 退出码 0，输出 `[no test files]`。
- `go vet` 通过。
- Windows amd64 PE32+ Console 构建通过。
- 同一源码重复构建产物 SHA-256 完全相同。

## 未验证事项

当前环境没有 Windows PowerShell 5.1、UAC、NTFS 和真实 ProgramData。以下事项仍需 Windows 实机验证：PowerShell Parser 实际执行、Start-Process/UAC 参数传递、同一/不同提权账号的 staging ACL、Bootstrap 哈希失败后的 staging 清理、ProgramData 审计文件创建与调用用户追加权限、Helper Apply 与 Watchdog 完整接管。

Go 编译、字符串检查和命令长度估算不能替代上述 Windows 运行时测试。
