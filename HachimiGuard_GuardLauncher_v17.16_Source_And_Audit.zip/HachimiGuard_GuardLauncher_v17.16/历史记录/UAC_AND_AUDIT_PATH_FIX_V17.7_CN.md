# v17.7 UAC 启动与审计路径修复说明

## 用户现场日志

`UAC bootstrap command is too large (26540 Base64 characters); refusing to launch`

随后多次出现 `shared lifecycle audit append failed ... The system cannot find the path specified`。

## 根因分析

1. v17.6 的 `runElevated` 把整个 Bootstrap PowerShell 脚本 UTF-16LE Base64 编码，并嵌入外层 PowerShell 的 `Start-Process -EncodedCommand` 参数。
2. 现场长度 26,540，超过源码 26,000 的保护阈值，因此在调用 `exec.Command` 启动 UAC 之前直接返回。
3. ProgramData 会话审计目录/文件由 Bootstrap/管理员 Helper 创建；但 v17.6 的错误分支仍无条件调用 `setSessionAuditPath`，随后的 `writeFileLog` 反复向尚未创建的路径追加日志。
4. 因此，日志路径不存在是 UAC 未启动后由错误绑定时序造成的次生错误；仅调整 ACL 或手动创建目录不能解决命令长度的首要故障。

## v17.7 设计

- 完整 Bootstrap 放到临时目录 `bootstrap.ps1`。
- 命令行只传入小型 trampoline 的 EncodedCommand。
- 提权后的 trampoline 首先检查 staging 根目录是否是 reparse point；之后收紧目录及其文件 ACL。
- 在执行 Bootstrap 前计算并比较 SHA-256；不匹配时拒绝执行并写入 staging 诊断日志。
- Bootstrap 继续校验 Helper/Config 的 SHA-256；Helper/Watchdog/Bootstrap/trampoline 都执行本机 PowerShell Parser 预检。
- 审计路径只在文件已存在、为普通文件且调用用户可追加时才登记。尚未完成提权时，所有错误保留在普通运行日志中，不绑定不存在的 ProgramData 路径。
- ProgramData 环境变量先去首尾空白并验证绝对路径；路径日志用引用格式输出。

## 静态长度估算

在代表性 Windows 临时路径（含空格）下，代表性 staging 路径长度约 80 字符时，trampoline 约 4,661 个 UTF-16 单元、12,432 个 Base64 字符；outer command 约 12,726 个 UTF-16 单元。对 160/220/240/260 字符 staging 路径的估算结果仍低于本版硬上限（对应 Base64 13,072/13,552/13,712/13,872 字符）。实际机器路径长度不同，程序会在运行时记录真实长度并执行 14,000/16,000 的硬上限检查。

## 验收步骤

1. 使用 v17.7 在普通 Windows 用户目录运行，检查主日志出现 `UAC command length: trampolineBase64=... outerCommand=...`，不再出现 26,000 字符 Bootstrap 长度拒绝。
2. 确认 UAC 提示出现；同意后检查 `%TEMP%` staging 诊断和 ProgramData 会话审计。
3. 检查 Bootstrap SHA-256、Helper SHA-256、Config SHA-256 均成功。
4. 正常进入 Watchdog 就绪状态，检查会话审计文件存在且主程序成功附加。
5. 用诊断或受控方式触发 UAC 启动前失败，确认只记录一条“session audit was not created...”警告；不再出现多条 `shared lifecycle audit append failed`。
6. 用带空格的 Windows 用户目录测试 staging 路径；确认引用格式日志路径准确。

## 未完成的实机确认

当前构建容器没有 Windows PowerShell 5.1、UAC、NTFS 和真实 ProgramData 环境。因此 PowerShell Parser、UAC 弹窗、Staging ACL 修改、提权账号不同于调用账号、文件哈希失败路径、审计文件附加权限都必须在 Windows 实机验证。
