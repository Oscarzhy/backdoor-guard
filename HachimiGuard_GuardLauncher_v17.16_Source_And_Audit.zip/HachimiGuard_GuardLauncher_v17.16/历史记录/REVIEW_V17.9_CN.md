# v17.9 代码复审

## 本轮确认并修复

- v17.8 Watchdog 从未见过 Minecraft target 时，60 秒后无条件进入恢复；其 `Get-SessionProcessState` 虽然返回 `ParentAlive`，循环却没有使用该字段。该缺陷可在 GuardLauncher 仍处于启动流程时提前恢复并删除状态目录。
- v17.8 `waitForWatchdogReady` 在第一次 `os.Stat(StateDir)` 失败时立即返回，未使用设定的等待窗口。
- ParentPath 的路径表示差异可能令 parent identity false negative。增加严格 basename 兼容回退，并保留 PID 创建时间约束。

## 仍需实机验证

- PowerShell 5.1 的脚本解析、表达式返回值和 CIM 字段。
- 实际 GuardLauncher 进程路径与 `Win32_Process.ExecutablePath` 是否相同或进入 basename 回退。
- UAC Helper/Watchdog 锁交接与持久化心跳。
- 主进程持续运行超过 60 秒、游戏出现后关闭、主进程异常退出三种生命周期。

## 未改动

本批未修改防火墙、FQDN、ACL 规则、5157、原子记录、UAC 启动参数或配置文件。

## 附加核对

- `ResumeWatchdog` 原有 5 秒 no-target grace 保留；仅把其计时起点延后到 GuardLauncher 父进程确认退出后。
- 普通 Apply 会话使用 60 秒父进程退出宽限期。
- 目标出现后继续使用 30 秒目标活动结束规则；父进程存活不阻止这条恢复路径。
- 13/13 定向静态断言通过；独立二次构建与交付 EXE 字节级一致。
