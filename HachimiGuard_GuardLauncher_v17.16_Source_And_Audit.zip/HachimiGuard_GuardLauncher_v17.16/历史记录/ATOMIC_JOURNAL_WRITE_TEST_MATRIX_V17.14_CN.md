# v17.14 原子 journal 写入测试矩阵

| 场景 | 预期行为 | 本轮验证范围 |
|---|---|---|
| 第一次创建目标文件 | 同目录 `.tmp` 完整写入并 Flush，随后 Move 成为目标 | 静态通过；未在 Windows 执行 |
| 第二次更新已存在目标 | 使用明确的同目录 `.bak` 路径调用 File.Replace | 静态通过；需 Windows 实测 |
| 连续写入多次 | 每次生成新的随机临时文件和备份路径，目标始终存在 | 静态通过；需 Windows 实测 |
| 替换成功 | 先确认目标存在，再删除旧内容备份 | 静态通过；需 Windows 实测 |
| 备份删除失败 | 新 journal 仍视为已提交，记录警告并保留备份 | 静态通过；需 Windows 实测 |
| 替换失败 | 不直接覆盖目标；记录 source/destination/backup 路径与存在状态 | 静态通过；需 Windows 故障注入 |
| 替换失败且 backup 存在 | 保留 backup，避免丢失旧 journal | 静态通过；需 Windows 故障注入 |
| 首次 Move 发生竞争 | 若目标已被另一进程创建，使用显式备份 File.Replace 路径 | 静态通过；需 Windows 并发测试 |
| Helper 与 Watchdog | 两者嵌入相同持久化函数，不存在第二份旧实现 | 静态通过 |
| Allow 规则变更顺序 | 持久化恢复记录成功之后，才禁用用户 Allow | 静态通过 |

## 目标机验收建议

1. 启动 v17.14，确认 `disabled_allows.json` 第一次写入成功。
2. 让审计流程写入第二条及后续 Allow 记录，确认第二次/多次写入不再出现 `Replace` 路径异常。
3. 检查 StateDir 中没有未解释的 `.bak` 文件；若有，结合日志判断是清理失败后保留还是替换失败现场。
4. 启动成功后，结束 Minecraft，检查 Watchdog 完整恢复防火墙 Profile、Guard 规则和原有 Allow 规则。
5. 另做故障注入时，不要在真实用户防火墙规则上随意制造不一致；使用测试机/虚拟机和可回滚快照。
