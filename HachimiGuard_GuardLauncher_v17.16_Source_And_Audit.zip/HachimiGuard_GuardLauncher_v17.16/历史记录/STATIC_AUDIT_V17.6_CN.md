# GuardLauncher v17.6 静态审计摘要

## 结果

- Go 代码完成 gofmt、Windows amd64 目标 go test 编译检查、go vet 和 go build。
- Helper / Watchdog 合并后的 PowerShell 源文本进行引号与括号/花括号/方括号平衡检查。
- 检查了 try/catch/finally 结构数量关系与关键恢复函数/日志调用存在性。
- 检查 ZIP 内容、EXE PE 架构和 SHA-256 清单。

## 本轮关键实现

| 区域 | 静态确认项 |
|---|---|
| 5157 | Helper/Watchdog 使用同一 Restore-AuditStateFromPath |
| 审计状态 | GUID 查询、原始/预期状态比对、恢复后验证 |
| 原子文件 | 同目录临时文件、Flush(true)、Replace/Move |
| ACL 写前日志 | 每对象 JSON 原子提交后才写 DACL |
| ACL manifest | Schema、Group、RecordCount 与实际记录数核对 |
| 记录损坏 | JSON 解析失败或计数缺失时保留会话并拒绝清理 |
| ACL 覆盖 | 目录树枚举、继承关闭子对象显式 ACE、写入后验证 |
| Reparse | 不跟随；路径告警并标记 COVERAGE_INCOMPLETE |
| 恢复隔离 | Firewall rules remain 时不恢复用户 Allow/Profile，ACL/5157 独立继续 |
| 日志 | 分组 START/SUCCESS/FAILURE、retry、异常与 ScriptStackTrace |

- stale recovery Profile baseline 判断包含 `firewall_profile_apply_started`，不只依赖规则存在或 cleanup marker。
- Watchdog 脚本写入使用 UTF-8 BOM 前导字节，兼容 Windows PowerShell 5.1 的非 ASCII 脚本文字读取。

## 静态检查限制

当前执行环境为 Linux。未运行 Windows PowerShell 5.1 Parser，未调用真实 `auditpol`、NetSecurity、NTFS ACL 或 WFP API。自定义 PowerShell 结构检查不是微软 PowerShell Parser，不能证明所有脚本在目标机器上可执行。`go test` 显示 `[no test files]`，只说明无 Go 测试文件且目标编译检查通过，不代表业务功能经过自动化测试。
