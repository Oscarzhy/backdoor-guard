# HachimiGuard GuardLauncher v17.12

## 本版本定位

v17.12 基于 v17.11 清理版源码修订，针对 2026-11-08 用户提供的 Windows PowerShell 5.1 原始日志，修复两处相互叠加的问题：旧 v17.7 会话恢复时，`Remove-NetFirewallRule -Group` 在没有匹配规则时抛出 CIM 异常；同时，Go 主程序在外层 PowerShell 返回退出码 0 时，没有再次核对 Bootstrap 是否确实成功，导致 Bootstrap 已写 `FAILED`，主界面却显示“管理员保护组件执行完成”。

本版保留 v17.11 的父进程 Mutex 租约、Windows 进程句柄核验、parent-ready 确认、状态目录删除审计、旧会话版本兼容、网络白名单、Tencent ACL、5157 审计及恢复策略。Schema 仍为 11。`AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 与 v17.11 完全一致。

## 本次重要修改

1. **旧会话防火墙清理改为幂等操作。** 不再直接调用 `Remove-NetFirewallRule -Group <Group>`。新逻辑枚举 `PersistentStore`，在内存中按精确 Group 比对，只删除属于 Guard 当前随机 Group 的本地规则；如果没有匹配规则，移除数量为 0 并视为成功。之后枚举 `ActiveStore` 复核同 Group 规则是否仍存在。若存在任何残留（包括无法由 Guard 修改的策略规则），仍然失败并保留会话恢复记录，不会继续放宽 Allow/Profile 状态。
2. **覆盖 Helper 与 Watchdog 的规则清理入口。** Apply 前清理、FQDN 降级、Helper 恢复、Watchdog 规则重建及 Watchdog 恢复均复用同一清理函数，避免仅修复旧会话扫描、却在正常 Restore 路径再次遇到“零匹配”异常。
3. **增加独立的 UAC Bootstrap 成功握手。** Bootstrap 在 Helper 返回 `HACHIMIGUARD_OK` 后写入 `HELPER_RESULT=OK`。Go 主程序在外层 PowerShell 返回后，必须从本次唯一临时目录中的 Bootstrap 诊断日志读到该确切标记，才将 `runElevated` 判定为成功。如果发现 `[bootstrap] FAILED`、错误文件或超时仍无成功标记，均返回失败，不再报告“管理员保护组件执行完成”，也不会继续等待尚未创建的 Watchdog StateDir。
4. **失败信息前移。** 旧会话恢复失败会直接以管理员组件启动失败返回；Bootstrap 诊断正文会进入主日志和单独的 `uac-failure-*.log`，而不是让后续的 Watchdog StateDir 不存在错误掩盖真正原因。
5. **保留安全边界。** 规则查询本身失败、PersistentStore 删除失败、或 ActiveStore 仍有同 Group 规则时，均不将失败降级为空结果；只有“确实查询成功且没有匹配规则”才作为幂等成功。

## 对用户这次日志的解释

原始日志顺序为：

- `recovery-inventory` 发现一个旧 v17.7 / Schema 10 会话。
- `stale-firewall-rules-remove` 因没有匹配 `RuleGroup` 的规则而失败。
- 动态对象、用户 Allow 和 Profile 恢复被延迟，`Recover-StaleSessions` 抛出“遗留会话恢复不完整”。
- Bootstrap 明确写入 `FAILED`。
- 主程序却显示管理员组件成功，并等待一个本次从未创建的 `session-7828...`，最终触发 Watchdog StateDir 超时。

因此这次 StateDir 错误是前置 Helper/Bootstrap 失败后的次生错误。此前的 Watchdog 父进程存活修复并没有消除此处的零匹配规则清理和成功状态误判。v17.12 同时修复这两处。

Microsoft 的 NetSecurity 文档说明 `Remove-NetFirewallRule` 可以按 `-Group` 查询并删除匹配规则；本版改为先取得实际规则对象，再使用 `-InputObject` 删除，避免将“查询到零匹配”本身作为删除命令的失败条件。参见：<https://learn.microsoft.com/powershell/module/netsecurity/remove-netfirewallrule>。

## 使用说明

1. 将本包解压到独立目录，不要覆盖 v17.11 或 v17.10。
2. 本包根目录只包含 v17.12 当前 EXE、源码、配置、构建脚本和当前文档；旧版本 Markdown 统一放在 `历史记录/`，不包含旧版 EXE。
3. 运行 `GuardLauncher_v17.12_x64.exe`。启动日志应显示 `HachimiGuard v17.12`。
4. 对这次失败留下的 `%ProgramData%\HachimiGuard\session-fbdf870ea5ebe864` 不要手动删除。v17.12 会再次尝试按旧会话恢复记录处理它；如仍有实际规则、动态对象或 Profile 恢复失败，日志会保留具体失败项和目录供重试。

## 验证边界

本次已完成 Go Windows/amd64 交叉编译、Go test（该源文件无单元测试文件）、go vet、重复构建比对、ZIP 完整性及静态断言。当前执行环境不是 Windows，无法实际调用 Windows PowerShell 5.1、UAC、NetSecurity CIM Provider、Windows Firewall PersistentStore/ActiveStore、CIM/WMI 或 NTFS ACL。因此不能将静态检查声称为用户电脑上的实机验证。建议先保留 v17.11 和原有 ProgramData 日志，在 Windows 上用 v17.12 做一次启动验证。
