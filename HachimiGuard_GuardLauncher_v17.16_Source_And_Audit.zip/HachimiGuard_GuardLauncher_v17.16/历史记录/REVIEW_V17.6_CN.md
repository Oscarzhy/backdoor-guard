# GuardLauncher v17.6 复审记录

## 本轮覆盖

- 5157：Helper/Watchdog 共用恢复函数；核对原始状态、Guard 预期状态和当前状态；恢复后再读验证。
- ACL journal：原子写入 per-object JSON；manifest RecordCount 与实际文件数比对；损坏记录抛错并保留会话。
- ACL tree：递归目录/文件检查；显式 Deny 写前记录；重新读取验证；reparse point 不跟随。
- 恢复流程：Firewall 与 ACL/5157 独立记录；Firewall Guard 规则残留时不放宽 Profile/用户 Allow；失败保留状态以重试。
- 日志：统一审计文件追加/Flush；记录目录树统计、失败路径、PowerShell 堆栈和恢复重试。

## 已发现并在本版处理

1. Watchdog 重试块的 PowerShell try/catch 结构不完整：补齐每次重试异常捕获、完整错误日志和 RecoveryFailed 心跳。
2. 空 ACL journal 与 journal 丢失无法区分：加入 schema/group/record count manifest。
3. ACL per-object JSON 缺少 manifest 可能被误当作恢复来源：现在拒绝自动清理并保留现场。
4. Reparse point 以前跳过但仍可能把树报告成完整：现在明确 COVERAGE_INCOMPLETE，并使根保护失败关闭。
5. Watchdog 每 5 秒重复读取全部 ACL 文件：加入会话只读快照缓存，真正恢复时强制刷新。
6. Watchdog 脚本写入不原子：改用同目录原子写入并保留 UTF-8 BOM。
7. Stale session 目录枚举和 metadata 缺失以前提示不够明确：增加持久化日志，无法安全确认时保留状态。

- 复查 stale-session 分支时发现：若 Profile 已改变但 Guard 规则被外部删除，且尚未写 firewall cleanup marker，旧条件可能跳过 Profile 恢复；现在也检查 `firewall_profile_apply_started`。
- Watchdog 脚本原子写入使用 UTF-8 BOM；显式写入 `UTF8Encoding.GetPreamble()`，因为 `GetBytes()` 本身不会自动附加 BOM。

## 尚未 Windows 实测的风险

- auditpol CSV 在各 Windows 显示语言和域策略环境的字段表现，需要实机验证；未知状态会失败保守，不执行猜测恢复。
- 文件系统/杀毒软件可能短暂锁住临时文件或阻止 File.Replace；原子提交失败会阻止后续 ACL 变更并保留状态。
- 大型 Tencent 目录逐对象写前日志会增加启动 I/O；需要用真实用户数据量测量。
- ACL reparse point 的目标不会被自动保护；必须单独评估并作为独立路径加入保护范围。
- 5157 审计只能根据可观察的当前状态与 Guard 预期状态判断；若外部策略恰好设置为相同值，无法从 Windows 审计策略接口证明修改者身份。

本报告仅为源码复审，不等同于 Windows 运行时确认。
