# GuardLauncher v17.9 变更记录

基线：v17.8 Watchdog Wait Fix。此次针对真实现场的 `session-*` 状态目录在 Watchdog 初始就绪前消失问题，修复 Watchdog 无目标宽限期与 GuardLauncher 父进程生命周期脱节，以及 Go 状态目录就绪检查过早退出的问题。

1. **父进程存活保护**：在尚未出现 Minecraft 启动器/Java 前，只要本会话 GuardLauncher 父进程仍存活，Watchdog 就继续维持保护，不触发无目标清理。
2. **父进程退出宽限**：仅当目标从未出现且 GuardLauncher 父进程已确认退出，才从该时刻开始 60 秒恢复宽限期。
3. **不影响游戏退出恢复**：一旦 Minecraft 启动器或 Java 已出现，仍使用目标进程活动及原有 30 秒 launcher-to-Java handoff 窗口；GuardLauncher 主进程继续存活不会阻止游戏结束后的正常恢复。
4. **父进程路径兼容**：完整路径匹配仍优先；路径表示不一致时，允许 PID + 创建时间不晚于 SessionStartUtc + 完全相同 basename 的兼容回退，记录 `ParentPathMatchedByName`。排除会话后 PID 重用。
5. **就绪检查重试**：`waitForWatchdogReady` 不再因首次 `os.Stat(StateDir)` 失败立即退出；在 15 秒窗口内重试并保留最后错误、目录不可用观察次数。持续缺失时依旧失败关闭。
6. **保留重启宽限策略**：`ResumeWatchdog` 原有 5 秒无目标宽限仍保留，但只在确认 GuardLauncher 父进程退出后开始计时；普通 Apply 会话仍使用 60 秒。
7. **日志**：记录 GuardLauncher 父进程身份状态变化、路径兼容回退、父进程退出与宽限期起点、持续等待启动器原因。

未改变 UAC trampoline、网络白名单、FQDN 降级、Java 游戏参数识别、会话锁、5157、原子恢复记录、ACL 策略和配置文件。
