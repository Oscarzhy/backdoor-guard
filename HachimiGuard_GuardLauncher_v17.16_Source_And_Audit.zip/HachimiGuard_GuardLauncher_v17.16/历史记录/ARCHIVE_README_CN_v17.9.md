# HachimiGuard GuardLauncher v17.9

v17.9 基于 v17.8 修复 Watchdog 在主程序尚未完成启动时，可能因 60 秒无 Minecraft 目标进程而提前恢复并删除会话状态目录的问题。v17.8 的 UAC 等待范围修复、v17.7 staging SHA-256 校验，以及此前的网络、Java 进程、会话互斥、5157、原子恢复记录和 ACL 逻辑均保留。

## v17.9 主要变化

- Minecraft 目标进程尚未出现时，只要本会话 GuardLauncher 主进程仍然存活，Watchdog 就继续保持保护，不启动无目标恢复倒计时。
- GuardLauncher 主进程确认退出后，才开始 60 秒无目标恢复宽限。
- Minecraft 目标出现后，依旧按目标进程最后活动和 30 秒启动器/Java 交接窗口恢复；父进程继续存活不会阻止正常退出清理。
- ParentPath 完整路径不匹配时，只有 PID、创建时间和完全相同的可执行文件 basename 均匹配，才启用兼容回退。
- Go 就绪检查在状态目录暂不可用时会重试整个就绪窗口，持续失败时仍然失败关闭并保留诊断。

## 测试

优先测试：UAC 后不启动 Minecraft、等待超过 60 秒、再启动游戏；正常关闭游戏；启动器尚未出现时关闭 GuardLauncher。详见 `WATCHDOG_PARENT_LIFETIME_TEST_MATRIX_V17.9_CN.md`。

当前交付为源码/交叉编译版。没有 Windows PowerShell 5.1、UAC、CIM、NTFS 与防火墙实机执行证据，不应把它视为已完成 Windows 稳定性验收。
