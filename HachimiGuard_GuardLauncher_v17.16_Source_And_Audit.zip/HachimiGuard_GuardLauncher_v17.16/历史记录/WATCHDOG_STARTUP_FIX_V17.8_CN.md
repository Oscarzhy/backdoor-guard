# v17.8 Watchdog 就绪超时根因与修复

## 用户现场错误

`Watchdog initial readiness failed: 读取 Watchdog 心跳失败 ... watchdog.heartbeat.json: The system cannot find the file specified.`

用户说明图片文字由平板 OCR 识别，路径中的空格、全半角冒号和反斜杠可能被错误识别；因此本次不把 OCR 转写中的字符差异当作路径错误证据。

## 源码根因

v17.7 `runElevated` 生成的外层 PowerShell 命令使用：

- `Start-Process -Verb RunAs -PassThru ... -Wait`

与此同时，Helper 的 `Start-SessionWatchdog` 会启动一个长期运行的 PowerShell Watchdog 子进程。Microsoft Learn 的 Windows PowerShell 5.1 文档明确说明，`Start-Process -Wait` 等待指定进程和其所有子进程；相对地，`Wait-Process` 只等待明确指定的进程对象/进程。

因此外层 UAC 调用可能一直等待 Watchdog 子进程，主程序无法及时从 `runElevated` 返回，也就无法在正确时点启动 Minecraft。Watchdog 的“尚未看到目标进程”宽限期却已经开始，最终可能提前进入恢复并删除心跳文件。主程序随后报告心跳文件不存在。这是等待范围的生命周期错误，不是单凭日志就能确定的路径拼写错误。

## v17.8 修复

1. 启动 UAC Bootstrap 时使用 `Start-Process -PassThru`，不使用 `-Wait`。
2. 使用 `Wait-Process -InputObject $p` 只等待 Bootstrap 本身退出。
3. 刷新 Process 对象并核对 `HasExited`，然后返回 Bootstrap 的 ExitCode。
4. Watchdog 子进程仍独立运行；Helper 仍必须观察到与会话组、PID、创建时间匹配的新鲜心跳才能返回成功。
5. 增加独立的 stdout、stderr 和 startup 诊断文件，且放在持久化审计目录，不放在可能被恢复流程删除的 session 目录。
6. Helper 与主程序的心跳超时错误会包含最近的 Watchdog 启动诊断。

## 为什么没有降低心跳要求

本次没有把“进程存在”改成“Watchdog 就绪”，也没有在找不到心跳时放行。主程序仍要求新鲜心跳、正确会话组、正确 PID 和进程映像/创建时间验证。只修正了 UAC 调用的等待对象。

## 验收步骤

1. 启动 v17.8，完成 UAC。
2. 确认 `runElevated(Apply)` 在 Helper/Bootstrap 返回后及时返回，不再等待 Watchdog 退出。
3. 确认主程序随后读到 `watchdog.heartbeat.json`，状态为 `Starting` 或 `Monitoring`，PID 和进程创建时间匹配。
4. 确认 Minecraft 可以在 Watchdog 60 秒无目标宽限期内正常启动。
5. 检查 `%ProgramData%\HachimiGuard\audit` 中对应会话的 `*.watchdog.startup.log`、`*.watchdog.stdout.log`、`*.watchdog.stderr.log`。
6. 正常关闭 Minecraft，确认 Watchdog 仍完成恢复；不要通过手动删除心跳或状态目录模拟恢复。

## 尚未验证

当前构建容器没有 Windows PowerShell 5.1、UAC、NTFS 和真实 Windows 进程树。因此本版能确认源码改动和 Go Windows x64 构建，但仍需在 Windows 实机确认 `Start-Process -Verb RunAs -PassThru` 返回的 Process 对象、`Wait-Process -InputObject`、子进程独立运行和心跳交接。
