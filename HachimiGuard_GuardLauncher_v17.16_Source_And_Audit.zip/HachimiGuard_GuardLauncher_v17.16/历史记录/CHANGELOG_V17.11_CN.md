# GuardLauncher v17.11 变更记录

- 新增父进程内核 Mutex 租约，GuardLauncher 在 UAC 前创建，并持有至主进程结束。
- Watchdog 的父进程状态改为结合 CIM、命名 Mutex 和 `System.Diagnostics.Process` 独立复核；无法确认时保留保护。
- 未确认 parent-ready 的孤儿清理路径、正常无目标清理路径，均加入最后一次父进程状态复核。
- 修正 `StateDir` 不存在观察计数：对 `%w` 包装的 `os.ErrNotExist` 使用 `errors.Is`。
- 为 Watchdog、Helper Watchdog、最终 Restore、Apply 回滚、旧会话恢复及空孤儿目录清理补充删除前/完成后的审计标记；普通目标退出路径的父进程状态日志兼容空值。
- 当前版本号、构建输出、EXE 文件名统一更新为 v17.11；历史会话表增加 v17.11 / Schema 11。
- 保持 Schema 11 与 v17.10 兼容；网络/ACL/Java/默认启动器配置内容不变。

## 未完成的实机验证

尚未在真实 Windows 机器上验证 UAC、PowerShell 5.1 Parser、命名 Mutex 跨进程互操作、CIM 短暂遗漏、进程 PID 重用、Watchdog 故障注入和完整恢复流程。Go 构建通过不等于这些 Windows 运行条件已经通过。


## 发布包整理

- 发布包只保留 v17.11 当前 EXE，不再重复携带用户已有的 v17.10 或更早版本程序。
- 所有旧版 Markdown 版本记录继续保留，统一移动到 `历史记录/`。
- 根目录保留当前源码、配置、构建脚本和 v17.11 使用说明，减少误启动旧程序的可能。
