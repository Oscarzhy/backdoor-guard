# v17.12 变更记录

日期：2026-11-08

## 修复

- 修复旧会话恢复在 `Remove-NetFirewallRule -Group` 没有匹配规则时被 NetSecurity/CIM Provider 抛出异常的问题。
- 新增精确 Group 的 PersistentStore 枚举与 InputObject 删除；无匹配规则视为幂等成功；删除后仍强制核验 ActiveStore。
- 将 Helper 与 Watchdog 的所有 Guard Group 删除入口统一到幂等删除函数。
- 修复外层 UAC PowerShell 返回 0 时，主程序未校验 Bootstrap 成功标记而误报管理员组件成功的问题。
- `runElevated` 现在要求读取本次 Bootstrap 的 `[bootstrap] HELPER_RESULT=OK`，发现 FAILED、错误文件或缺少标记超时均按失败处理。
- 将真实 Bootstrap 错误提前返回，避免随后出现误导性的 Watchdog StateDir 不存在错误。

## 保留

- v17.11 父进程 Mutex 租约、直接进程身份核验和 parent-ready 机制。
- Schema 11、旧会话版本映射及网络/ACL/恢复配置。
- v17.11 以来的全部历史 Markdown，继续保存在 `历史记录/`。

## 未宣称

- 未完成 Windows 实机 UAC/PowerShell 5.1/NetSecurity/NTFS 测试。
- 未声称用户机器上的旧会话恢复已在此构建环境中实测成功。
