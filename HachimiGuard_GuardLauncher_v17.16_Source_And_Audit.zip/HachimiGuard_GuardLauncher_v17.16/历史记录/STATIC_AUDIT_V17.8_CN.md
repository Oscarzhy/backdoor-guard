# GuardLauncher v17.8 静态审计摘要

## 审计范围

仅检查 v17.7 用户现场 Watchdog readiness 错误涉及的 UAC 外层等待行为、Helper 子进程启动、Watchdog 首次心跳、持久化启动诊断和主程序超时读取路径。未重构原有网络、ACL、5157 或恢复策略。

## 结果

1. UAC 外层原先使用 `Start-Process -Wait`；该参数会等待进程树，包含 Helper 启动的长期 Watchdog。
2. 已改为 `Start-Process -PassThru` + `Wait-Process -InputObject $p`，只等待明确的管理员 Bootstrap Process 对象。
3. Bootstrap 退出后检查 `HasExited` 并读取其 ExitCode；UAC 启动失败仍会向上报告，不会错误报告成功。
4. Watchdog 本身仍在 Helper 的锁交接后取得全局锁，并先写入带 PID/Group/创建时间的心跳；未降低主程序的心跳身份验证条件。
5. Watchdog stdout/stderr 与启动阶段诊断保存在 `%ProgramData%\HachimiGuard\audit` 下的会话专属文件，避免 Watchdog 删除 `session-*` 状态目录时丢失诊断。
6. Helper 超时握手会记录子进程退出码、最后心跳校验错误、启动日志和 stdout/stderr 尾部。
7. Go 主程序心跳超时也从相同审计目录读取最多 4 KiB/文件的诊断尾部。
8. `AllowedDomains.txt`、`ProtectedPaths.txt`、`JavaPaths.txt`、`DefaultLauncherPath.txt` 与 v17.7 逐字节一致。
9. Go 源码版本标识改为 v17.8，构建脚本输出文件名同步更新。

## 定向静态断言

- 无 `Start-Process ... -Verb RunAs ... -Wait` 的 UAC 等待路径。
- 存在 `Wait-Process -InputObject $p`。
- Watchdog 子进程启动不包含 `-Wait`。
- stdout/stderr 重定向目标位于会话审计目录。
- Watchdog startup log 记录脚本入口、锁获取和首次心跳结果。
- Go 主程序诊断读取与 PowerShell 写入使用相同的文件名规则。
- 原有 Helper 心跳验证条件（Schema/Group/PID/新鲜时间/创建时间）保持。

## 构建

Go 1.23.2，Linux amd64 交叉编译 Windows amd64；`gofmt`、`GOOS=windows GOARCH=amd64 go test` 编译检查、`go vet` 和 `go build` 通过。`go test` 输出 `[no test files]`，无 Go 业务测试用例。

## 未验证

当前环境没有 PowerShell 5.1/Windows/UAC/NTFS。PowerShell Parser 和运行时进程树测试未执行；因此本报告不把静态检查称作 Windows 功能测试。
