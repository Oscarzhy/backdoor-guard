# GuardLauncher v17.14 更新记录

## 修复：原子写入目标已存在时替换失败

v17.13 的实机日志显示：`disabled_allows.json` 第一次写入成功，随后再次更新时，`System.IO.File.Replace` 在 Windows PowerShell 5.1 中抛出“路径的形式不合法”。异常发生在 `Save-DisabledAllows`，随后触发 Helper 回滚。

v17.14 将所有已存在目标文件的原子替换改为：

1. 在目标文件同一目录创建唯一 `.tmp` 源文件并写入完整内容，执行 `Flush(true)`。
2. 为旧目标生成同目录、唯一 `.bak` 文件路径。
3. 将 `.tmp`、目标文件和明确的 `.bak` 路径作为字符串参数传给 `File.Replace(..., true)`，不再向 PowerShell 方法绑定传递 null 备份路径。
4. 检查目标文件在替换后仍然存在，再删除旧内容备份。若备份删除失败，只记警告，不把已提交的新 journal 误报为写入失败。
5. 替换失败时保留任何存在的 `.bak`，并将 source/destination/backup 路径及存在状态写入异常信息；绝不改用非原子覆盖。

首次写入仍使用同目录 `File.Move`；若另一个进程在首次写入竞争中先创建目标，则使用相同的显式备份替换流程。

## 安全与兼容

- `Write-AtomicText` 属于 Helper 与 Watchdog 共用的持久化函数；两条执行路径均得到本次修复。
- 用户防火墙 Allow 规则依旧先写入恢复 journal，再执行 `Disable-NetFirewallRule`。journal 写入失败时，禁止继续禁用该规则。
- Schema 维持 11，并将 `v17.14` 加入后续版本识别旧会话的兼容映射。
- AllowedDomains、ProtectedPaths、JavaPaths、DefaultLauncherPath 配置不变。

## 对本次实机日志的结论

旧 v17.7 会话的恢复步骤全部完成。新会话在 journal 第二次写入时失败，Helper 已回滚并删除本次 StateDir，主程序正确以 `exitCode=5` 退出。该日志没有显示 Watchdog 就绪超时。

## 验证边界

本轮确认源码级修复和 Linux 环境 Windows x64 编译/静态检查；尚未在 Windows PowerShell 5.1 + NTFS + NetSecurity 环境进行真实重复写入和防火墙恢复。
