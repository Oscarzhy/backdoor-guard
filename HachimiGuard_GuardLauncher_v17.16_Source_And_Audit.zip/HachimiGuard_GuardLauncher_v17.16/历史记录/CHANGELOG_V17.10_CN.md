# GuardLauncher v17.10 变更记录

## 修复

- 新增 Watchdog parent-ready acknowledgement：会话 Group、ParentPID、随机 Token、ReadyUtc 必须匹配。
- Watchdog 在 parent-ready 确认前保持保护，不执行常规自动恢复或删除 StateDir；父进程确认退出后才进入孤儿恢复宽限期。
- Helper 在返回成功前验证 `session.json`、`watchdog.pid`、`watchdog.heartbeat.json`，并核对 PID 与 Group。
- Go 主程序等待 Watchdog 时验证 `session.json` 的 Group、Schema、Version、ParentPID、StateDir、ReadyToken，并核对 PID 文件与心跳 PID。
- 修正正式源码中 `watchdog.pid` 的 `Join-Path` 参数，改为单一子路径，写入后读回验证。
- 启动横幅/标题/主程序版本日志统一从 `appVersion` 读取，显示 v17.10。
- ProgramData 遗留会话枚举增加 `-Force`，并采用保留优先策略：损坏/未知/非空孤儿/非受信所有者目录阻止新会话，不静默跳过。
- 仅完全空、没有 session.json、没有修改证据且所有者符合预期的孤儿目录可自动清理。
- 历史 `audit` 文件和 `active-session.lock` 文件本身不参与会话活动判断，也不在常规恢复时删除。

## 未改变

- AllowedDomains.txt、ProtectedPaths.txt、JavaPaths.txt、DefaultLauncherPath.txt 与 v17.9 完全一致。
- 不修改 hosts。
- 不改变现有防火墙默认 BLOCK、指定白名单、静态 IP/FQDN 降级、5157 和 ACL 保护策略。
