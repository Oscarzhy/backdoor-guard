# v17.16 源码复核与范围检查

## 保留实现的逐段比较

下列 PowerShell 函数与上传 v17.15 源码逐段文本比较一致：

- `Read-GuardUtf8Text`：不重写既有 ACL/session 严格 UTF-8 行为。
- `Write-AtomicText`：保留显式同目录备份/原子替换和失败保留策略。
- `Remove-GuardDeny` 两份实现：仍只移除有来源的精确显式 ACE。
- `Restore-ProfileState` / `Restore-Profiles`：保留 GpoBoolean 兼容转换。
- `Repair-DisabledAllowsFingerprintEscapes` 两份实现：保留受限旧 Fingerprint 修复。
- `Get-GuardParentLeaseMutexState`、`Test-WatchdogParentReadyAcknowledgement`：保留父进程租约与启动确认。
- `Test-MinecraftJavaCommandLine`：保留已有 Minecraft 参数识别，不凭扫描结果扩大命令行匹配。

`roots=0` 所在原汇总行保持。旧 Group 幂等规则清理、外部 Allow 指纹恢复、Bootstrap 成功标记/短 trampoline/UAC 哈希机制没有改写。

## 当前修改检查

- 有效 ACL 只有一份共享定义，Go/Helper/Watchdog 均使用它；来源 ACE 恢复仍独立。
- Watchdog 的非空 journal 标志和通知 writer 定义实际出现在生成脚本，不依赖 Helper 进程作用域。
- Java 自动候选与 cfg.JavaPaths 分开；运行时同步先写元数据，再审计冲突 Allow，再重建端点规则。
- 原生备用进程快照不产生 ConfirmedJavaProcesses。主程序的 UNKNOWN_ALIVE 不显示成确认的 Minecraft。
- FQDN 降级失败不再删除动态清理 ID 清单；最终核验失败可传播，旧状态保留。
- 新增的 audit_policy 严格读取继续使用已有解码器。
- CLI、配置和通知边界具有实际自动化测试；完整的脚本解析由 PS7.4.6 执行。

以上为源码、比较、Parser 和模拟证据。尚无 Windows PS5.1/真实 ACL/ActiveStore/UAC 验收。详细未解决风险见 00/02/03，不将网络架构或 reparse 兼容称作已完成。

上传 Go 基线 SHA-256：`0d38159ca47007192a797f06846039a5ee0fb22ce7c77b5101b09b8a4a06e4c5`。输入 ZIP CRC 与输入 FILE_HASHES_SHA256 清单均核验通过。
